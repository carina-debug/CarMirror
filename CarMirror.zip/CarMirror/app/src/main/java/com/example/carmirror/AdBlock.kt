package com.example.carmirror

import android.net.Uri
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream

/**
 * Basit reklam engelleme (en iyi çaba):
 *  1) Bilinen reklam sunucularına giden istekleri boş yanıtla keser.
 *  2) YouTube'un oynatıcı yanıtlarındaki reklam alanlarını (adPlacements vb.) sayfa betikleri
 *     çalışmadan önce siler.
 *  3) Reklam gösterilirse videoyu sessize alıp sona sarar, "Atla" düğmesine basar ve
 *     reklam arayüzünü CSS ile gizler.
 * YouTube bunları sık sık değiştirdiği için zamanla bozulabilir.
 */
object AdBlock {

    private val adHosts = listOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adservice.google.com", "imasdk.googleapis.com", "2mdn.net", "adnxs.com",
        "adsrvr.org", "taboola.com", "outbrain.com", "scorecardresearch.com",
        "moatads.com", "amazon-adsystem.com", "criteo.com", "pubmatic.com",
        "rubiconproject.com", "openx.net", "adform.net", "smartadserver.com"
    )

    private val youtubeAdPaths = listOf(
        "/pagead/", "/api/stats/ads", "/get_midroll_info", "/youtubei/v1/player/ad_break"
    )

    fun shouldBlock(uri: Uri): Boolean {
        val host = uri.host?.lowercase() ?: return false
        if (adHosts.any { host == it || host.endsWith(".$it") }) return true
        if (host.endsWith("youtube.com")) {
            val path = uri.path ?: return false
            if (youtubeAdPaths.any { path.contains(it) }) return true
        }
        return false
    }

    fun emptyResponse(): WebResourceResponse =
        WebResourceResponse(
            "text/plain", "utf-8", 204, "No Content", emptyMap(), ByteArrayInputStream(ByteArray(0))
        )

    /** Sayfa betiklerinden önce (document start) ya da sayfa yüklenirken çalıştırılır; tekrar çalışması zararsız. */
    val SCRIPT = """
        (function(){
          if (window.__cmAdBlock) return;
          window.__cmAdBlock = true;

          var KEYS = ['adPlacements','playerAds','adSlots','adBreakHeartbeatParams'];
          function clean(o){
            try {
              if (o && typeof o === 'object') {
                KEYS.forEach(function(k){
                  if (k in o) { try { delete o[k]; } catch(e) { o[k] = undefined; } }
                });
              }
            } catch(e) {}
            return o;
          }
          function cleanAny(r){
            try {
              if (!r || typeof r !== 'object') return r;
              if (r.adPlacements || r.playerAds || r.adSlots) clean(r);
              if (r.playerResponse) clean(r.playerResponse);
            } catch(e) {}
            return r;
          }

          try {
            var origParse = JSON.parse;
            JSON.parse = function(){ return cleanAny(origParse.apply(this, arguments)); };
          } catch(e) {}

          try {
            var origJson = Response.prototype.json;
            Response.prototype.json = function(){
              return origJson.apply(this, arguments).then(cleanAny);
            };
          } catch(e) {}

          try {
            var ipr;
            Object.defineProperty(window, 'ytInitialPlayerResponse', {
              configurable: true,
              get: function(){ return ipr; },
              set: function(v){ ipr = clean(v); }
            });
          } catch(e) {}

          var css = '#masthead-ad,#player-ads,.video-ads,.ytp-ad-module,.ytp-ad-overlay-container,' +
            '.ytp-ad-image-overlay,.ytp-paid-content-overlay,ytd-ad-slot-renderer,' +
            'ytd-promoted-sparkles-web-renderer,ytd-promoted-video-renderer,ytd-display-ad-renderer,' +
            'ytd-in-feed-ad-layout-renderer,ytd-banner-promo-renderer,ytd-statement-banner-renderer,' +
            'ytd-companion-slot-renderer,ytd-action-companion-ad-renderer,' +
            'ytd-player-legacy-desktop-watch-ads-renderer,.ytp-ad-text-overlay' +
            '{display:none !important}';
          function addCss(){
            var r = document.head || document.documentElement;
            if (!r) return false;
            var s = document.createElement('style');
            s.textContent = css;
            r.appendChild(s);
            return true;
          }
          if (!addCss()) document.addEventListener('DOMContentLoaded', addCss);

          var adMuted = false, prevMuted = false;
          setInterval(function(){
            try {
              var p = document.querySelector('.html5-video-player');
              var v = document.querySelector('video.html5-main-video') || document.querySelector('video');
              var showing = p && p.classList.contains('ad-showing');
              if (v && showing) {
                if (!adMuted) { adMuted = true; prevMuted = v.muted; }
                v.muted = true;
                if (isFinite(v.duration) && v.duration > 0) { v.currentTime = v.duration; }
                var b = document.querySelector('.ytp-skip-ad-button, .ytp-ad-skip-button, ' +
                  '.ytp-ad-skip-button-modern, .ytp-ad-skip-button-container button');
                if (b) b.click();
              } else if (v && adMuted) {
                adMuted = false;
                v.muted = prevMuted;
              }
              var c = document.querySelector('.ytp-ad-overlay-close-button');
              if (c) c.click();
            } catch(e) {}
          }, 250);
        })();
    """.trimIndent()
}
