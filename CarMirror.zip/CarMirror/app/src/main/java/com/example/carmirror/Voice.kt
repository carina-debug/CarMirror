package com.example.carmirror

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.util.Locale

/** Sesle yazma: telefonun mikrofonu + ses tanıma servisi (araçta da ekranı açmadan çalışır). */
object Voice {

    private var rec: SpeechRecognizer? = null

    /** Ana iş parçacığından çağır. [onMsg] kısa durum mesajları için (toast). */
    fun listen(ctx: Context, onText: (String) -> Unit, onMsg: (String) -> Unit) {
        val app = ctx.applicationContext
        if (!Perms.hasMic(app)) {
            onMsg("Mikrofon izni yok: telefonda uygulamayı açıp izin ver")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(app)) {
            onMsg("Bu telefonda ses tanıma yok")
            return
        }
        rec?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(app)
        rec = r
        fun done() {
            r.destroy()
            if (rec === r) rec = null
        }
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) = onMsg("🎤 Dinliyorum…")
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onError(error: Int) {
                done()
                onMsg("Anlaşılamadı, tekrar dene")
            }

            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                done()
                if (text.isNullOrBlank()) onMsg("Anlaşılamadı, tekrar dene") else onText(text)
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        r.startListening(i)
    }
}
