package com.example.carmirror

import android.content.Context
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Araç ekranında gösterilen her modül (tarayıcı, müzik, ...) bu arayüzü uygular. */
interface CarModule {
    val title: String
    fun createView(root: RootView): View
    fun onShow() {}
    fun onHide() {}

    /** true dönerse geri tuşu modül içinde tüketildi demektir. */
    fun onBack(): Boolean = false
    fun onDestroy() {}
}

/**
 * Araç ekranındaki sanal pencerenin kök görünümü: üst çubuk + modül alanı +
 * tam ekran katmanı + ekran klavyesi + kısa mesaj (toast).
 */
class RootView(ctx: Context, val host: CarUiHost, startId: String = "home") : FrameLayout(ctx) {

    private val handler = Handler(Looper.getMainLooper())
    private val topBar = LinearLayout(ctx)
    private val titleView = Ui.label(ctx, "", 22f, bold = true)
    private val clock = Ui.label(ctx, "", 20f, Ui.MUTED)
    private val content = FrameLayout(ctx)
    private val overlay = FrameLayout(ctx)
    private val keyboard = CarKeyboard(ctx)
    private val toastView = Ui.label(ctx, "", 18f)

    private val factories: Map<String, () -> CarModule> = mapOf(
        "home" to { HomeModule(this) },
        "youtube" to { BrowserModule(this, "YouTube", "https://www.youtube.com", true, false) },
        "kids" to { BrowserModule(this, "YouTube Kids", "https://www.youtubekids.com", true, false) },
        "ytmusic" to { BrowserModule(this, "YouTube Music", "https://music.youtube.com", true, false) },
        "browser" to { BrowserModule(this, "Tarayıcı", null, true, true) },
        "music" to { MusicModule(this) },
        "radio" to { RadioModule(this) },
        "gallery" to { GalleryModule(this) },
        "iptv" to { IptvModule(this) },
        "settings" to { SettingsModule(this) }
    )
    private val modules = HashMap<String, CarModule>()
    private val views = HashMap<String, View>()
    private var current: String? = null
    private var overlayHidden: (() -> Unit)? = null

    private val hideToast = Runnable { toastView.visibility = View.GONE }
    private val tick = object : Runnable {
        override fun run() {
            clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            handler.postDelayed(this, 20_000)
        }
    }

    init {
        setBackgroundColor(Ui.BG)
        val c = ctx

        topBar.orientation = LinearLayout.HORIZONTAL
        topBar.gravity = Gravity.CENTER_VERTICAL
        topBar.setPadding(c.dp(8), c.dp(4), c.dp(8), c.dp(4))
        topBar.setBackgroundColor(Ui.PANEL)
        topBar.addView(Ui.button(c, "⌂", 24f) { home() }, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, c.dp(3)))
        topBar.addView(Ui.button(c, "◀", 22f) { back() }, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, c.dp(3)))
        topBar.addView(titleView, Ui.lin(0, Ui.WRAP, 1f).apply { leftMargin = c.dp(14) })
        topBar.addView(clock)

        val column = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        column.addView(topBar, Ui.lin(Ui.MATCH, Ui.WRAP))
        column.addView(content, Ui.lin(Ui.MATCH, 0, 1f))
        addView(column, LayoutParams(Ui.MATCH, Ui.MATCH))

        overlay.setBackgroundColor(Color.BLACK)
        overlay.visibility = View.GONE
        addView(overlay, LayoutParams(Ui.MATCH, Ui.MATCH))

        addView(keyboard, LayoutParams(Ui.MATCH, Ui.WRAP, Gravity.BOTTOM))

        toastView.background = Ui.round(0xE6000000.toInt(), c.dp(10).toFloat())
        toastView.setPadding(c.dp(18), c.dp(10), c.dp(18), c.dp(10))
        toastView.visibility = View.GONE
        addView(
            toastView,
            LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
                bottomMargin = c.dp(40)
            }
        )

        tick.run()
        open(startId)
    }

    fun home() = open("home")

    fun open(id: String) {
        if (id == current) return
        hideKeyboard()
        if (overlay.visibility == View.VISIBLE) hideFullscreen()
        current?.let { modules[it]?.onHide() }
        content.removeAllViews()

        val m = modules.getOrPut(id) { factories.getValue(id)() }
        val v = views.getOrPut(id) { m.createView(this) }
        (v.parent as? ViewGroup)?.removeView(v)
        content.addView(v, LayoutParams(Ui.MATCH, Ui.MATCH))
        titleView.text = m.title
        current = id
        setChromeVisible(true)
        m.onShow()
    }

    fun back() {
        if (keyboard.visibility == View.VISIBLE) {
            hideKeyboard()
            return
        }
        if (overlay.visibility == View.VISIBLE) {
            hideFullscreen()
            return
        }
        val c = current ?: return
        if (modules[c]?.onBack() == true) return
        if (c != "home") home()
    }

    fun setChromeVisible(visible: Boolean) {
        topBar.visibility = if (visible) View.VISIBLE else View.GONE
    }

    fun showKeyboard(initial: String, hint: String, done: (String) -> Unit) {
        keyboard.show(initial, hint) {
            keyboard.hide()
            done(it)
        }
    }

    fun hideKeyboard() = keyboard.hide()

    fun showFullscreen(v: View, onHidden: () -> Unit) {
        overlay.removeAllViews()
        (v.parent as? ViewGroup)?.removeView(v)
        overlay.addView(v, LayoutParams(Ui.MATCH, Ui.MATCH))
        overlay.visibility = View.VISIBLE
        overlayHidden = onHidden
        setChromeVisible(false)
    }

    fun hideFullscreen() {
        if (overlay.visibility != View.VISIBLE) return
        overlay.visibility = View.GONE
        overlay.removeAllViews()
        setChromeVisible(true)
        val cb = overlayHidden
        overlayHidden = null
        cb?.invoke()
    }

    fun toast(msg: String) {
        toastView.text = msg
        toastView.visibility = View.VISIBLE
        toastView.bringToFront()
        handler.removeCallbacks(hideToast)
        handler.postDelayed(hideToast, 2500)
    }

    fun destroy() {
        handler.removeCallbacksAndMessages(null)
        modules.values.forEach {
            try {
                it.onDestroy()
            } catch (_: Exception) {
            }
        }
        modules.clear()
        views.clear()
    }
}
