package com.example.carmirror

import android.content.Context
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.webkit.CookieManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Araç ve telefon tarafının paylaştığı basit ayarlar. */
object CarPrefs {

    private fun sp(ctx: Context) = ctx.getSharedPreferences("car", Context.MODE_PRIVATE)

    fun adBlock(ctx: Context): Boolean = sp(ctx).getBoolean("adblock", true)

    fun setAdBlock(ctx: Context, v: Boolean) {
        sp(ctx).edit().putBoolean("adblock", v).apply()
    }

    fun radioCountry(ctx: Context): String = sp(ctx).getString("radio_cc", "TR") ?: "TR"

    fun setRadioCountry(ctx: Context, v: String) {
        sp(ctx).edit().putString("radio_cc", v).apply()
    }

    fun zoom(ctx: Context): Int = sp(ctx).getInt("zoom", 130)

    fun setZoom(ctx: Context, v: Int) {
        sp(ctx).edit().putInt("zoom", v).apply()
    }

    fun theme(ctx: Context): String = sp(ctx).getString("theme", "midnight") ?: "midnight"

    fun setTheme(ctx: Context, id: String) {
        sp(ctx).edit().putString("theme", id).apply()
    }

    fun autoTheme(ctx: Context): Boolean = sp(ctx).getBoolean("auto_theme", true)

    fun setAutoTheme(ctx: Context, v: Boolean) {
        sp(ctx).edit().putBoolean("auto_theme", v).apply()
    }

    fun bigText(ctx: Context): Boolean = sp(ctx).getBoolean("big_text", false)

    fun setBigText(ctx: Context, v: Boolean) {
        sp(ctx).edit().putBoolean("big_text", v).apply()
    }

    /** "maps" (Google Haritalar) veya "waze" */
    fun navApp(ctx: Context): String = sp(ctx).getString("nav_app", "maps") ?: "maps"

    fun setNavApp(ctx: Context, v: String) {
        sp(ctx).edit().putString("nav_app", v).apply()
    }

    /** Uygulama başına seçilen simge (yoksa null = varsayılan). */
    fun icon(ctx: Context, id: String): String? = sp(ctx).getString("icon_$id", null)

    fun setIcon(ctx: Context, id: String, v: String) {
        sp(ctx).edit().putString("icon_$id", v).apply()
    }

    fun resetIcons(ctx: Context) {
        val e = sp(ctx).edit()
        sp(ctx).all.keys.filter { it.startsWith("icon_") }.forEach { e.remove(it) }
        e.apply()
    }

    /** "fit" (sığdır), "fill" (doldur), "stretch" (uzat), "169", "43" */
    fun videoMode(ctx: Context): String = sp(ctx).getString("video_mode", "fit") ?: "fit"

    fun setVideoMode(ctx: Context, v: String) {
        sp(ctx).edit().putString("video_mode", v).apply()
    }

    fun permsAsked(ctx: Context): Boolean = sp(ctx).getBoolean("perms_asked_v7", false)

    fun setPermsAsked(ctx: Context) {
        sp(ctx).edit().putBoolean("perms_asked_v7", true).apply()
    }

    /** Ana menüdeki uygulama açılış sayıları (sık kullanılan kısayollar için). */
    fun usage(ctx: Context): Map<String, Int> =
        (sp(ctx).getString("usage", "") ?: "").split(',').mapNotNull {
            val p = it.split(':')
            if (p.size == 2) p[1].toIntOrNull()?.let { n -> p[0] to n } else null
        }.toMap()

    fun bump(ctx: Context, id: String) {
        val m = usage(ctx).toMutableMap()
        m[id] = (m[id] ?: 0) + 1
        sp(ctx).edit().putString("usage", m.entries.joinToString(",") { "${it.key}:${it.value}" }).apply()
    }

    /** Ana menüdeki uygulama sırası (uygulama kimlikleri). Boşsa varsayılan sıra. */
    fun order(ctx: Context): List<String> =
        (sp(ctx).getString("order", "") ?: "").split(',').filter { it.isNotBlank() }

    fun setOrder(ctx: Context, ids: List<String>) {
        sp(ctx).edit().putString("order", ids.joinToString(",")).apply()
    }
}

// Tema değişince arayüz baştan kurulur; kullanıcı aynı sayfada kalsın diye son sayfa hatırlanır.
private var rememberedPage = "general"

/** Araç ekranındaki "Ayarlar" kutusu: Genel / Tema / Sıralama / Simgeler sayfaları. */
class SettingsModule(private val root: RootView) : CarModule {

    override val title = "Ayarlar"

    private val countries = listOf("TR", "DE", "NL", "FR", "GB", "US", "AZ", "CY")

    private lateinit var content: FrameLayout
    private val navButtons = LinkedHashMap<String, TextView>()
    private lateinit var adBtn: TextView
    private lateinit var ccBtn: TextView
    private lateinit var autoBtn: TextView
    private lateinit var bigBtn: TextView
    private lateinit var navBtn: TextView
    private lateinit var vidBtn: TextView
    private lateinit var updBtn: TextView
    private lateinit var altBtn: TextView
    private lateinit var srcInfo: TextView
    private lateinit var diagBtn: TextView
    private var updText: String? = null
    private var updUrl: String? = null
    private var altText: String? = null
    private var selected = 0

    override fun createView(root: RootView): View {
        val c = root.context
        content = FrameLayout(c)

        val compact = root.compact
        val nav = LinearLayout(c).apply {
            // Araçta sol kenar menüsü; telefonda üstte sekme şeridi
            orientation = if (compact) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
            setPadding(c.dp(8), c.dp(8), c.dp(8), c.dp(8))
        }
        listOf("general" to "⚙  Genel", "theme" to "🎨  Tema", "order" to "↔  Sıralama", "icons" to "✨  Simgeler").forEach { (id, label) ->
            val b = Ui.button(c, if (compact) label.replace("  ", " ") else label, if (compact) 12f else 19f) { show(id) }
            navButtons[id] = b
            nav.addView(
                b,
                if (compact) Ui.lin(0, Ui.WRAP, 1f, c.dp(3)) else Ui.lin(Ui.MATCH, Ui.WRAP, 0f, c.dp(4))
            )
        }

        val row = LinearLayout(c).apply {
            if (compact) {
                orientation = LinearLayout.VERTICAL
                addView(nav, Ui.lin(Ui.MATCH, Ui.WRAP))
                addView(content, Ui.lin(Ui.MATCH, 0, 1f))
            } else {
                orientation = LinearLayout.HORIZONTAL
                addView(nav, Ui.lin(c.dp(190), Ui.MATCH))
                addView(content, Ui.lin(0, Ui.MATCH, 1f))
            }
        }
        show(rememberedPage)
        return row
    }

    private fun show(id: String) {
        rememberedPage = id
        val c = root.context
        content.removeAllViews()
        val v = when (id) {
            "theme" -> themePage()
            "order" -> orderPage()
            "icons" -> iconsPage()
            else -> generalPage()
        }
        content.addView(v, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        navButtons.forEach { (k, b) ->
            b.background = Ui.round(if (k == id) Ui.ACCENT else Ui.PANEL2, c.dp(10).toFloat())
            b.setTextColor(if (k == id) 0xFFFFFFFF.toInt() else Ui.TEXT)
        }
    }

    // ------------------------------------------------------------------ Genel

    private fun generalPage(): View {
        val c = root.context

        val sp = if (root.compact) 16f else 20f
        adBtn = Ui.button(c, "", sp) {
            CarPrefs.setAdBlock(c, !CarPrefs.adBlock(c))
            refreshGeneral()
            root.toast("Değişiklik, uygulamayı kapatıp açınca geçerli olur")
        }
        ccBtn = Ui.button(c, "", sp) {
            val cur = CarPrefs.radioCountry(c)
            val next = countries[(countries.indexOf(cur) + 1) % countries.size]
            CarPrefs.setRadioCountry(c, next)
            refreshGeneral()
            root.toast("Radyo > Yerel sekmesi $next istasyonlarını gösterecek")
        }
        autoBtn = Ui.button(c, "", sp) {
            CarPrefs.setAutoTheme(c, !CarPrefs.autoTheme(c))
            Themes.applyAll(c)
            root.host.restartUi("settings")
        }
        bigBtn = Ui.button(c, "", sp) {
            CarPrefs.setBigText(c, !CarPrefs.bigText(c))
            Themes.applyAll(c)
            root.host.restartUi("settings")
        }
        navBtn = Ui.button(c, "", sp) {
            CarPrefs.setNavApp(c, if (CarPrefs.navApp(c) == "waze") "maps" else "waze")
            refreshGeneral()
        }
        vidBtn = Ui.button(c, "", sp) {
            val modes = listOf("fit", "fill", "stretch", "169", "43")
            val cur = CarPrefs.videoMode(c)
            CarPrefs.setVideoMode(c, modes[(modes.indexOf(cur) + 1) % modes.size])
            refreshGeneral()
            root.toast("Video görüntüsü bir sonraki açılışta/yenilemede uygulanır")
        }
        updBtn = Ui.button(c, "", sp) {
            val url = updUrl
            if (url != null && url.endsWith(".apk", ignoreCase = true)) {
                SelfInstaller.downloadAndInstall(c, url) { msg ->
                    updText = msg
                    refreshGeneral()
                }
            } else if (url != null) {
                try {
                    c.applicationContext.startActivity(
                        Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (_: Exception) {
                    root.toast("Bağlantı açılamadı")
                }
            } else {
                updText = "Denetleniyor…"
                refreshGeneral()
                Updater.check(c) { r ->
                    when (r.kind) {
                        Updater.Kind.AVAILABLE -> {
                            updUrl = r.url
                            updText = "Yeni sürüm var: ${r.version} – kurmak için dokun"
                        }
                        Updater.Kind.UP_TO_DATE -> updText = "Güncel ✓ (sürüm ${BuildConfig.VERSION_NAME})"
                        Updater.Kind.ERROR -> updText = "Denetlenemedi: ${r.message}"
                    }
                    refreshGeneral()
                }
            }
        }
        altBtn = Ui.button(c, "Alternatif yöntemle etkinleştir", sp) {
            SelfInstaller.reinstallSelf(c) { msg ->
                altText = msg
                refreshGeneral()
            }
        }
        diagBtn = Ui.button(c, "Android Auto görünmüyor mu? Tanıla", sp) {
            if (!root.isPhone) {
                root.toast("Bu kontrol telefonda açılır")
            } else {
                android.app.AlertDialog.Builder(c)
                    .setTitle("Android Auto tanılama")
                    .setMessage(AutoDiag.report(c))
                    .setPositiveButton("Tamam", null)
                    .show()
            }
        }
        srcInfo = Ui.label(c, "", 13f, Ui.MUTED).apply { setPadding(c.dp(4), 0, c.dp(4), 0) }
        val vidInfo = Ui.label(
            c,
            "Sığdır: görüntünün tamamı görünür.  Doldur: kenarlar kırpılır, boşluk kalmaz.  " +
                    "Uzat: ekrana yayılır (oran bozulur).  16:9 / 4:3: sabit oran.",
            14f,
            Ui.MUTED
        ).apply { setPadding(c.dp(4), 0, c.dp(4), 0) }
        val cookieBtn = Ui.button(c, "Web oturumlarını sil (çerezler)", sp) {
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
            root.toast("Oturumlar silindi")
        }
        val about = Ui.label(
            c,
            "Reklam engelleme en iyi çabayla çalışır; YouTube değiştikçe bozulabilir. " +
                    "Yazı girişi için sayfadaki bir kutuya dokununca ekran klavyesi açılır; 🎤 ile sesle de yazabilirsin. " +
                    "Radyo istasyonlarını ve IPTV listesini telefondaki uygulamadan yönetirsin.",
            15f,
            Ui.MUTED
        )

        val col = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(c.dp(14), c.dp(10), c.dp(14), c.dp(10))
            addView(adBtn, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, c.dp(5)))
            addView(ccBtn, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, c.dp(5)))
            addView(autoBtn, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, c.dp(5)))
            addView(bigBtn, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, c.dp(5)))
            addView(navBtn, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, c.dp(5)))
            addView(vidBtn, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, c.dp(5)))
            addView(vidInfo, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, c.dp(5)))
            addView(updBtn, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, c.dp(5)))
            addView(altBtn, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, c.dp(5)))
            addView(diagBtn, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, c.dp(5)))
            addView(srcInfo, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, c.dp(5)))
            addView(cookieBtn, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, c.dp(5)))
            if (root.isPhone) {
                // Telefonda kurulum ekranlarına buradan ulaşılır
                addView(
                    Ui.button(c, "📻  Radyo istasyonlarını düzenle", sp) {
                        c.startActivity(Intent(c, RadioEditActivity::class.java))
                    },
                    Ui.lin(Ui.MATCH, Ui.WRAP, 0f, c.dp(5))
                )
                addView(
                    Ui.button(c, "📺  IPTV ayarları", sp) {
                        c.startActivity(Intent(c, IptvSettingsActivity::class.java))
                    },
                    Ui.lin(Ui.MATCH, Ui.WRAP, 0f, c.dp(5))
                )
                addView(
                    Ui.button(c, "🔔  Mesaj şeridi için bildirim erişimi", sp) {
                        c.startActivity(Intent(android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    },
                    Ui.lin(Ui.MATCH, Ui.WRAP, 0f, c.dp(5))
                )
                addView(
                    Ui.button(c, "🚗  Kurulum, izinler, araç yansıtma", sp) {
                        c.startActivity(Intent(c, MainActivity::class.java))
                    },
                    Ui.lin(Ui.MATCH, Ui.WRAP, 0f, c.dp(5))
                )
            }
            addView(about, Ui.lin(Ui.MATCH, Ui.WRAP).apply { topMargin = c.dp(14) })
        }
        refreshGeneral()
        return ScrollView(c).apply { addView(col) }
    }

    private fun refreshGeneral() {
        val c = root.context
        adBtn.text = "Reklam engelleme: " + if (CarPrefs.adBlock(c)) "AÇIK" else "KAPALI"
        autoBtn.text = "Otomatik gündüz/gece tema: " + if (CarPrefs.autoTheme(c)) "AÇIK" else "KAPALI"
        bigBtn.text = "Büyük yazı modu: " + if (CarPrefs.bigText(c)) "AÇIK" else "KAPALI"
        navBtn.text = "Navigasyon kartı: " + if (CarPrefs.navApp(c) == "waze") "Waze" else "Google Haritalar"
        vidBtn.text = "Video görüntüsü: " + when (CarPrefs.videoMode(c)) {
            "fill" -> "Doldur"
            "stretch" -> "Uzat"
            "169" -> "16:9"
            "43" -> "4:3"
            else -> "Sığdır"
        }
        altBtn.text = altText ?: "Alternatif yöntemle etkinleştir (normal yöntem işe yaramadıysa)"
        srcInfo.text = SelfInstaller.installSource(c)
        updBtn.text = updText ?: "Güncellemeleri denetle  (şu an ${BuildConfig.VERSION_NAME})"
        ccBtn.text = "Yerel radyo ülkesi: " + CarPrefs.radioCountry(c) + "  (değiştirmek için dokun)"
    }

    // ------------------------------------------------------------------- Tema

    private fun themePage(): View {
        val c = root.context
        val grid = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(c.dp(10), c.dp(10), c.dp(10), c.dp(10))
        }
        val cols = if (root.compact) 2 else 3
        Themes.all.chunked(cols).forEach { rowThemes ->
            val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
            rowThemes.forEach { t -> row.addView(themeCard(t), Ui.lin(0, Ui.MATCH, 1f, c.dp(6))) }
            repeat(cols - rowThemes.size) { row.addView(View(c), Ui.lin(0, Ui.MATCH, 1f, c.dp(6))) }
            grid.addView(row, Ui.lin(Ui.MATCH, 0, 1f))
        }
        return grid
    }

    private fun themeCard(t: Theme): View {
        val c = root.context
        val sel = t.id == CarPrefs.theme(c)
        val card = GradientDrawable().apply {
            setColor(t.panel)
            cornerRadius = c.dp(16).toFloat()
            setStroke(c.dp(if (sel) 3 else 1), if (sel) t.accent else 0x33FFFFFF)
        }
        val swatches = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            listOf(t.bg, t.panel2, t.accent).forEach { color ->
                val chip = View(c).apply {
                    background = GradientDrawable().apply {
                        setColor(color)
                        cornerRadius = c.dp(8).toFloat()
                        setStroke(c.dp(1), 0x55FFFFFF)
                    }
                }
                addView(chip, Ui.lin(c.dp(30), c.dp(30), 0f, c.dp(3)))
            }
        }
        return LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = card
            isClickable = true
            addView(swatches, Ui.lin(Ui.WRAP, Ui.WRAP))
            addView(
                Ui.label(c, (if (sel) "✓ " else "") + t.name, 17f, t.text, bold = true).apply {
                    gravity = Gravity.CENTER
                },
                Ui.lin(Ui.WRAP, Ui.WRAP).apply { topMargin = c.dp(10) }
            )
            setOnClickListener {
                if (!sel) {
                    CarPrefs.setTheme(c, t.id)
                    Themes.applyAll(c)
                    if (Themes.currentId != t.id) {
                        root.toast("Otomatik mod açık: bu tema geceleri kullanılır")
                    }
                    root.host.restartUi("settings")
                }
            }
        }
    }

    // --------------------------------------------------------------- Simgeler

    private var iconSel = "youtube"

    private fun iconsPage(): View {
        val c = root.context
        val apps = Apps.ordered(c, root.isPhone)
        val cur = apps.firstOrNull { it.id == iconSel } ?: apps.first().also { iconSel = it.id }
        val cols = if (root.compact) 3 else 5

        val info = Ui.label(
            c,
            "Bir uygulama seç, sonra altından simgesini seç. Ana menüye dönünce değişir.",
            15f,
            Ui.MUTED
        ).apply { setPadding(c.dp(10), c.dp(8), c.dp(10), c.dp(4)) }

        val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        col.addView(info, Ui.lin(Ui.MATCH, Ui.WRAP))

        val grid = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(c.dp(6), c.dp(4), c.dp(6), c.dp(4))
        }
        apps.chunked(cols).forEach { rowApps ->
            val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
            rowApps.forEach { app -> row.addView(iconAppTile(app, app.id == cur.id), Ui.lin(0, Ui.MATCH, 1f, c.dp(4))) }
            repeat(cols - rowApps.size) { row.addView(View(c), Ui.lin(0, Ui.MATCH, 1f, c.dp(4))) }
            grid.addView(row, Ui.lin(Ui.MATCH, c.dp(96)))
        }
        col.addView(grid, Ui.lin(Ui.MATCH, Ui.WRAP))

        col.addView(
            Ui.label(c, "${cur.label} için simge:", 16f, bold = true)
                .apply { setPadding(c.dp(12), c.dp(10), c.dp(12), c.dp(4)) },
            Ui.lin(Ui.MATCH, Ui.WRAP)
        )
        val chosen = Apps.iconOf(c, cur)
        val choices = Apps.iconChoices(cur)
        val perRow = if (root.compact) 5 else 8
        val picker = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(c.dp(6), c.dp(2), c.dp(6), c.dp(2))
        }
        choices.chunked(perRow).forEach { rowChoices ->
            val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
            rowChoices.forEach { ch ->
                val sel = ch == chosen
                val cell = FrameLayout(c).apply {
                    background = GradientDrawable().apply {
                        setColor(Ui.PANEL)
                        cornerRadius = c.dp(12).toFloat()
                        setStroke(c.dp(if (sel) 3 else 1), if (sel) Ui.ACCENT else 0x33FFFFFF)
                    }
                    isClickable = true
                    addView(
                        if (ch == Apps.ORIGINAL) {
                            android.widget.ImageView(c).apply {
                                setImageResource(R.drawable.ic_kids)
                                setPadding(c.dp(6), c.dp(6), c.dp(6), c.dp(6))
                            }
                        } else {
                            TextView(c).apply {
                                text = ch
                                textSize = 24f
                                gravity = Gravity.CENTER
                                setTextColor(Ui.TEXT)
                            }
                        },
                        FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH)
                    )
                    setOnClickListener {
                        CarPrefs.setIcon(c, cur.id, ch)
                        show("icons")
                    }
                }
                row.addView(cell, Ui.lin(0, c.dp(56), 1f, c.dp(3)))
            }
            repeat(perRow - rowChoices.size) { row.addView(View(c), Ui.lin(0, c.dp(56), 1f, c.dp(3))) }
            picker.addView(row, Ui.lin(Ui.MATCH, Ui.WRAP))
        }
        col.addView(picker, Ui.lin(Ui.MATCH, Ui.WRAP))

        col.addView(
            Ui.button(c, "↺ Tüm simgeleri varsayılana döndür", if (root.compact) 14f else 18f) {
                CarPrefs.resetIcons(c)
                show("icons")
            },
            Ui.lin(Ui.MATCH, Ui.WRAP).apply { setMargins(c.dp(10), c.dp(10), c.dp(10), c.dp(14)) }
        )
        return ScrollView(c).apply { addView(col) }
    }

    private fun iconAppTile(app: App, sel: Boolean): View {
        val c = root.context
        val bg = GradientDrawable().apply {
            setColor(Ui.PANEL)
            cornerRadius = c.dp(14).toFloat()
            setStroke(c.dp(if (sel) 3 else 1), if (sel) Ui.ACCENT else 0x33FFFFFF)
        }
        return LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = bg
            isClickable = true
            addView(Apps.iconView(c, app, 22f, 12), LinearLayout.LayoutParams(c.dp(46), c.dp(46)))
            addView(
                Ui.label(c, app.label, 13f, bold = true).apply {
                    gravity = Gravity.CENTER
                    isSingleLine = true
                    ellipsize = TextUtils.TruncateAt.END
                },
                Ui.lin(Ui.WRAP, Ui.WRAP).apply { topMargin = c.dp(6) }
            )
            setOnClickListener {
                iconSel = app.id
                show("icons")
            }
        }
    }

    // --------------------------------------------------------------- Sıralama

    private fun orderPage(): View {
        val c = root.context
        val apps = Apps.ordered(c)
        if (selected !in apps.indices) selected = 0

        val info = Ui.label(
            c,
            "Bir uygulamaya dokun, sonra ◀ ▶ ile yerini değiştir. Ana menüde bu sırayla görünür.",
            15f,
            Ui.MUTED
        ).apply { setPadding(c.dp(10), c.dp(8), c.dp(10), c.dp(4)) }

        val grid = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(c.dp(6), c.dp(4), c.dp(6), c.dp(4))
        }
        var index = 0
        val cols = if (root.compact) 3 else 5
        apps.chunked(cols).forEach { rowApps ->
            val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
            rowApps.forEach { app ->
                row.addView(miniTile(app, index), Ui.lin(0, Ui.MATCH, 1f, c.dp(4)))
                index++
            }
            repeat(cols - rowApps.size) { row.addView(View(c), Ui.lin(0, Ui.MATCH, 1f, c.dp(4))) }
            grid.addView(row, Ui.lin(Ui.MATCH, 0, 1f))
        }

        val controls = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(c.dp(6), c.dp(4), c.dp(6), c.dp(8))
            val csp = if (root.compact) 14f else 18f
            addView(Ui.button(c, "◀ Sola al", csp) { move(-1) }, Ui.lin(0, Ui.WRAP, 1f, c.dp(4)))
            addView(Ui.button(c, "Sağa al ▶", csp) { move(1) }, Ui.lin(0, Ui.WRAP, 1f, c.dp(4)))
            addView(Ui.button(c, "↺ Varsayılan", csp) { resetOrder() }, Ui.lin(0, Ui.WRAP, 1f, c.dp(4)))
        }

        return LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            addView(info, Ui.lin(Ui.MATCH, Ui.WRAP))
            addView(grid, Ui.lin(Ui.MATCH, 0, 1f))
            addView(controls, Ui.lin(Ui.MATCH, Ui.WRAP))
        }
    }

    private fun miniTile(app: App, index: Int): View {
        val c = root.context
        val sel = index == selected
        val bg = GradientDrawable().apply {
            setColor(Ui.PANEL)
            cornerRadius = c.dp(14).toFloat()
            setStroke(c.dp(if (sel) 3 else 1), if (sel) Ui.ACCENT else 0x33FFFFFF)
        }
        val icon = Apps.iconView(c, app, 22f, 12)
        return LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = bg
            isClickable = true
            addView(icon, LinearLayout.LayoutParams(c.dp(46), c.dp(46)))
            addView(
                Ui.label(c, "${index + 1}. ${app.label}", 13f, bold = true).apply {
                    gravity = Gravity.CENTER
                    isSingleLine = true
                    ellipsize = TextUtils.TruncateAt.END
                },
                Ui.lin(Ui.WRAP, Ui.WRAP).apply { topMargin = c.dp(6) }
            )
            setOnClickListener {
                selected = index
                show("order")
            }
        }
    }

    private fun move(delta: Int) {
        val c = root.context
        val ids = Apps.ordered(c).map { it.id }.toMutableList()
        val target = selected + delta
        if (selected !in ids.indices || target !in ids.indices) return
        val tmp = ids[selected]
        ids[selected] = ids[target]
        ids[target] = tmp
        CarPrefs.setOrder(c, ids)
        selected = target
        show("order")
    }

    private fun resetOrder() {
        CarPrefs.setOrder(root.context, emptyList())
        selected = 0
        show("order")
    }
}
