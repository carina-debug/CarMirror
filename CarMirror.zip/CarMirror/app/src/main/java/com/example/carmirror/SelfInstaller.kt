package com.example.carmirror

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.core.content.FileProvider
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * APK indirip sistem paket yükleyicisiyle kurar.
 *  - [downloadAndInstall]: yeni sürümü indirir ve kurulum ekranını açar.
 *  - [reinstallSelf]: "Alternatif yöntemle etkinleştir": yüklü APK'nın kopyasını sistem paket
 *    yükleyicisiyle yeniden kurar; böylece kurulum kaynağı paket yükleyici olarak görünür.
 *    (Android Auto'nun kurulum kaynağı denetimine etkisi cihaza göre değişebilir.)
 */
object SelfInstaller {

    private val main = Handler(Looper.getMainLooper())

    fun canInstall(ctx: Context): Boolean =
        ctx.applicationContext.packageManager.canRequestPackageInstalls()

    /** "Bu kaynaktan izin ver" ekranını açar. */
    fun openPermissionSettings(ctx: Context) {
        val app = ctx.applicationContext
        val i = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + app.packageName))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            app.startActivity(i)
        } catch (_: Exception) {
        }
    }

    /** Ayarlarda gösterilir: bu uygulamayı kimin kurduğu ve kimin başlattığı. */
    fun installSource(ctx: Context): String {
        val app = ctx.applicationContext
        val pm = app.packageManager
        return try {
            if (Build.VERSION.SDK_INT >= 30) {
                val si = pm.getInstallSourceInfo(app.packageName)
                "Kuran: " + (si.installingPackageName ?: "-") + "\nBaşlatan: " + (si.initiatingPackageName ?: "-")
            } else {
                @Suppress("DEPRECATION")
                "Kuran: " + (pm.getInstallerPackageName(app.packageName) ?: "-")
            }
        } catch (_: Exception) {
            "Kurulum kaynağı okunamadı"
        }
    }

    /** [status] ana iş parçacığında çağrılır. */
    fun downloadAndInstall(ctx: Context, url: String, status: (String) -> Unit) {
        val app = ctx.applicationContext
        if (!canInstall(app)) {
            status("Açılan ekranda \"Bu kaynaktan izin ver\"i aç, sonra geri dönüp tekrar dokun")
            openPermissionSettings(app)
            return
        }
        status("Güncelleme indiriliyor…")
        Thread {
            try {
                val dir = File(app.cacheDir, "apk").apply { mkdirs() }
                val f = File(dir, "update.apk")
                fetchTo(url, f) { p -> main.post { status("Güncelleme indiriliyor… %$p") } }
                main.post {
                    status("İndirildi. Açılan ekranda \"Güncelle\"ye bas")
                    launchInstaller(app, f)
                }
            } catch (e: Exception) {
                main.post { status("İndirilemedi: " + (e.message ?: "hata")) }
            }
        }.start()
    }

    fun reinstallSelf(ctx: Context, status: (String) -> Unit) {
        val app = ctx.applicationContext
        if (!canInstall(app)) {
            status("Açılan ekranda \"Bu kaynaktan izin ver\"i aç, sonra geri dönüp tekrar dokun")
            openPermissionSettings(app)
            return
        }
        status("Hazırlanıyor…")
        Thread {
            try {
                val dir = File(app.cacheDir, "apk").apply { mkdirs() }
                val f = File(dir, "CarMirror.apk")
                File(app.applicationInfo.sourceDir).inputStream().use { ins ->
                    f.outputStream().use { ins.copyTo(it) }
                }
                main.post {
                    status("Kurulum ekranında \"Güncelle\"ye bas; bitince Android Auto'yu yeniden başlat")
                    launchInstaller(app, f)
                }
            } catch (e: Exception) {
                main.post { status("Hazırlanamadı: " + (e.message ?: "hata")) }
            }
        }.start()
    }

    private fun launchInstaller(app: Context, file: File) {
        val uri = FileProvider.getUriForFile(app, app.packageName + ".files", file)
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            app.startActivity(i)
        } catch (_: Exception) {
        }
    }

    private fun fetchTo(url: String, dest: File, onProgress: (Int) -> Unit) {
        var u = url
        for (i in 0 until 6) {
            val conn = URL(u).openConnection() as HttpURLConnection
            conn.instanceFollowRedirects = false
            conn.connectTimeout = 15_000
            conn.readTimeout = 30_000
            conn.setRequestProperty("User-Agent", "CarMirror")
            val code = conn.responseCode
            if (code in 300..399) {
                val loc = conn.getHeaderField("Location") ?: throw IOException("Yönlendirme hatası")
                u = URL(URL(u), loc).toString()
                conn.disconnect()
                continue
            }
            if (code != 200) throw IOException("HTTP $code")
            val total = conn.contentLengthLong
            val tmp = File(dest.parentFile, dest.name + ".tmp")
            conn.inputStream.use { ins ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    var read = 0L
                    var last = -1
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        read += n
                        if (total > 0) {
                            val p = (read * 100 / total).toInt()
                            if (p != last) {
                                last = p
                                onProgress(p)
                            }
                        }
                    }
                }
            }
            dest.delete()
            if (!tmp.renameTo(dest)) throw IOException("Dosya kaydedilemedi")
            return
        }
        throw IOException("Çok fazla yönlendirme")
    }
}
