package com.example.carmirror

import android.content.Context
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.webkit.CookieManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Araç ve telefon tarafının paylaştığı basit ayarlar. */
object CarPrefs {

    private fun sp(ctx: Context) = ctx.getSharedPreferences("car", Context.MODE_PRIVATE)

    fun adBlock(ctx: Context): Boolean = sp(ctx).getBoolean("adblock", true)

    fun setAdBlock(ctx: Context, v: Boolean) {
        sp(ctx).edit().putBoolean("adblock", v).apply()
    }

    fun radioCountry(ctx: Context): String = sp(ctx).getString("radio_cc", "TR") ?: "TR"

    fun setRadioCountry(ctx: Context, v: String) {
        sp(ctx).edit().putString("radio_cc", v).apply()
    }

    fun zoom(ctx: Context): Int = sp(ctx).getInt("zoom", 130)

    fun setZoom(ctx: Context, v: Int) {
        sp(ctx).edit().putInt("zoom", v).apply()
    }

    fun theme(ctx: Context): String = sp(ctx).getString("theme", "midnight") ?: "midnight"

    fun setTheme(ctx: Context, id: String) {
        sp(ctx).edit().putString("theme", id).apply()
    }

    /** Ana menüdeki uygulama sırası (uygulama kimlikleri). Boşsa varsayılan sıra. */
    fun order(ctx: Context): List<String> =
        (sp(ctx).getString("order", "") ?: "").split(',').filter { it.isNotBlank() }

    fun setOrder(ctx: Context, ids: List<String>) {
        sp(ctx).edit().putString("order", ids.joinToString(",")).apply()
    }
}

// Tema değişince arayüz baştan kurulur; kullanıcı aynı sayfada kalsın diye son sayfa hatırlanır.
private var rememberedPage = "general"

/** Araç ekranındaki "Ayarlar" kutusu: Genel / Tema / Sıralama sayfaları. */
class SettingsModule(private val root: RootView) : CarModule {

    override val title = "Ayarlar"

    private val countries = listOf("TR", "DE", "NL", "FR", "GB", "US", "AZ", "CY")

    private lateinit var content: FrameLayout
    private val navButtons = LinkedHashMap<String, TextView>()
    private lateinit var adBtn: TextView
    private lateinit var ccBtn: TextView
    private var selected = 0

    override fun createView(root: RootView): View {
        val c = root.context
        content = FrameLayout(c)

        val compact = root.compact
        val nav = LinearLayout(c).apply {
            // Araçta sol kenar menüsü; telefonda üstte sekme şeridi
            orientation = if (compact) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
            setPadding(c.dp(8), c.dp(8), c.dp(8), c.dp(8))
        }
        listOf("general" to "⚙  Genel", "theme" to "🎨  Tema", "order" to "↔  Sıralama").forEach { (id, label) ->
            val b = Ui.button(c, if (compact) label.replace("  ", " ") else label, if (compact) 14f else 19f) { show(id) }
            navButtons[id] = b
            nav.addView(
                b,
                if (compact) Ui.lin(0, Ui.WRAP, 1f, c.dp(3)) else Ui.lin(Ui.MATCH, Ui.WRAP, 0f, c.dp(4))
            )
        }

        val row = LinearLayout(c).apply {
            if (compact) {
                orientation = LinearLayout.VERTICAL
                addView(nav, Ui.lin(Ui.MATCH, Ui.WRAP))
                addView(content, Ui.lin(Ui.MATCH, 0, 1f))
            } else {
                orientation = LinearLayout.HORIZONTAL
                addView(nav, Ui.lin(c.dp(190), Ui.MATCH))
                addView(content, Ui.lin(0, Ui.MATCH, 1f))
            }
        }
        show(rememberedPage)
        return row
    }

    private fun show(id: String) {
        rememberedPage = id
        val c = root.context
        content.removeAllViews()
        val v = when (id) {
            "theme" -> themePage()
            "order" -> orderPage()
            else -> generalPage()
        }
        content.addView(v, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        navButtons.forEach { (k, b) ->
            b.background = Ui.round(if (k == id) Ui.ACCENT else Ui.PANEL2, c.dp(10).toFloat())
        }
    }

    // ------------------------------------------------------------------ Genel

    private fun generalPage(): View {
        val c = root.context

        val sp = if (root.compact) 16f else 20f
        adBtn = Ui.button(c, "", sp) {
            CarPrefs.setAdBlock(c, !CarPrefs.adBlock(c))
            refreshGeneral()
            root.toast("Değişiklik, uygulamayı kapatıp açınca geçerli olur")
        }
        ccBtn = Ui.button(c, "", sp) {
            val cur = CarPrefs.radioCountry(c)
            val next = countries[(countries.indexOf(cur) + 1) % countries.size]
            CarPrefs.setRadioCountry(c, next)
            refreshGeneral()
            root.toast("Radyo > Yerel sekmesi $next istasyonlarını gösterecek")
        }
        val cookieBtn = Ui.button(c, "Web oturumlarını sil (çerezler)", sp) {
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
            root.toast("Oturumlar silindi")
        }
        val about = Ui.label(
            c,
            "Reklam engelleme en iyi çabayla çalışır; YouTube değiştikçe bozulabilir. " +
                    "Yazı girişi için sayfadaki bir kutuya dokununca ekran klavyesi açılır. " +
                    "Radyo istasyonlarını ve IPTV listesini telefondaki uygulamadan yönetirsin.",
            15f,
            Ui.MUTED
        )

        val col = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(c.dp(14), c.dp(10), c.dp(14), c.dp(10))
            addView(adBtn, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, c.dp(5)))
            addView(ccBtn, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, c.dp(5)))
            addView(cookieBtn, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, c.dp(5)))
            if (root.isPhone) {
                // Telefonda kurulum ekranlarına buradan ulaşılır
                addView(
                    Ui.button(c, "📻  Radyo istasyonlarını düzenle", sp) {
                        c.startActivity(Intent(c, RadioEditActivity::class.java))
                    },
                    Ui.lin(Ui.MATCH, Ui.WRAP, 0f, c.dp(5))
                )
                addView(
                    Ui.button(c, "📺  IPTV ayarları", sp) {
                        c.startActivity(Intent(c, IptvSettingsActivity::class.java))
                    },
                    Ui.lin(Ui.MATCH, Ui.WRAP, 0f, c.dp(5))
                )
                addView(
                    Ui.button(c, "🚗  Kurulum, izinler, araç yansıtma", sp) {
                        c.startActivity(Intent(c, MainActivity::class.java))
                    },
                    Ui.lin(Ui.MATCH, Ui.WRAP, 0f, c.dp(5))
                )
            }
            addView(about, Ui.lin(Ui.MATCH, Ui.WRAP).apply { topMargin = c.dp(14) })
        }
        refreshGeneral()
        return ScrollView(c).apply { addView(col) }
    }

    private fun refreshGeneral() {
        val c = root.context
        adBtn.text = "Reklam engelleme: " + if (CarPrefs.adBlock(c)) "AÇIK" else "KAPALI"
        ccBtn.text = "Yerel radyo ülkesi: " + CarPrefs.radioCountry(c) + "  (değiştirmek için dokun)"
    }

    // ------------------------------------------------------------------- Tema

    private fun themePage(): View {
        val c = root.context
        val grid = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(c.dp(10), c.dp(10), c.dp(10), c.dp(10))
        }
        val cols = if (root.compact) 2 else 3
        Themes.all.chunked(cols).forEach { rowThemes ->
            val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
            rowThemes.forEach { t -> row.addView(themeCard(t), Ui.lin(0, Ui.MATCH, 1f, c.dp(6))) }
            repeat(cols - rowThemes.size) { row.addView(View(c), Ui.lin(0, Ui.MATCH, 1f, c.dp(6))) }
            grid.addView(row, Ui.lin(Ui.MATCH, 0, 1f))
        }
        return grid
    }

    private fun themeCard(t: Theme): View {
        val c = root.context
        val sel = t.id == CarPrefs.theme(c)
        val card = GradientDrawable().apply {
            setColor(t.panel)
            cornerRadius = c.dp(16).toFloat()
            setStroke(c.dp(if (sel) 3 else 1), if (sel) t.accent else 0x33FFFFFF)
        }
        val swatches = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            listOf(t.bg, t.panel2, t.accent).forEach { color ->
                val chip = View(c).apply {
                    background = GradientDrawable().apply {
                        setColor(color)
                        cornerRadius = c.dp(8).toFloat()
                        setStroke(c.dp(1), 0x55FFFFFF)
                    }
                }
                addView(chip, Ui.lin(c.dp(30), c.dp(30), 0f, c.dp(3)))
            }
        }
        return LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = card
            isClickable = true
            addView(swatches, Ui.lin(Ui.WRAP, Ui.WRAP))
            addView(
                Ui.label(c, (if (sel) "✓ " else "") + t.name, 17f, bold = true).apply {
                    gravity = Gravity.CENTER
                },
                Ui.lin(Ui.WRAP, Ui.WRAP).apply { topMargin = c.dp(10) }
            )
            setOnClickListener {
                if (!sel) {
                    CarPrefs.setTheme(c, t.id)
                    Themes.apply(t.id)
                    root.host.restartUi("settings")
                }
            }
        }
    }

    // --------------------------------------------------------------- Sıralama

    private fun orderPage(): View {
        val c = root.context
        val apps = Apps.ordered(c)
        if (selected !in apps.indices) selected = 0

        val info = Ui.label(
            c,
            "Bir uygulamaya dokun, sonra ◀ ▶ ile yerini değiştir. Ana menüde bu sırayla görünür.",
            15f,
            Ui.MUTED
        ).apply { setPadding(c.dp(10), c.dp(8), c.dp(10), c.dp(4)) }

        val grid = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(c.dp(6), c.dp(4), c.dp(6), c.dp(4))
        }
        var index = 0
        val cols = if (root.compact) 3 else 5
        apps.chunked(cols).forEach { rowApps ->
            val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
            rowApps.forEach { app ->
                row.addView(miniTile(app, index), Ui.lin(0, Ui.MATCH, 1f, c.dp(4)))
                index++
            }
            repeat(cols - rowApps.size) { row.addView(View(c), Ui.lin(0, Ui.MATCH, 1f, c.dp(4))) }
            grid.addView(row, Ui.lin(Ui.MATCH, 0, 1f))
        }

        val controls = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(c.dp(6), c.dp(4), c.dp(6), c.dp(8))
            val csp = if (root.compact) 14f else 18f
            addView(Ui.button(c, "◀ Sola al", csp) { move(-1) }, Ui.lin(0, Ui.WRAP, 1f, c.dp(4)))
            addView(Ui.button(c, "Sağa al ▶", csp) { move(1) }, Ui.lin(0, Ui.WRAP, 1f, c.dp(4)))
            addView(Ui.button(c, "↺ Varsayılan", csp) { resetOrder() }, Ui.lin(0, Ui.WRAP, 1f, c.dp(4)))
        }

        return LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            addView(info, Ui.lin(Ui.MATCH, Ui.WRAP))
            addView(grid, Ui.lin(Ui.MATCH, 0, 1f))
            addView(controls, Ui.lin(Ui.MATCH, Ui.WRAP))
        }
    }

    private fun miniTile(app: App, index: Int): View {
        val c = root.context
        val sel = index == selected
        val bg = GradientDrawable().apply {
            setColor(Ui.PANEL)
            cornerRadius = c.dp(14).toFloat()
            setStroke(c.dp(if (sel) 3 else 1), if (sel) Ui.ACCENT else 0x33FFFFFF)
        }
        val icon = TextView(c).apply {
            text = app.glyph
            textSize = 22f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            background = Ui.gradient(app.c1, app.c2, c.dp(12).toFloat())
        }
        return LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = bg
            isClickable = true
            addView(icon, LinearLayout.LayoutParams(c.dp(46), c.dp(46)))
            addView(
                Ui.label(c, "${index + 1}. ${app.label}", 13f, bold = true).apply {
                    gravity = Gravity.CENTER
                    isSingleLine = true
                    ellipsize = TextUtils.TruncateAt.END
                },
                Ui.lin(Ui.WRAP, Ui.WRAP).apply { topMargin = c.dp(6) }
            )
            setOnClickListener {
                selected = index
                show("order")
            }
        }
    }

    private fun move(delta: Int) {
        val c = root.context
        val ids = Apps.ordered(c).map { it.id }.toMutableList()
        val target = selected + delta
        if (selected !in ids.indices || target !in ids.indices) return
        val tmp = ids[selected]
        ids[selected] = ids[target]
        ids[target] = tmp
        CarPrefs.setOrder(c, ids)
        selected = target
        show("order")
    }

    private fun resetOrder() {
        CarPrefs.setOrder(root.context, emptyList())
        selected = 0
        show("order")
    }
}
