package com.example.carmirror

import android.content.Context
import android.content.Intent
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/**
 * Müzik/radyo/IPTV'nin paylaştığı ExoPlayer için medya oturumu:
 * - bildirimde ⏮ ⏯ ⏭ düğmeleri, uygulama kapalıyken/ekran kilitliyken çalmaya devam
 * - Android Auto / direksiyon / kulaklık medya tuşları oturuma gider
 */
class PlaybackService : MediaSessionService() {

    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        val player = PlayerHolder.peek() ?: PlayerHolder.get(this)
        session = MediaSession.Builder(this, player).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onDestroy() {
        try {
            session?.release()
        } catch (_: Exception) {
        }
        session = null
        if (instance === this) instance = null
        super.onDestroy()
    }

    companion object {
        @Volatile
        var instance: PlaybackService? = null

        fun start(ctx: Context) {
            try {
                val app = ctx.applicationContext
                app.startService(Intent(app, PlaybackService::class.java))
            } catch (_: Exception) {
                // arka plandan başlatma kısıtlıysa sessizce geç
            }
        }

        /** Oynatıcı bırakılmadan önce çağrılır. */
        fun stop() {
            val s = instance ?: return
            try {
                s.session?.release()
            } catch (_: Exception) {
            }
            s.session = null
            s.stopSelf()
        }
    }
}
