package com.example.carmirror

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.TextUtils
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

fun Context.dp(n: Int): Int = (n * resources.displayMetrics.density + 0.5f).toInt()

/** Araç ekranındaki tüm arayüzün ortak renk ve bileşen yardımcıları (XML kullanılmıyor). */
object Ui {
    // Renkler seçilen temaya göre değişir (Themes.apply / applyTheme).
    var BG = 0xFF070B1F.toInt()
    var PANEL = 0xFF111A3A.toInt()
    var PANEL2 = 0xFF1B2757.toInt()
    var ACCENT = 0xFF3B82F6.toInt()
    var MUTED = 0xFFA9B4D6.toInt()
    var HOME_TOP = 0xFF0E1A44.toInt()
    var HOME_BOTTOM = 0xFF060A1C.toInt()
    val TEXT = Color.WHITE

    fun applyTheme(t: Theme) {
        BG = t.bg
        PANEL = t.panel
        PANEL2 = t.panel2
        ACCENT = t.accent
        MUTED = t.muted
        HOME_TOP = t.homeTop
        HOME_BOTTOM = t.homeBottom
    }

    /** CSS için #RRGGBB */
    fun cssHex(color: Int): String = String.format("#%06X", color and 0xFFFFFF)

    const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    fun round(color: Int, radiusPx: Float): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radiusPx
        }

    /** Köşeden köşeye iki renkli yuvarlak kare (uygulama ikonu görünümü). */
    fun gradient(c1: Int, c2: Int, radiusPx: Float): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c1, c2)).apply {
            cornerRadius = radiusPx
        }

    fun label(
        ctx: Context,
        text: String,
        sp: Float = 18f,
        color: Int = TEXT,
        bold: Boolean = false
    ): TextView = TextView(ctx).apply {
        this.text = text
        textSize = sp
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    fun button(
        ctx: Context,
        text: String,
        sp: Float = 20f,
        bg: Int = PANEL2,
        onClick: () -> Unit
    ): TextView = TextView(ctx).apply {
        this.text = text
        textSize = sp
        setTextColor(TEXT)
        gravity = Gravity.CENTER
        background = round(bg, ctx.dp(10).toFloat())
        minHeight = ctx.dp(52)
        minimumWidth = ctx.dp(52)
        setPadding(ctx.dp(14), ctx.dp(6), ctx.dp(14), ctx.dp(6))
        isClickable = true
        setOnClickListener { onClick() }
    }

    fun lin(w: Int, h: Int, weight: Float = 0f, margin: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(w, h, weight).apply { setMargins(margin, margin, margin, margin) }

    /** Listeler için ▲ ▼ sayfa düğmeleri (kaydırma hareketi güvenilir olmayabilir). */
    fun pager(ctx: Context, list: RecyclerView): LinearLayout =
        LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(
                button(ctx, "▲", 22f) { list.smoothScrollBy(0, -(list.height * 0.8f).toInt()) },
                lin(0, WRAP, 1f, ctx.dp(3))
            )
            addView(
                button(ctx, "▼", 22f) { list.smoothScrollBy(0, (list.height * 0.8f).toInt()) },
                lin(0, WRAP, 1f, ctx.dp(3))
            )
        }

    fun formatTime(ms: Long): String {
        if (ms < 0) return "--:--"
        val s = ms / 1000
        return String.format("%d:%02d", s / 60, s % 60)
    }
}

/** Liste satırı: başlık, alt başlık ve sağda isteğe bağlı eylem düğmesi. */
class ListRow(ctx: Context) : LinearLayout(ctx) {
    val title = Ui.label(ctx, "", 20f, bold = true)
    val subtitle = Ui.label(ctx, "", 14f, Ui.MUTED)
    val action = Ui.button(ctx, "", 22f, Ui.PANEL2) { }

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(ctx.dp(12), ctx.dp(6), ctx.dp(8), ctx.dp(6))
        title.isSingleLine = true
        title.ellipsize = TextUtils.TruncateAt.END
        subtitle.isSingleLine = true
        subtitle.ellipsize = TextUtils.TruncateAt.END
        val col = LinearLayout(ctx).apply {
            orientation = VERTICAL
            addView(title)
            addView(subtitle)
        }
        addView(col, LayoutParams(0, Ui.WRAP, 1f))
        addView(action, LayoutParams(Ui.WRAP, Ui.WRAP))
        isClickable = true
        setSelectedRow(false)
    }

    fun setSelectedRow(selected: Boolean) {
        background = Ui.round(if (selected) Ui.ACCENT else Ui.PANEL, context.dp(10).toFloat())
    }

    fun setAction(text: String?, onClick: (() -> Unit)? = null) {
        if (text.isNullOrEmpty()) {
            action.visibility = GONE
        } else {
            action.visibility = VISIBLE
            action.text = text
            action.setOnClickListener { onClick?.invoke() }
        }
    }
}

class RowAdapter<T>(private val bind: (ListRow, T, Int) -> Unit) :
    RecyclerView.Adapter<RowAdapter.VH>() {

    class VH(val row: ListRow) : RecyclerView.ViewHolder(row)

    var items: List<T> = emptyList()
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val r = ListRow(parent.context)
        r.layoutParams = RecyclerView.LayoutParams(Ui.MATCH, Ui.WRAP).apply {
            setMargins(0, 0, 0, parent.context.dp(4))
        }
        return VH(r)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        bind(holder.row, items[position], position)
    }
}

object Perms {
    fun has(ctx: Context, p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    fun hasAudio(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 33) has(ctx, Manifest.permission.READ_MEDIA_AUDIO)
        else has(ctx, Manifest.permission.READ_EXTERNAL_STORAGE)

    fun hasVisual(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 33)
            has(ctx, Manifest.permission.READ_MEDIA_IMAGES) && has(ctx, Manifest.permission.READ_MEDIA_VIDEO)
        else has(ctx, Manifest.permission.READ_EXTERNAL_STORAGE)

    fun requestList(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) arrayOf(
            Manifest.permission.READ_MEDIA_AUDIO,
            Manifest.permission.READ_MEDIA_IMAGES,
            Manifest.permission.READ_MEDIA_VIDEO,
            Manifest.permission.POST_NOTIFICATIONS
        ) else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
}
