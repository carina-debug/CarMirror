# Araç Ekranı (CarMirror) – kişisel Android Auto uygulaması

Android Auto'nun araç ekranında kendi arayüzünü çizer. Modüller:

| Modül | Ne yapar |
|---|---|
| ▶ YouTube / ☺ YouTube Kids / ♫ YouTube Music | Reklam engelleme açık web uygulamaları. Arama kutusuna dokununca ekran klavyesi çıkar |
| 🌐 Tarayıcı | Adres/arama çubuğu, hızlı erişim sayfası, yazı boyutu, tam ekran video |
| ⚙ Ayarlar | **Genel** (reklam engelleme, yerel radyo ülkesi, oturumları silme), **Tema** (6 tema: Gece Mavisi, Mor Gece, Orman, Gün Batımı, Okyanus, Karbon), **Sıralama** (ana menüdeki uygulamaları ◀ ▶ ile yeniden sırala) |
| 🎵 Müzik | Telefondaki müzikler (albüm kapağı, karıştır/tekrar, ilerleme çubuğu) |
| 📻 Radyo | Açılışta yerel (ülke) radyoları, favoriler (telefondan düzenlenir) ve ada göre arama (radio-browser.info) |
| 🖼 Galeri | Fotoğraf/video ızgarası, tam ekran görüntüleyici, slayt gösterisi, video oynatma |
| 📺 IPTV | M3U veya Xtream bilgisiyle canlı kanallar, grup/arama/favori, tam ekran, 2x2 çoklu ekran |
| 📱 Telefon ekranı | Telefon ekranını araca yansıtır, dokunmayı telefona geri iletir (isteğe bağlı) |

## Nasıl çalışır
1. `CarMirrorService` Android Auto'ya **navigasyon uygulaması** olarak kayıt olur ve araç ekranının ham `Surface`'ini alır.
2. `CarUiHost` bu yüzeye bağlı kendi `VirtualDisplay`'ini açar ve üzerinde bir `Presentation` (ana menü + modüller) gösterir. Telefon ekranı kapalıyken de çalışır.
3. Araçtan gelen `onClick/onScroll` olayları `MotionEvent`'e çevrilip bu pencereye verilir. (Sistem klavyesi sanal ekranda çıkmadığı için `CarKeyboard` var.)
4. "Telefon ekranı" kutusu ise yüzeyi `MirrorBridge`'e (MediaProjection) devreder; dokunmalar `TouchForwardService` ile telefona uygulanır.

## Kurulum
1. Android Studio ile `CarMirror` klasörünü aç, Gradle sync bitsin (JDK 17).
2. Telefonu USB hata ayıklama ile bağla → Run (veya Build > Build APK).
3. Telefonda uygulamayı aç → **Medya izinlerini ver** (müzik/galeri için; ilk açılışta otomatik sorulur, sonra Ayarlar > Genel > Kurulum'dan).
4. İstersen: **Radyo istasyonlarını düzenle** ve **IPTV ayarları** (M3U adresi veya Xtream sunucu/kullanıcı/şifre).
5. Android Auto ayarları → en alta in, "Sürüm" yazısına 10 kez dokun → ⋮ menüsü > **Geliştirici ayarları** → **Bilinmeyen kaynaklar**'ı aç.
6. Arabaya bağlan, Android Auto uygulama listesinden **Araç Ekranı**'nı aç.

Yalnızca "Telefon ekranı" kutusu için: erişilebilirlik ayarlarından "Araç Ekranı Dokunma İletimi"ni aç
(Android 13+ yan yüklemede gri ise: Ayarlar > Uygulamalar > Araç Ekranı > ⋮ > *Kısıtlı ayarlara izin ver*), sonra **Yansıtmayı başlat** → "Tüm ekran".

## Telefonda kullanım
Uygulama ikonuna dokununca telefonda da **aynı kart menüsü ve modüller** açılır (araca bağlanmak gerekmez).

- Dikey ekrana göre uyarlanmıştır: ana menü 3 sütun (kaydırılır), Ayarlar'da üst sekmeler, Müzik/IPTV'de üstte oynatıcı + altta liste, Galeri 3 sütun.
- Yazı girişinde telefonun kendi klavyesi kullanılır; Tarayıcı/YouTube mobil site olarak açılır, parmakla kaydırma ve sıkıştırarak yakınlaştırma çalışır.
- Tam ekran video ve IPTV tam ekranı otomatik yatay moda geçer; çıkınca dikeye döner.
- Ana menüdeyken geri tuşu uygulamadan çıkar. "Telefon ekranı" kutusu telefonda gizlenir (yalnızca araç içindir).
- Radyo istasyonları, IPTV ayarları ve kurulum/izin/yansıtma ekranına **Ayarlar > Genel** içinden ulaşılır.
- İlk açılışta medya izinleri istenir. Uygulama kapatılınca çalan ses de durur (araç bağlıysa durmaz).

## Yeni özellikler (3.3)
- **Ana menü widget'ları:** saat/tarih, hava durumu (Open-Meteo, yaklaşık konum; karta dokununca yenilenir), çalan parça (⏯ ⏭) ve en sık açtığın 3 kart.
- **"Şu an çalıyor" şeridi:** Müzik/Radyo/IPTV dışındaki her modülde üstte çalan parça + ⏯ ⏭. Mesaj bildirimleri de burada 8 sn gösterilir (dokununca kapanır).
- **Medya oturumu (`PlaybackService`):** bildirimde kontroller, uygulama kapalı/ekran kilitliyken çalmaya devam, direksiyon / Android Auto / kulaklık medya tuşları.
- **Mesaj şeridi:** Ayarlar > Genel > "Mesaj şeridi için bildirim erişimi" ile açılır (yalnızca mesaj/e-posta/arama bildirimleri okunur, saklanmaz).
- **Tema:** "Gündüz" teması + otomatik gündüz/gece (07–19 gündüz; geceleri seçili tema; yalnızca ana menüdeyken değişir) ve **Büyük yazı modu** (Ayarlar > Genel).
- **Navigasyon kartı:** Google Haritalar veya Waze'i açar (Ayarlar'dan seçilir). Araç bağlıyken bazı telefonlar arka plandan uygulama açmayı engelleyebilir.
- **Sesle arama:** Klavyedeki 🎤 ile söyle, otomatik gönderilir (YouTube, Tarayıcı, Radyo, IPTV aramaları). Mikrofon izni telefonda bir kez verilir.
- **Telefon yatay / tablet:** Döndürme desteklenir; geniş ekranlarda araç düzeni, alçak (yatay telefon) ekranda küçültülmüş widget'lar kullanılır.

## Araç eylem çubuğu
◀ Geri · ⌂ Ana menü · ✕ Çıkış. Telefon ekranı modunda ◀ telefonun geri tuşudur, ⌂ ana menüye döner.

## Reklam engelleme ve web uygulamaları hakkında
- Reklam engelleme en iyi çabayla çalışır (reklam sunucularını keser, YouTube oynatıcı yanıtlarındaki reklam alanlarını siler, kalan reklamı sona sarar). YouTube sık değiştiği için zamanla bozulabilir; o zaman `AdBlock.kt` güncellenir.
- Şifre alanları ekran klavyesine bağlanmaz. Google, uygulama içi WebView'dan girişi engelleyebilir; YouTube'u giriş yapmadan kullanmak en sorunsuzu.
- YouTube'un kullanım şartları reklam engellemeyi desteklemez; hesabınla giriş yapıyorsan bu risk sende.

## Sorun giderme
- **Uygulama Android Auto'da görünmüyor:** Bilinmeyen kaynaklar açık mı? Android Auto > Ayarlar > "Başlatıcıyı özelleştir" içinde işaretli mi? Android Auto'yu zorla durdurup arabayı yeniden bağla.
- **Araç ekranı siyah / çöküyor:** Logcat'te `CarUiHost` ve `Presentation` hatalarına bak. Sanal ekran oluşturma bazı telefonlarda kısıtlı olabilir.
- **Kaydırma çalışmıyor:** Araç sürükleme olaylarını göndermeyebilir. Tüm listelerde ▲ ▼ düğmeleri var; tarayıcıda da ▲ ▼ sayfa kaydırır. Yön ters ise `CarUiHost.scroll` içinde `dx/dy` işaretini çevir (telefon ekranı modu için `MirrorBridge.SCROLL_SIGN`).
- **Siyah bantlar (telefon ekranı modu):** Telefonu yatay çevir.
- **Radyo/IPTV oynamıyor:** Adres http ise sorun yok (cleartext açık). Bazı IPTV sağlayıcıları belirli User-Agent ister; `PlayerHolder` içindeki User-Agent'ı değiştir.
- **Müzik/Galeri boş:** Medya izinleri verildi mi? (Android 14'te "seçili fotoğraflar" yerine "tümüne izin ver" seç.)

## Not
- Sürüş sırasında video izlemek tehlikelidir ve birçok ülkede yasaktır; video/IPTV/tarayıcıyı yalnızca park halindeyken kullan.
- Bu proje kişisel/debug kullanım içindir (`HostValidator.ALLOW_ALL_HOSTS_VALIDATOR`). Play Store'a konamaz.
- Telif/erişim hakkın olmayan IPTV listelerini kullanma.

## Güncelleme (kaldırmadan üzerine kurma) ve imza anahtarı
Uygulama sabit bir anahtarla imzalanır; `applicationId` aynı kaldığı ve `versionCode` her sürümde artırıldığı sürece yeni APK eskisinin üzerine kurulur. **Anahtar ve şifreler repoda tutulmaz** (`.gitignore` `*.jks` dosyalarını dışlar).

**GitHub Actions (önerilen):** Repo > Settings > Secrets and variables > Actions > *New repository secret* ile şunları ekle:

| Secret | Değer |
|---|---|
| `KEYSTORE_BASE64` | `.jks` dosyasının base64 çıktısı (`base64 -w0 carmirror.jks`) |
| `KEYSTORE_PASSWORD` | anahtar deposu şifresi |
| `KEY_ALIAS` | anahtar takma adı |
| `KEY_PASSWORD` | anahtar şifresi |

Sonra her `push`'ta `.github/workflows/build.yml` APK'yı derleyip **Actions > Artifacts** altına koyar.

**Yerelde:** `.jks` dosyasını bir yere koy ve `~/.gradle/gradle.properties` içine (repoya değil) `CM_KEYSTORE_PATH`, `CM_STORE_PASSWORD`, `CM_KEY_ALIAS`, `CM_KEY_PASSWORD` satırlarını yaz. Verilmezse debug anahtarıyla imzalanır; bu durumda GitHub'dan gelen APK'nın üzerine kurulamaz (imza farklı).

## Simgeleri değiştirme
**Ayarlar > Simgeler:** üstten bir uygulama seç, altından simgesini seç (varsayılan, ⭐ ❤ 🎮 🚗 🎧 📷 🏠 🔥; YouTube Kids için ayrıca resmi görünümlü simge, varsayılan odur). "Tüm simgeleri varsayılana döndür" düğmesi hepsini sıfırlar. YouTube Kids'in resmi simgesi `res/drawable/ic_kids.xml`'dir; kendi PNG'ni kullanmak istersen bu dosyayı silip `ic_kids.png` ekle.

## Video görüntüsü
**Ayarlar > Genel > Video görüntüsü** düğmesi dokundukça döner: Sığdır (varsayılan) → Doldur (kenarlar kırpılır) → Uzat → 16:9 → 4:3. Galeri videoları ve IPTV (tekli ve çoklu ekran) bu ayarı kullanır. YouTube/Tarayıcı videoları web sayfası olduğu için etkilenmez.

## Güncelleme denetimi
**Ayarlar > Genel > Güncellemeleri denetle** GitHub'daki son yayına (Release) bakar; yeni sürüm varsa düğme "indirmek için dokun" olur ve APK bağlantısını açar. Gereksinimler:
- Depo **herkese açık (Public)** olmalı (özel depolarda API 404 döner). Anahtar Secrets'ta olduğu için bu güvenlidir.
- Yeni sürüm için `app/build.gradle.kts` içinde `versionCode`/`versionName`'i artır, push'la, sonra GitHub'da **Releases > Draft a new release** ile `v3.6` gibi (versionName ile aynı) bir etiket oluşturup yayımla. Actions APK'yı derleyip yayına ekler.
- Depo adı derlemeye Actions'tan otomatik gömülür; yerel derlemede `gradle.properties` içine `CM_UPDATE_REPO=kullanici/CarMirror` yaz.
