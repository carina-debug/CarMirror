# Araç Ekranı (CarMirror) – kişisel Android Auto uygulaması

Android Auto'nun araç ekranında kendi arayüzünü çizer. Modüller:

| Modül | Ne yapar |
|---|---|
| ▶ YouTube / ☺ YouTube Kids / ♫ YouTube Music | Reklam engelleme açık web uygulamaları. Arama kutusuna dokununca ekran klavyesi çıkar |
| 🌐 Tarayıcı | Adres/arama çubuğu, hızlı erişim sayfası, yazı boyutu, tam ekran video |
| ⚙ Ayarlar | **Genel** (reklam engelleme, yerel radyo ülkesi, oturumları silme), **Tema** (6 tema: Gece Mavisi, Mor Gece, Orman, Gün Batımı, Okyanus, Karbon), **Sıralama** (ana menüdeki uygulamaları ◀ ▶ ile yeniden sırala) |
| 🎵 Müzik | Telefondaki müzikler (albüm kapağı, karıştır/tekrar, ilerleme çubuğu) |
| 📻 Radyo | Açılışta yerel (ülke) radyoları, favoriler (telefondan düzenlenir) ve ada göre arama (radio-browser.info) |
| 🖼 Galeri | Fotoğraf/video ızgarası, tam ekran görüntüleyici, slayt gösterisi, video oynatma |
| 📺 IPTV | M3U veya Xtream bilgisiyle canlı kanallar, grup/arama/favori, tam ekran, 2x2 çoklu ekran |
| 📱 Telefon ekranı | Telefon ekranını araca yansıtır, dokunmayı telefona geri iletir (isteğe bağlı) |

## Nasıl çalışır
1. `CarMirrorService` Android Auto'ya **navigasyon uygulaması** olarak kayıt olur ve araç ekranının ham `Surface`'ini alır.
2. `CarUiHost` bu yüzeye bağlı kendi `VirtualDisplay`'ini açar ve üzerinde bir `Presentation` (ana menü + modüller) gösterir. Telefon ekranı kapalıyken de çalışır.
3. Araçtan gelen `onClick/onScroll` olayları `MotionEvent`'e çevrilip bu pencereye verilir. (Sistem klavyesi sanal ekranda çıkmadığı için `CarKeyboard` var.)
4. "Telefon ekranı" kutusu ise yüzeyi `MirrorBridge`'e (MediaProjection) devreder; dokunmalar `TouchForwardService` ile telefona uygulanır.

## Kurulum
1. Android Studio ile `CarMirror` klasörünü aç, Gradle sync bitsin (JDK 17).
2. Telefonu USB hata ayıklama ile bağla → Run (veya Build > Build APK).
3. Telefonda uygulamayı aç → **Medya izinlerini ver** (müzik/galeri için; ilk açılışta otomatik sorulur, sonra Ayarlar > Genel > Kurulum'dan).
4. İstersen: **Radyo istasyonlarını düzenle** ve **IPTV ayarları** (M3U adresi veya Xtream sunucu/kullanıcı/şifre).
5. Android Auto ayarları → en alta in, "Sürüm" yazısına 10 kez dokun → ⋮ menüsü > **Geliştirici ayarları** → **Bilinmeyen kaynaklar**'ı aç.
6. Arabaya bağlan, Android Auto uygulama listesinden **Araç Ekranı**'nı aç.

Yalnızca "Telefon ekranı" kutusu için: erişilebilirlik ayarlarından "Araç Ekranı Dokunma İletimi"ni aç
(Android 13+ yan yüklemede gri ise: Ayarlar > Uygulamalar > Araç Ekranı > ⋮ > *Kısıtlı ayarlara izin ver*), sonra **Yansıtmayı başlat** → "Tüm ekran".

## Telefonda kullanım
Uygulama ikonuna dokununca telefonda da **aynı kart menüsü ve modüller** açılır (araca bağlanmak gerekmez).

- Dikey ekrana göre uyarlanmıştır: ana menü 3 sütun (kaydırılır), Ayarlar'da üst sekmeler, Müzik/IPTV'de üstte oynatıcı + altta liste, Galeri 3 sütun.
- Yazı girişinde telefonun kendi klavyesi kullanılır; Tarayıcı/YouTube mobil site olarak açılır, parmakla kaydırma ve sıkıştırarak yakınlaştırma çalışır.
- Tam ekran video ve IPTV tam ekranı otomatik yatay moda geçer; çıkınca dikeye döner.
- Ana menüdeyken geri tuşu uygulamadan çıkar. "Telefon ekranı" kutusu telefonda gizlenir (yalnızca araç içindir).
- Radyo istasyonları, IPTV ayarları ve kurulum/izin/yansıtma ekranına **Ayarlar > Genel** içinden ulaşılır.
- İlk açılışta medya izinleri istenir. Uygulama kapatılınca çalan ses de durur (araç bağlıysa durmaz).

## Araç eylem çubuğu
◀ Geri · ⌂ Ana menü · ✕ Çıkış. Telefon ekranı modunda ◀ telefonun geri tuşudur, ⌂ ana menüye döner.

## Reklam engelleme ve web uygulamaları hakkında
- Reklam engelleme en iyi çabayla çalışır (reklam sunucularını keser, YouTube oynatıcı yanıtlarındaki reklam alanlarını siler, kalan reklamı sona sarar). YouTube sık değiştiği için zamanla bozulabilir; o zaman `AdBlock.kt` güncellenir.
- Şifre alanları ekran klavyesine bağlanmaz. Google, uygulama içi WebView'dan girişi engelleyebilir; YouTube'u giriş yapmadan kullanmak en sorunsuzu.
- YouTube'un kullanım şartları reklam engellemeyi desteklemez; hesabınla giriş yapıyorsan bu risk sende.

## Sorun giderme
- **Uygulama Android Auto'da görünmüyor:** Bilinmeyen kaynaklar açık mı? Android Auto > Ayarlar > "Başlatıcıyı özelleştir" içinde işaretli mi? Android Auto'yu zorla durdurup arabayı yeniden bağla.
- **Araç ekranı siyah / çöküyor:** Logcat'te `CarUiHost` ve `Presentation` hatalarına bak. Sanal ekran oluşturma bazı telefonlarda kısıtlı olabilir.
- **Kaydırma çalışmıyor:** Araç sürükleme olaylarını göndermeyebilir. Tüm listelerde ▲ ▼ düğmeleri var; tarayıcıda da ▲ ▼ sayfa kaydırır. Yön ters ise `CarUiHost.scroll` içinde `dx/dy` işaretini çevir (telefon ekranı modu için `MirrorBridge.SCROLL_SIGN`).
- **Siyah bantlar (telefon ekranı modu):** Telefonu yatay çevir.
- **Radyo/IPTV oynamıyor:** Adres http ise sorun yok (cleartext açık). Bazı IPTV sağlayıcıları belirli User-Agent ister; `PlayerHolder` içindeki User-Agent'ı değiştir.
- **Müzik/Galeri boş:** Medya izinleri verildi mi? (Android 14'te "seçili fotoğraflar" yerine "tümüne izin ver" seç.)

## Not
- Sürüş sırasında video izlemek tehlikelidir ve birçok ülkede yasaktır; video/IPTV/tarayıcıyı yalnızca park halindeyken kullan.
- Bu proje kişisel/debug kullanım içindir (`HostValidator.ALLOW_ALL_HOSTS_VALIDATOR`). Play Store'a konamaz.
- Telif/erişim hakkın olmayan IPTV listelerini kullanma.

## Güncelleme (kaldırmadan üzerine kurma)
Uygulama sabit bir anahtarla (`app/keystore/carmirror.jks`) imzalanır; `applicationId` aynı kaldığı ve `versionCode` her sürümde artırıldığı sürece yeni APK eskisinin üzerine kurulur. **Not:** Daha önce başka bir anahtarla kurduysan, bu anahtarlı ilk sürüm için bir kez kaldırman gerekir; sonrası hep güncelleme olur. Repo herkese açıksa bu anahtarı ayrı tut (kişisel kullanım için sorun değil).
