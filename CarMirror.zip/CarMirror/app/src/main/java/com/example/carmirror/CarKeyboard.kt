package com.example.carmirror

import android.content.Context
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

/**
 * Araç ekranı penceresinde sistem klavyesi açılmadığı için kendi ekran klavyemiz.
 * Türkçe harfler (ç ğ ı ö ş ü) dahil.
 */
class CarKeyboard(ctx: Context) : LinearLayout(ctx) {

    private val buf = StringBuilder()
    private val preview = Ui.label(ctx, "", 22f)
    private var hint = ""
    private var onDone: ((String) -> Unit)? = null

    /** 🎤 düğmesi: RootView ses tanımayı bağlar. */
    var onMic: (() -> Unit)? = null
    private var shift = false
    private val letters = ArrayList<Pair<TextView, String>>()
    private val tr = Locale("tr", "TR")

    init {
        orientation = VERTICAL
        setBackgroundColor(Ui.PANEL)
        setPadding(ctx.dp(8), ctx.dp(8), ctx.dp(8), ctx.dp(8))
        visibility = GONE
        isClickable = true // dokunuşları alttaki içeriğe geçirme

        val top = LinearLayout(ctx).apply {
            orientation = HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        preview.background = Ui.round(Ui.BG, ctx.dp(8).toFloat())
        preview.setPadding(ctx.dp(12), ctx.dp(10), ctx.dp(12), ctx.dp(10))
        preview.isSingleLine = true
        top.addView(preview, Ui.lin(0, Ui.WRAP, 1f, ctx.dp(3)))
        top.addView(Ui.button(ctx, "🎤", 16f) { onMic?.invoke() }, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, ctx.dp(3)))
        top.addView(Ui.button(ctx, "Temizle", 16f) { buf.setLength(0); refresh() }, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, ctx.dp(3)))
        top.addView(Ui.button(ctx, "İptal", 16f) { hide() }, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, ctx.dp(3)))
        addView(top, Ui.lin(Ui.MATCH, Ui.WRAP))

        row {
            "1234567890".forEach { addChar(it.toString()) }
            addKey("⌫", 1.5f) { backspace() }
        }
        row { "qwertyuıopğü".forEach { addLetter(it.toString()) } }
        row { "asdfghjklşi".forEach { addLetter(it.toString()) } }
        row {
            addKey("⇧", 1.5f) { shift = !shift; applyShift() }
            "zxcvbnmöç".forEach { addLetter(it.toString()) }
        }
        row { "/:.-_?&=%@#".forEach { addChar(it.toString()) } }
        row {
            addKey(".com", 1.5f) { type(".com") }
            addKey("boşluk", 5f) { type(" ") }
            addKey("Git", 2f, Ui.ACCENT) { onDone?.invoke(buf.toString()) }
        }
    }

    fun show(initial: String, hint: String, onDone: (String) -> Unit) {
        this.hint = hint
        this.onDone = onDone
        buf.setLength(0)
        buf.append(initial)
        shift = false
        applyShift()
        refresh()
        visibility = View.VISIBLE
        bringToFront()
    }

    /** Sesle yazılan metni doğrudan gönder. */
    fun submitText(s: String) {
        onDone?.invoke(s)
    }

    fun hide() {
        visibility = View.GONE
        onDone = null
    }

    private fun row(build: LinearLayout.() -> Unit) {
        val r = LinearLayout(context).apply { orientation = HORIZONTAL }
        r.build()
        addView(r, Ui.lin(Ui.MATCH, Ui.WRAP))
    }

    private fun LinearLayout.addKey(
        label: String,
        weight: Float = 1f,
        bg: Int = Ui.PANEL2,
        onTap: () -> Unit
    ): TextView {
        val k = Ui.button(context, label, 20f, bg, onTap)
        k.minimumWidth = 0
        k.setPadding(0, 0, 0, 0)
        addView(k, Ui.lin(0, context.dp(50), weight, context.dp(2)))
        return k
    }

    private fun LinearLayout.addChar(c: String) {
        addKey(c) { type(c) }
    }

    private fun LinearLayout.addLetter(c: String) {
        val k = addKey(c) { }
        k.setOnClickListener { type(k.text.toString()) }
        letters.add(k to c)
    }

    private fun type(s: String) {
        buf.append(s)
        if (shift) {
            shift = false
            applyShift()
        }
        refresh()
    }

    private fun backspace() {
        if (buf.isNotEmpty()) buf.deleteCharAt(buf.length - 1)
        refresh()
    }

    private fun applyShift() {
        letters.forEach { (k, c) -> k.text = if (shift) c.uppercase(tr) else c }
    }

    private fun refresh() {
        if (buf.isEmpty()) {
            preview.text = hint
            preview.setTextColor(Ui.MUTED)
        } else {
            preview.text = buf.toString()
            preview.setTextColor(Ui.TEXT)
        }
    }
}
