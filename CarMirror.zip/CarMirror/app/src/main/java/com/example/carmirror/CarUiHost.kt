package com.example.carmirror

import android.app.Presentation
import android.content.Context
import android.graphics.drawable.ColorDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Display
import android.view.InputDevice
import android.view.MotionEvent
import android.view.Surface
import android.view.ViewGroup
import android.view.WindowManager

/**
 * Araç ekranı yüzeyini (Surface) yönetir.
 *
 * Normal mod: yüzeye bağlı kendi VirtualDisplay'imizi açar, üzerinde bir Presentation
 * (RootView: ana menü + modüller) gösterir. Araçtan gelen dokunuşlar MotionEvent'e çevrilip
 * bu pencereye verilir. Telefon ekranı kapalıyken bile çalışır.
 *
 * Yansıtma modu: yüzey MirrorBridge'e (MediaProjection) devredilir.
 */
class CarUiHost(private val ctx: Context) {

    private val main = Handler(Looper.getMainLooper())

    private var surface: Surface? = null
    private var width = 0
    private var height = 0
    private var dpi = 0

    private var uiW = 0
    private var uiH = 0
    private var uiDpi = 0
    private var virtualDisplay: VirtualDisplay? = null
    private var presentation: Presentation? = null
    private var root: RootView? = null

    var mirrorMode = false
        private set

    /** Arayüz yeniden kurulurken ilk açılacak modül (tema değişince "settings"). */
    private var startModule = "home"

    init {
        Themes.apply(CarPrefs.theme(ctx))
    }

    // ---- dokunma sentezi (yalnızca normal mod) ----
    private var lastClickX = 0f
    private var lastClickY = 0f
    private var lastClickTime = 0L
    private var dragging = false
    private var dragDownTime = 0L
    private var dragX = 0f
    private var dragY = 0f
    private val endDragRunnable = Runnable { endDrag() }

    // ------------------------------------------------------------------ yüzey

    fun onSurfaceAvailable(s: Surface, w: Int, h: Int, d: Int) {
        surface = s
        width = w
        height = h
        dpi = d
        MirrorBridge.hasCarSurface = true
        if (mirrorMode) {
            MirrorBridge.setTarget(s, w, h, d)
        } else {
            ensureUi()
        }
    }

    fun onSurfaceDestroyed() {
        surface = null
        MirrorBridge.hasCarSurface = false
        endDrag()
        if (mirrorMode) {
            MirrorBridge.clearTarget()
        } else {
            try {
                virtualDisplay?.surface = null
            } catch (_: Exception) {
            }
        }
    }

    private fun ensureUi() {
        val s = surface ?: return
        if (!s.isValid || width <= 0 || height <= 0 || dpi <= 0) return

        if (virtualDisplay != null && (uiW != width || uiH != height || uiDpi != dpi)) {
            teardownUi() // ölçü değişti: pencereyi baştan kur
        }

        val vd = virtualDisplay
        if (vd == null) {
            try {
                val dm = ctx.getSystemService(DisplayManager::class.java)
                val flags = DisplayManager.VIRTUAL_DISPLAY_FLAG_PRESENTATION or
                        DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY
                val created = dm.createVirtualDisplay("CarUi", width, height, dpi, s, flags)
                virtualDisplay = created
                uiW = width
                uiH = height
                uiDpi = dpi
                showPresentation(created.display)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        } else {
            vd.surface = s
        }
    }

    private fun showPresentation(display: Display) {
        val p = Presentation(ctx, display)
        p.window?.let { w ->
            w.addFlags(WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED)
            w.setBackgroundDrawable(ColorDrawable(Ui.BG))
        }
        val r = RootView(p.context, this, startModule)
        startModule = "home"
        p.setContentView(r, ViewGroup.LayoutParams(Ui.MATCH, Ui.MATCH))
        p.setCancelable(false)
        p.show()
        presentation = p
        root = r
    }

    private fun teardownUi() {
        endDrag()
        try {
            presentation?.dismiss()
        } catch (_: Exception) {
        }
        root?.destroy()
        presentation = null
        root = null
        try {
            virtualDisplay?.release()
        } catch (_: Exception) {
        }
        virtualDisplay = null
    }

    fun destroy() {
        main.removeCallbacksAndMessages(null)
        MirrorBridge.clearTarget()
        MirrorBridge.hasCarSurface = false
        mirrorMode = false
        teardownUi()
        PlayerHolder.release()
        surface = null
    }

    /** Tema değişince arayüzü yeni renklerle baştan kurar (çalan müzik/radyo kesilmez). */
    fun restartUi(startId: String = "home") {
        if (mirrorMode) return
        startModule = startId
        main.post {
            teardownUi()
            ensureUi()
        }
    }

    // ---------------------------------------------------------- mod geçişleri

    fun enterMirror() {
        if (MirrorBridge.projection == null) {
            root?.toast("Önce telefonda 'Yansıtmayı başlat'a bas")
            return
        }
        if (TouchForwardService.instance == null) {
            root?.toast("Dokunma için erişilebilirlik servisini aç")
        }
        mirrorMode = true
        endDrag()
        try {
            virtualDisplay?.surface = null
        } catch (_: Exception) {
        }
        surface?.let { MirrorBridge.setTarget(it, width, height, dpi) }
    }

    private fun exitMirror() {
        mirrorMode = false
        MirrorBridge.clearTarget()
        ensureUi()
    }

    /** Araç eylem çubuğundaki "Ana menü" düğmesi. */
    fun menu() {
        if (mirrorMode) exitMirror() else root?.home()
    }

    /** Araç eylem çubuğundaki "Geri" düğmesi. */
    fun back() {
        if (mirrorMode) MirrorBridge.back() else root?.back()
    }

    // ---------------------------------------------------------------- dokunma

    fun click(x: Float, y: Float) {
        if (mirrorMode) {
            if (!MirrorBridge.tap(x, y)) root?.toast("Erişilebilirlik servisi kapalı")
            return
        }
        endDrag()
        lastClickX = x
        lastClickY = y
        lastClickTime = SystemClock.uptimeMillis()
        val t = SystemClock.uptimeMillis()
        send(MotionEvent.ACTION_DOWN, x, y, t)
        main.postDelayed({ send(MotionEvent.ACTION_UP, x, y, t) }, 50)
    }

    fun scroll(dx: Float, dy: Float) {
        if (mirrorMode) {
            MirrorBridge.scroll(dx, dy)
            return
        }
        if (!dragging) {
            dragging = true
            val recent = SystemClock.uptimeMillis() - lastClickTime < 10_000
            dragX = if (recent) lastClickX else width / 2f
            dragY = if (recent) lastClickY else height / 2f
            dragDownTime = SystemClock.uptimeMillis()
            send(MotionEvent.ACTION_DOWN, dragX, dragY, dragDownTime)
        }
        // distanceX pozitif = parmak sola gitti
        dragX = (dragX - dx).coerceIn(1f, (width - 1).toFloat())
        dragY = (dragY - dy).coerceIn(1f, (height - 1).toFloat())
        send(MotionEvent.ACTION_MOVE, dragX, dragY, dragDownTime)
        main.removeCallbacks(endDragRunnable)
        main.postDelayed(endDragRunnable, 150)
    }

    fun fling(vx: Float, vy: Float) {
        if (mirrorMode) {
            MirrorBridge.fling(vx, vy)
            return
        }
        endDrag()
    }

    private fun endDrag() {
        if (!dragging) return
        dragging = false
        main.removeCallbacks(endDragRunnable)
        send(MotionEvent.ACTION_UP, dragX, dragY, dragDownTime)
    }

    private fun send(action: Int, x: Float, y: Float, downTime: Long) {
        val target = presentation?.window?.decorView ?: return
        val ev = MotionEvent.obtain(downTime, SystemClock.uptimeMillis(), action, x, y, 0)
        ev.source = InputDevice.SOURCE_TOUCHSCREEN
        try {
            target.dispatchTouchEvent(ev)
        } finally {
            ev.recycle()
        }
    }
}
