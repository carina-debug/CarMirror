package com.example.carmirror

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

data class Channel(val name: String, val url: String, val group: String, val logo: String)

/** M3U / M3U8 oynatma listesi ayrıştırıcı. */
object M3u {

    private val attr = Regex("""([\w-]+)="([^"]*)"""")

    fun parse(file: File): List<Channel> {
        val out = ArrayList<Channel>()
        var name = ""
        var group = ""
        var logo = ""
        file.bufferedReader().useLines { lines ->
            for (raw in lines) {
                val line = raw.trim()
                when {
                    line.startsWith("#EXTINF") -> {
                        val attrs = attr.findAll(line).associate { it.groupValues[1].lowercase() to it.groupValues[2] }
                        group = attrs["group-title"] ?: ""
                        logo = attrs["tvg-logo"] ?: ""
                        name = line.substringAfterLast(',').trim()
                        if (name.isEmpty()) name = attrs["tvg-name"] ?: ""
                    }

                    line.startsWith("#EXTGRP:") -> group = line.removePrefix("#EXTGRP:").trim()

                    line.isNotEmpty() && !line.startsWith("#") -> {
                        out.add(Channel(name.ifBlank { line }, line, group.ifBlank { "Diğer" }, logo))
                        name = ""
                        group = ""
                        logo = ""
                    }
                }
            }
        }
        return out
    }
}

/** IPTV ayarları ve favoriler (telefondaki "IPTV ayarları" ekranından girilir). */
object IptvPrefs {

    private fun sp(ctx: Context) = ctx.getSharedPreferences("iptv", Context.MODE_PRIVATE)

    fun raw(ctx: Context, key: String): String = sp(ctx).getString(key, "") ?: ""

    fun save(ctx: Context, url: String, host: String, user: String, pass: String) {
        sp(ctx).edit()
            .putString("url", url.trim())
            .putString("xhost", host.trim())
            .putString("xuser", user.trim())
            .putString("xpass", pass.trim())
            .apply()
        File(ctx.cacheDir, "iptv.m3u").delete()
    }

    /** Xtream bilgisi girilmişse ondan M3U adresi üretir, yoksa doğrudan M3U adresini kullanır. */
    fun playlistUrl(ctx: Context): String {
        val host = raw(ctx, "xhost").trim()
        if (host.isNotEmpty()) {
            val base = (if (host.startsWith("http")) host else "http://$host").trimEnd('/')
            val u = URLEncoder.encode(raw(ctx, "xuser"), "UTF-8")
            val p = URLEncoder.encode(raw(ctx, "xpass"), "UTF-8")
            return "$base/get.php?username=$u&password=$p&type=m3u_plus&output=ts"
        }
        return raw(ctx, "url").trim()
    }

    fun favorites(ctx: Context): MutableSet<String> =
        HashSet(sp(ctx).getStringSet("fav", emptySet()) ?: emptySet())

    fun saveFavorites(ctx: Context, set: Set<String>) {
        sp(ctx).edit().putStringSet("fav", set).apply()
    }
}

class IptvModule(private val root: RootView) : CarModule {

    override val title = "IPTV"

    private data class Group(val key: String, val label: String)

    private enum class Mode { GROUPS, CHANNELS }

    private enum class Section { LIVE, MOVIES, SERIES }

    private enum class XKind { CAT, MOVIE, SERIES, SEASON, EPISODE }

    private data class XItem(val kind: XKind, val title: String, val sub: String, val id: String, val url: String = "")

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private var all: List<Channel> = emptyList()
    private var loaded = false
    private var groups: List<Group> = emptyList()
    private var mode = Mode.GROUPS
    private var channels: List<Channel> = emptyList()
    private var playing: Channel? = null
    private var favs = HashSet<String>()

    // ---- Xtream: film / dizi
    private var section = Section.LIVE
    private var xItems: List<XItem> = emptyList()
    private var xHeader = ""
    private val xStack = ArrayList<Pair<String, List<XItem>>>()
    private var seasonMap: Map<String, List<XItem>> = emptyMap()
    private val xTabButtons = HashMap<Section, TextView>()
    private lateinit var xAdapter: RowAdapter<XItem>
    private lateinit var xTabs: LinearLayout
    private lateinit var accountView: TextView

    private var multi = false
    private var immersive = false
    private var activeCell = 0
    private val cellPlayers = arrayOfNulls<ExoPlayer>(4)

    private lateinit var list: RecyclerView
    private lateinit var groupAdapter: RowAdapter<Group>
    private lateinit var channelAdapter: RowAdapter<Channel>
    private lateinit var header: TextView
    private lateinit var info: TextView
    private lateinit var leftPanel: LinearLayout
    private lateinit var videoHolder: FrameLayout
    private lateinit var surface: VideoSurface
    private lateinit var status: TextView
    private lateinit var nowLabel: TextView
    private lateinit var controls: LinearLayout
    private lateinit var playBtn: TextView
    private lateinit var multiGrid: LinearLayout
    private lateinit var cellSurfaces: Array<VideoSurface>
    private lateinit var cellBoxes: Array<FrameLayout>

    private val player get() = PlayerHolder.get(root.context)

    private val listener = object : Player.Listener {
        override fun onPlaybackStateChanged(state: Int) {
            when (state) {
                Player.STATE_BUFFERING -> showStatus("Yükleniyor…")
                Player.STATE_READY -> showStatus("")
                else -> {}
            }
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            playBtn.text = if (isPlaying) "⏸" else "▶"
        }

        override fun onPlayerError(error: PlaybackException) {
            showStatus("Oynatılamadı")
        }
    }

    override fun createView(root: RootView): View {
        val c = root.context

        groupAdapter = RowAdapter { row, g, _ ->
            row.title.text = g.label
            row.subtitle.text = ""
            row.subtitle.visibility = View.GONE
            row.setSelectedRow(false)
            row.setAction(null)
            row.setOnClickListener { openGroup(g) }
        }
        channelAdapter = RowAdapter { row, ch, _ ->
            row.title.text = ch.name
            row.subtitle.visibility = View.VISIBLE
            row.subtitle.text = ch.group
            row.setSelectedRow(ch.url == playing?.url)
            row.setAction(if (favs.contains(ch.url)) "★" else "☆") {
                toggleFavorite(ch)
            }
            row.setOnClickListener { play(ch) }
        }
        xAdapter = RowAdapter { row, x, _ ->
            row.title.text = x.title
            row.subtitle.visibility = if (x.sub.isEmpty()) View.GONE else View.VISIBLE
            row.subtitle.text = x.sub
            row.setSelectedRow((x.kind == XKind.MOVIE || x.kind == XKind.EPISODE) && x.url == playing?.url)
            row.setAction(null)
            row.setOnClickListener { xOpen(x) }
        }
        list = RecyclerView(c).apply { layoutManager = LinearLayoutManager(c) }

        header = Ui.label(c, "Gruplar", 18f, bold = true).apply {
            isSingleLine = true
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        info = Ui.label(c, "", 14f, Ui.MUTED).apply { setPadding(c.dp(6), c.dp(2), c.dp(6), c.dp(2)) }

        val headRow = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(Ui.button(c, "☰", 20f) { goRoot() }, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, c.dp(2)))
            addView(header, Ui.lin(0, Ui.WRAP, 1f, c.dp(6)))
            addView(Ui.button(c, "🔍", 18f) { searchChannels() }, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, c.dp(2)))
            addView(Ui.button(c, "⟳", 20f) { refreshCurrent() }, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, c.dp(2)))
        }

        leftPanel = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        leftPanel.addView(headRow, Ui.lin(Ui.MATCH, Ui.WRAP))
        xTabs = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            visibility = View.GONE
        }
        fun xTab(sec: Section, label: String) {
            val b = Ui.button(c, label, if (root.compact) 14f else 16f) { setSection(sec) }
            xTabButtons[sec] = b
            xTabs.addView(b, Ui.lin(0, Ui.WRAP, 1f, c.dp(2)))
        }
        xTab(Section.LIVE, "📺 Canlı")
        xTab(Section.MOVIES, "🎬 Film")
        xTab(Section.SERIES, "📚 Dizi")
        accountView = Ui.label(c, "", 13f, Ui.MUTED).apply {
            visibility = View.GONE
            setPadding(c.dp(6), 0, c.dp(6), 0)
        }
        leftPanel.addView(xTabs, Ui.lin(Ui.MATCH, Ui.WRAP))
        leftPanel.addView(accountView, Ui.lin(Ui.MATCH, Ui.WRAP))
        leftPanel.addView(info, Ui.lin(Ui.MATCH, Ui.WRAP))
        leftPanel.addView(list, Ui.lin(Ui.MATCH, 0, 1f))
        if (!root.isPhone) leftPanel.addView(Ui.pager(c, list), Ui.lin(Ui.MATCH, Ui.WRAP))

        // ---- sağ taraf: tekli video
        surface = VideoSurface(c).apply { setOnClickListener { toggleImmersive() } }
        status = Ui.label(c, "", 20f, 0xFFFFFFFF.toInt(), bold = true).apply {
            gravity = Gravity.CENTER
            setBackgroundColor(0x88000000.toInt())
            setPadding(c.dp(16), c.dp(8), c.dp(16), c.dp(8))
            visibility = View.GONE
        }
        nowLabel = Ui.label(c, "Kanal seç", 16f, 0xFFFFFFFF.toInt(), bold = true).apply {
            isSingleLine = true
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        playBtn = Ui.button(c, "▶", 22f, Ui.ACCENT) { togglePlay() }
        controls = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0xCC000000.toInt())
            setPadding(c.dp(6), c.dp(4), c.dp(6), c.dp(4))
            addView(Ui.button(c, "⏮", 20f) { zap(-1) }, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, c.dp(2)))
            addView(playBtn, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, c.dp(2)))
            addView(Ui.button(c, "⏭", 20f) { zap(1) }, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, c.dp(2)))
            addView(nowLabel, Ui.lin(0, Ui.WRAP, 1f, c.dp(8)))
            addView(Ui.button(c, "⛶", 20f) { toggleImmersive() }, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, c.dp(2)))
            addView(Ui.button(c, "▦", 20f) { setMulti(!multi) }, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, c.dp(2)))
        }
        videoHolder = FrameLayout(c).apply {
            addView(surface, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
            addView(status, FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.CENTER))
            addView(controls, FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP, Gravity.BOTTOM))
        }

        // ---- sağ taraf: çoklu ekran (2x2)
        cellSurfaces = Array(4) { VideoSurface(c) }
        cellBoxes = Array(4) { i ->
            FrameLayout(c).apply {
                setPadding(c.dp(3), c.dp(3), c.dp(3), c.dp(3))
                isClickable = true
                setOnClickListener { selectCell(i) }
                addView(cellSurfaces[i], FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
            }
        }
        multiGrid = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            for (r in 0..1) {
                val rowLayout = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
                rowLayout.addView(cellBoxes[r * 2], Ui.lin(0, Ui.MATCH, 1f))
                rowLayout.addView(cellBoxes[r * 2 + 1], Ui.lin(0, Ui.MATCH, 1f))
                addView(rowLayout, Ui.lin(Ui.MATCH, 0, 1f))
            }
        }
        val rightPanel = FrameLayout(c).apply {
            addView(videoHolder, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
            addView(multiGrid, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        }

        return LinearLayout(c).apply {
            setPadding(c.dp(6), c.dp(6), c.dp(6), c.dp(6))
            if (root.compact) {
                // Telefon (dikey): üstte video, altta kanal listesi
                orientation = LinearLayout.VERTICAL
                addView(rightPanel, Ui.lin(Ui.MATCH, 0, 4f, c.dp(3)))
                addView(leftPanel, Ui.lin(Ui.MATCH, 0, 6f, c.dp(3)))
            } else {
                orientation = LinearLayout.HORIZONTAL
                addView(leftPanel, Ui.lin(0, Ui.MATCH, 4f, c.dp(3)))
                addView(rightPanel, Ui.lin(0, Ui.MATCH, 6f, c.dp(3)))
            }
        }
    }

    override fun onShow() {
        favs = HashSet(IptvPrefs.favorites(root.context))
        player.addListener(listener)
        if (!multi) surface.attach(player)
        playBtn.text = if (player.isPlaying) "⏸" else "▶"
        val xt = xConfigured()
        xTabs.visibility = if (xt) View.VISIBLE else View.GONE
        if (!xt) {
            section = Section.LIVE
            accountView.visibility = View.GONE
        }
        styleTabs()
        if (section == Section.LIVE) ensureLoaded(false)
        if (xt) loadAccount()
    }

    override fun onHide() {
        player.removeListener(listener)
        stopAll()
    }

    override fun onBack(): Boolean {
        if (immersive) {
            toggleImmersive()
            return true
        }
        if (multi) {
            setMulti(false)
            return true
        }
        if (section != Section.LIVE && xStack.isNotEmpty()) {
            val prev = xStack.removeAt(xStack.size - 1)
            xHeader = prev.first
            xItems = prev.second
            xShow()
            return true
        }
        if (section == Section.LIVE && mode == Mode.CHANNELS) {
            showGroups()
            return true
        }
        return false
    }

    override fun onDestroy() {
        stopAll()
        io.shutdownNow()
        main.removeCallbacksAndMessages(null)
    }

    // ------------------------------------------------------------ liste yükleme

    private fun ensureLoaded(force: Boolean) {
        if (loaded && !force) {
            if (mode == Mode.GROUPS) showGroups()
            return
        }
        val c = root.context
        val url = IptvPrefs.playlistUrl(c)
        if (url.isBlank()) {
            info.text = if (root.isPhone) "IPTV listesi ayarlanmamış. Ayarlar > Genel > IPTV ayarları'na gir."
            else "IPTV listesi ayarlanmamış. Telefonda uygulamayı açıp 'IPTV ayarları'na gir."
            return
        }
        info.text = "Liste yükleniyor…"
        val cache = File(c.cacheDir, "iptv.m3u")
        io.execute {
            try {
                if (force || !cache.exists()) download(url, cache)
                val parsed = M3u.parse(cache)
                main.post {
                    all = parsed
                    loaded = true
                    buildGroups()
                    showGroups()
                    info.text = "${all.size} kanal"
                }
            } catch (e: Exception) {
                main.post { info.text = "Liste yüklenemedi: ${e.message ?: "hata"}" }
            }
        }
    }

    private fun download(url: String, dest: File) {
        var u = url
        repeat(6) {
            val conn = URL(u).openConnection() as HttpURLConnection
            conn.instanceFollowRedirects = false
            conn.connectTimeout = 15_000
            conn.readTimeout = 30_000
            conn.setRequestProperty("User-Agent", "VLC/3.0.18 LibVLC/3.0.18")
            val code = conn.responseCode
            if (code in 300..399) {
                val loc = conn.getHeaderField("Location") ?: throw IOException("Yönlendirme hatası")
                u = URL(URL(u), loc).toString()
                conn.disconnect()
                return@repeat
            }
            if (code != 200) throw IOException("HTTP $code")
            val tmp = File(dest.parentFile, dest.name + ".tmp")
            conn.inputStream.use { ins -> tmp.outputStream().use { ins.copyTo(it) } }
            dest.delete()
            tmp.renameTo(dest)
            return
        }
        throw IOException("Çok fazla yönlendirme")
    }

    private fun buildGroups() {
        val counts = all.groupingBy { it.group }.eachCount()
        val names = counts.keys.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it })
        groups = listOf(
            Group("__fav", "★ Favoriler"),
            Group("__all", "Tümü (${all.size})")
        ) + names.map { Group(it, "$it (${counts[it]})") }
    }

    // ------------------------------------------------------------------ liste

    private fun showGroups() {
        mode = Mode.GROUPS
        header.text = "Gruplar"
        list.adapter = groupAdapter
        groupAdapter.items = groups
    }

    private fun openGroup(g: Group) {
        channels = when (g.key) {
            "__fav" -> all.filter { favs.contains(it.url) }
            "__all" -> all
            else -> all.filter { it.group == g.key }
        }
        showChannels(g.label)
        if (channels.isEmpty()) info.text = "Bu grupta kanal yok"
    }

    private fun showChannels(title: String) {
        mode = Mode.CHANNELS
        header.text = title
        list.adapter = channelAdapter
        channelAdapter.items = channels
        info.text = "${channels.size} kanal"
    }

    private fun searchChannels() {
        if (section != Section.LIVE) {
            root.showKeyboard("", "Ara") { q ->
                if (q.isNotBlank()) {
                    val f = xItems.filter { it.title.contains(q.trim(), ignoreCase = true) }
                    xStack.add(xHeader to xItems)
                    xHeader = "Ara: ${q.trim()}"
                    xItems = f
                    xShow()
                }
            }
            return
        }
        if (!loaded) return
        root.showKeyboard("", "Kanal ara") { q ->
            if (q.isNotBlank()) {
                channels = all.filter { it.name.contains(q.trim(), ignoreCase = true) }
                showChannels("Ara: ${q.trim()}")
            }
        }
    }

    private fun toggleFavorite(ch: Channel) {
        if (!favs.add(ch.url)) favs.remove(ch.url)
        IptvPrefs.saveFavorites(root.context, favs)
        channelAdapter.notifyDataSetChanged()
    }

    // ------------------------------------------------------- Xtream: film / dizi

    private fun xConfigured(): Boolean = IptvPrefs.raw(root.context, "xhost").isNotBlank()

    private fun xBase(): String {
        val host = IptvPrefs.raw(root.context, "xhost").trim()
        return (if (host.startsWith("http")) host else "http://$host").trimEnd('/')
    }

    private fun xUser(): String = URLEncoder.encode(IptvPrefs.raw(root.context, "xuser"), "UTF-8")

    private fun xPass(): String = URLEncoder.encode(IptvPrefs.raw(root.context, "xpass"), "UTF-8")

    private fun xApi(action: String, extra: String = ""): String =
        xBase() + "/player_api.php?username=" + xUser() + "&password=" + xPass() +
                (if (action.isEmpty()) "" else "&action=$action") + extra

    private fun xGet(url: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 30_000
        conn.setRequestProperty("User-Agent", "VLC/3.0.18 LibVLC/3.0.18")
        if (conn.responseCode != 200) throw IOException("HTTP ${conn.responseCode}")
        return conn.inputStream.bufferedReader().use { it.readText() }
    }

    private fun styleTabs() {
        val c = root.context
        xTabButtons.forEach { (k, b) ->
            b.background = Ui.round(if (k == section) Ui.ACCENT else Ui.PANEL2, c.dp(10).toFloat())
            b.setTextColor(if (k == section) 0xFFFFFFFF.toInt() else Ui.TEXT)
        }
    }

    private fun loadAccount() {
        io.execute {
            try {
                val ui = JSONObject(xGet(xApi(""))).getJSONObject("user_info")
                val exp = ui.optString("exp_date")
                val date = exp.toLongOrNull()?.let {
                    SimpleDateFormat("dd.MM.yyyy", Locale("tr", "TR")).format(Date(it * 1000))
                }
                val line = "Bitiş: " + (date ?: "sınırsız") +
                        " · Bağlantı: " + ui.optString("active_connections", "0") + "/" +
                        ui.optString("max_connections", "?")
                main.post {
                    accountView.text = line
                    accountView.visibility = View.VISIBLE
                }
            } catch (_: Exception) {
            }
        }
    }

    private fun goRoot() {
        if (section == Section.LIVE) showGroups() else setSection(section)
    }

    private fun refreshCurrent() {
        if (section == Section.LIVE) ensureLoaded(true) else setSection(section)
    }

    private fun setSection(sec: Section) {
        section = sec
        styleTabs()
        xStack.clear()
        when (sec) {
            Section.LIVE -> if (loaded) showGroups() else ensureLoaded(false)
            Section.MOVIES -> xLoadList("Film kategorileri", xApi("get_vod_categories"), false) { arr -> parseCats(arr) }
            Section.SERIES -> xLoadList("Dizi kategorileri", xApi("get_series_categories"), false) { arr -> parseCats(arr) }
        }
    }

    private fun parseCats(arr: JSONArray): List<XItem> {
        val out = ArrayList<XItem>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(XItem(XKind.CAT, o.optString("category_name"), "", o.optString("category_id")))
        }
        return out
    }

    private fun xShow() {
        mode = Mode.GROUPS
        header.text = xHeader
        list.adapter = xAdapter
        xAdapter.items = xItems
        info.text = "${xItems.size} öğe"
    }

    /** [push] true ise şu anki liste geri tuşu için saklanır. */
    private fun xLoadList(headerText: String, url: String, push: Boolean, parse: (JSONArray) -> List<XItem>) {
        info.text = "Yükleniyor…"
        io.execute {
            try {
                val items = parse(JSONArray(xGet(url)))
                main.post {
                    if (push) xStack.add(xHeader to xItems)
                    xHeader = headerText
                    xItems = items
                    xShow()
                }
            } catch (e: Exception) {
                main.post { info.text = "Yüklenemedi: ${e.message ?: "hata"}" }
            }
        }
    }

    private fun xOpen(x: XItem) {
        when (x.kind) {
            XKind.CAT -> if (section == Section.MOVIES) {
                xLoadList(x.title, xApi("get_vod_streams", "&category_id=" + x.id), true) { arr ->
                    val out = ArrayList<XItem>()
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val id = o.optString("stream_id")
                        val ext = o.optString("container_extension").ifBlank { "mp4" }
                        val rating = o.optString("rating")
                        out.add(
                            XItem(
                                XKind.MOVIE, o.optString("name"),
                                if (rating.isNotBlank() && rating != "0") "★ $rating" else "",
                                id, xBase() + "/movie/" + xUser() + "/" + xPass() + "/" + id + "." + ext
                            )
                        )
                    }
                    out
                }
            } else {
                xLoadList(x.title, xApi("get_series", "&category_id=" + x.id), true) { arr ->
                    val out = ArrayList<XItem>()
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        out.add(XItem(XKind.SERIES, o.optString("name"), "", o.optString("series_id")))
                    }
                    out
                }
            }

            XKind.MOVIE -> {
                channels = emptyList()
                play(Channel(x.title, x.url, "Film", ""))
            }

            XKind.SERIES -> openSeries(x)

            XKind.SEASON -> {
                xStack.add(xHeader to xItems)
                xHeader = x.title
                xItems = seasonMap[x.id] ?: emptyList()
                xShow()
            }

            XKind.EPISODE -> {
                channels = xItems.filter { it.kind == XKind.EPISODE }.map { Channel(it.title, it.url, "Dizi", "") }
                play(Channel(x.title, x.url, "Dizi", ""))
            }
        }
    }

    private fun openSeries(x: XItem) {
        info.text = "Yükleniyor…"
        io.execute {
            try {
                val eps = JSONObject(xGet(xApi("get_series_info", "&series_id=" + x.id))).opt("episodes")
                val map = LinkedHashMap<String, List<XItem>>()
                fun addSeason(key: String, arr: JSONArray) {
                    val list = ArrayList<XItem>()
                    for (i in 0 until arr.length()) {
                        val e = arr.getJSONObject(i)
                        val id = e.optString("id")
                        val ext = e.optString("container_extension").ifBlank { "mkv" }
                        val no = e.optString("episode_num")
                        list.add(
                            XItem(
                                XKind.EPISODE, (if (no.isNotBlank()) "$no. " else "") + e.optString("title"),
                                "", id, xBase() + "/series/" + xUser() + "/" + xPass() + "/" + id + "." + ext
                            )
                        )
                    }
                    map[key] = list
                }
                if (eps is JSONObject) {
                    val keys = ArrayList<String>()
                    eps.keys().forEach { keys.add(it) }
                    keys.sortedBy { it.toIntOrNull() ?: 0 }.forEach { k -> addSeason(k, eps.getJSONArray(k)) }
                } else if (eps is JSONArray) {
                    for (i in 0 until eps.length()) addSeason((i + 1).toString(), eps.getJSONArray(i))
                }
                val seasons = map.map { (k, v) -> XItem(XKind.SEASON, "$k. Sezon", "${v.size} bölüm", k) }
                main.post {
                    seasonMap = map
                    xStack.add(xHeader to xItems)
                    xHeader = x.title
                    xItems = seasons
                    xShow()
                    if (seasons.isEmpty()) info.text = "Bölüm bulunamadı"
                }
            } catch (e: Exception) {
                main.post { info.text = "Yüklenemedi: ${e.message ?: "hata"}" }
            }
        }
    }

    // --------------------------------------------------------------- oynatma

    private fun play(ch: Channel) {
        playing = ch
        nowLabel.text = ch.name
        if (multi) {
            playInCell(ch)
        } else {
            val p = player
            surface.attach(p)
            p.setMediaItem(
                MediaItem.Builder()
                    .setUri(ch.url)
                    .setMediaMetadata(MediaMetadata.Builder().setTitle(ch.name).setArtist("IPTV").build())
                    .build()
            )
            p.prepare()
            p.play()
            showStatus("Yükleniyor…")
        }
        channelAdapter.notifyDataSetChanged()
    }

    private fun togglePlay() {
        if (multi) return
        val p = player
        if (p.isPlaying) {
            p.pause()
        } else {
            val ch = playing
            if (ch != null && (p.mediaItemCount == 0 || p.playbackState == Player.STATE_IDLE)) play(ch) else p.play()
        }
    }

    private fun zap(delta: Int) {
        if (channels.isEmpty()) return
        val i = channels.indexOfFirst { it.url == playing?.url }
        val next = if (i < 0) 0 else (i + delta + channels.size) % channels.size
        play(channels[next])
    }

    private fun showStatus(msg: String) {
        status.text = msg
        status.visibility = if (msg.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun toggleImmersive() {
        if (multi) return
        immersive = !immersive
        leftPanel.visibility = if (immersive) View.GONE else View.VISIBLE
        controls.visibility = if (immersive) View.GONE else View.VISIBLE
        root.setChromeVisible(!immersive)
    }

    private fun stopAll() {
        if (immersive) toggleImmersive()
        if (::surface.isInitialized) {
            val p = player
            p.stop()
            p.clearMediaItems()
            surface.detach()
        }
        releaseCells()
        multi = false
        if (::multiGrid.isInitialized) {
            multiGrid.visibility = View.GONE
            videoHolder.visibility = View.VISIBLE
        }
    }

    // ----------------------------------------------------------- çoklu ekran

    private fun setMulti(on: Boolean) {
        if (on == multi) return
        multi = on
        if (on) {
            if (immersive) toggleImmersive()
            val p = player
            p.stop()
            p.clearMediaItems()
            surface.detach()
            videoHolder.visibility = View.GONE
            multiGrid.visibility = View.VISIBLE
            activeCell = 0
            updateCellBorders()
            root.toast("Çoklu ekran: hücreye dokun, sonra kanal seç")
        } else {
            releaseCells()
            multiGrid.visibility = View.GONE
            videoHolder.visibility = View.VISIBLE
            surface.attach(player)
        }
    }

    private fun selectCell(i: Int) {
        activeCell = i
        applyVolumes()
        updateCellBorders()
    }

    private fun playInCell(ch: Channel) {
        val i = activeCell
        val p = cellPlayers[i] ?: PlayerHolder.create(root.context, false).also {
            cellPlayers[i] = it
            cellSurfaces[i].attach(it)
        }
        p.setMediaItem(MediaItem.fromUri(ch.url))
        p.prepare()
        p.play()
        applyVolumes()
    }

    private fun applyVolumes() {
        cellPlayers.forEachIndexed { i, p -> p?.volume = if (i == activeCell) 1f else 0f }
    }

    private fun updateCellBorders() {
        val c = root.context
        cellBoxes.forEachIndexed { i, box ->
            box.background = Ui.round(if (i == activeCell) Ui.ACCENT else Ui.BG, c.dp(6).toFloat())
        }
    }

    private fun releaseCells() {
        for (i in cellPlayers.indices) {
            if (::cellSurfaces.isInitialized) cellSurfaces[i].detach()
            try {
                cellPlayers[i]?.release()
            } catch (_: Exception) {
            }
            cellPlayers[i] = null
        }
    }
}
