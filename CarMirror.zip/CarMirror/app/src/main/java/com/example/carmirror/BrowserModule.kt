package com.example.carmirror

import android.graphics.Bitmap
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.TextView
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONObject

/**
 * Genel web modülü. Aynı sınıf hem "Tarayıcı" (adres çubuklu, başlangıç sayfalı) hem de
 * YouTube / YouTube Kids / YouTube Music gibi tek siteli uygulamalar için kullanılır.
 *
 * - [startUrl] null ise başlangıç sayfası (hızlı erişim) yüklenir.
 * - [wantAdBlock] true ve Ayarlar'da reklam engelleme açıksa AdBlock devreye girer.
 * - Sayfadaki bir yazı alanına dokunulunca ekran klavyemiz açılır ve yazı alana işlenir.
 */
class BrowserModule(
    private val root: RootView,
    override val title: String,
    private val startUrl: String?,
    private val wantAdBlock: Boolean,
    private val addressBar: Boolean
) : CarModule {

    private lateinit var web: WebView
    private var urlView: TextView? = null
    private var textZoom = 130
    private val main = Handler(Looper.getMainLooper())
    private var blockOn = false

    private val desktopUa =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) " +
                "Chrome/124.0.0.0 Safari/537.36"

    private val startHtml: String get() = """
        <!DOCTYPE html><html lang="tr"><head><meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
          body{margin:0;background:${Ui.cssHex(Ui.BG)};color:#fff;font-family:sans-serif}
          h1{text-align:center;font-weight:600;margin:28px 0 18px}
          .g{display:grid;grid-template-columns:repeat(${if (root.isPhone) 2 else 3},1fr);gap:${if (root.isPhone) 12 else 16}px;padding:0 ${if (root.isPhone) 14 else 24}px 24px}
          a{display:block;text-align:center;padding:${if (root.isPhone) 26 else 34}px 8px;border-radius:18px;
            color:#fff;text-decoration:none;font-size:${if (root.isPhone) 19 else 26}px;font-weight:600}
        </style></head><body>
        <h1>Hızlı erişim</h1>
        <div class="g">
          <a style="background:#d50f1f" href="https://www.youtube.com">YouTube</a>
          <a style="background:#c2185b" href="https://music.youtube.com">YouTube Music</a>
          <a style="background:#2563eb" href="https://www.google.com">Google</a>
          <a style="background:#059669" href="https://open.spotify.com">Spotify</a>
          <a style="background:#d97706" href="https://news.google.com/?hl=tr">Haberler</a>
          <a style="background:#7c3aed" href="https://www.google.com/maps">Harita</a>
        </div></body></html>
    """.trimIndent()

    /** Sayfadaki yazı alanına odaklanınca Kotlin tarafına haber verir; metni geri yazar. */
    private val inputScript = """
        (function(){
          if (window.__cmInput) return;
          window.__cmInput = true;
          var OK = ['text','search','url','email','tel','number',''];
          document.addEventListener('focusin', function(e){
            var t = e.target;
            if (!t) return;
            var tag = (t.tagName || '').toLowerCase();
            var editable = tag === 'textarea' || t.isContentEditable ||
              (tag === 'input' && OK.indexOf((t.type || '').toLowerCase()) >= 0);
            if (!editable) return;
            window.__cmEl = t;
            try {
              CarBridge.onInputFocus(t.value || t.textContent || '',
                t.placeholder || t.getAttribute('aria-label') || '');
            } catch(x) {}
          }, true);
          window.__cmSet = function(text, submit){
            var t = window.__cmEl;
            if (!t) return;
            t.focus();
            if ('value' in t) {
              var proto = t.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
              var d = Object.getOwnPropertyDescriptor(proto, 'value');
              if (d && d.set) d.set.call(t, text); else t.value = text;
            } else {
              t.textContent = text;
            }
            t.dispatchEvent(new Event('input', {bubbles: true}));
            t.dispatchEvent(new Event('change', {bubbles: true}));
            if (submit) {
              var k = {key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true};
              t.dispatchEvent(new KeyboardEvent('keydown', k));
              t.dispatchEvent(new KeyboardEvent('keypress', k));
              t.dispatchEvent(new KeyboardEvent('keyup', k));
              if (t.form) {
                try { if (t.form.requestSubmit) t.form.requestSubmit(); else t.form.submit(); } catch(x) {}
              }
            }
          };
        })();
    """.trimIndent()

    private val pageScript: String
        // Telefonda sayfanın kendi (sistem) klavyesi kullanılır; araç klavyesi köprüsü yalnızca araçta
        get() = (if (blockOn) AdBlock.SCRIPT + "\n" else "") + (if (root.isPhone) "" else inputScript)

    inner class Bridge {
        @JavascriptInterface
        fun onInputFocus(value: String, hint: String) {
            main.post {
                root.showKeyboard(value, hint.ifBlank { "Yaz" }) { text ->
                    web.evaluateJavascript("window.__cmSet(${JSONObject.quote(text)}, true)", null)
                }
            }
        }
    }

    override fun createView(root: RootView): View {
        val c = root.context
        blockOn = wantAdBlock && CarPrefs.adBlock(c)
        textZoom = if (root.isPhone) 100 else CarPrefs.zoom(c)

        web = WebView(c)
        configure()

        val bar = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(c.dp(6), c.dp(4), c.dp(6), c.dp(4))
        }
        fun add(label: String, sp: Float = 20f, onClick: () -> Unit) {
            val b = Ui.button(c, label, sp) { onClick() }
            if (root.isPhone) { // telefonda daha küçük düğmeler
                b.minimumWidth = c.dp(40)
                b.minHeight = c.dp(44)
                b.setPadding(c.dp(6), c.dp(4), c.dp(6), c.dp(4))
            }
            bar.addView(b, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, c.dp(2)))
        }

        add("◀") { if (web.canGoBack()) web.goBack() }
        add("▶") { if (web.canGoForward()) web.goForward() }
        add("⟳") { web.reload() }
        add("⌂") { loadStart() }
        if (addressBar) {
            val uv = Ui.label(c, "", 17f).apply {
                isSingleLine = true
                gravity = Gravity.CENTER_VERTICAL
                setPadding(c.dp(12), 0, c.dp(12), 0)
                background = Ui.round(Ui.PANEL, c.dp(10).toFloat())
                isClickable = true
                setOnClickListener {
                    root.showKeyboard(currentTypedUrl(), "Adres yaz veya ara") { navigate(it) }
                }
            }
            urlView = uv
            bar.addView(uv, Ui.lin(0, c.dp(if (root.isPhone) 44 else 52), 1f, c.dp(2)))
        } else {
            bar.addView(View(c), Ui.lin(0, 1, 1f))
        }
        if (!root.isPhone) { // telefonda parmakla kaydır / sıkıştırarak yakınlaştır
            add("A−", 16f) { setZoom(textZoom - 20) }
            add("A+", 16f) { setZoom(textZoom + 20) }
            add("▲") { web.pageUp(false) }
            add("▼") { web.pageDown(false) }
        }

        val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        col.addView(bar, Ui.lin(Ui.MATCH, Ui.WRAP))
        col.addView(web, Ui.lin(Ui.MATCH, 0, 1f))

        loadStart()
        return col
    }

    private fun configure() {
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            useWideViewPort = true
            loadWithOverviewMode = true
            // Telefonda mobil site, araçta masaüstü sitesi
            userAgentString = if (root.isPhone) {
                WebSettings.getDefaultUserAgent(root.context).replace("; wv", "")
            } else desktopUa
            textZoom = this@BrowserModule.textZoom
            if (root.isPhone) {
                setSupportZoom(true)
                builtInZoomControls = true
                displayZoomControls = false
            }
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)

        web.addJavascriptInterface(Bridge(), "CarBridge")
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            try {
                WebViewCompat.addDocumentStartJavaScript(web, pageScript, setOf("*"))
            } catch (_: Exception) {
            }
        }

        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                showUrl(url)
                view?.evaluateJavascript(pageScript, null) // belge-başı betiği desteklenmeyen cihazlar için yedek
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                showUrl(url)
                view?.evaluateJavascript(pageScript, null)
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val scheme = request?.url?.scheme ?: return false
                return scheme !in listOf("http", "https", "about", "data", "blob", "file")
            }

            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                val uri = request?.url ?: return null
                return if (blockOn && AdBlock.shouldBlock(uri)) AdBlock.emptyResponse() else null
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (view == null) return
                root.showFullscreen(view) { callback?.onCustomViewHidden() }
            }

            override fun onHideCustomView() {
                root.hideFullscreen()
            }
        }
    }

    private fun loadStart() {
        if (startUrl != null) {
            web.loadUrl(startUrl)
        } else {
            web.loadDataWithBaseURL("https://start.page/", startHtml, "text/html", "utf-8", null)
        }
    }

    private fun showUrl(url: String?) {
        val uv = urlView ?: return
        uv.text = when {
            url.isNullOrEmpty() -> "Adres yaz veya ara"
            url.startsWith("https://start.page") -> "Başlangıç sayfası"
            else -> url
        }
    }

    private fun currentTypedUrl(): String {
        val u = web.url ?: ""
        return if (u.startsWith("https://start.page")) "" else u
    }

    private fun navigate(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        val url = when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            !t.contains(' ') && t.contains('.') -> "https://$t"
            else -> "https://www.google.com/search?q=" + Uri.encode(t)
        }
        web.loadUrl(url)
    }

    private fun setZoom(z: Int) {
        textZoom = z.coerceIn(80, 260)
        web.settings.textZoom = textZoom
        if (!root.isPhone) CarPrefs.setZoom(root.context, textZoom)
        root.toast("Yazı boyutu %$textZoom")
    }

    override fun onBack(): Boolean {
        if (web.canGoBack()) {
            web.goBack()
            return true
        }
        return false
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        try {
            web.destroy()
        } catch (_: Exception) {
        }
    }
}
