package com.example.carmirror

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** GitHub Releases üzerinden yeni sürüm denetimi (depo, derleme sırasında BuildConfig.UPDATE_REPO olarak gömülür). */
object Updater {

    class Result(val kind: Kind, val version: String = "", val url: String = "", val message: String = "")

    enum class Kind { UP_TO_DATE, AVAILABLE, ERROR }

    fun check(ctx: Context, done: (Result) -> Unit) {
        val main = Handler(Looper.getMainLooper())
        val repo = BuildConfig.UPDATE_REPO
        if (repo.isBlank() || !repo.contains('/')) {
            done(Result(Kind.ERROR, message = "Güncelleme deposu ayarlı değil"))
            return
        }
        Thread {
            val res = try {
                val conn = URL("https://api.github.com/repos/$repo/releases/latest").openConnection() as HttpURLConnection
                conn.connectTimeout = 10_000
                conn.readTimeout = 10_000
                conn.setRequestProperty("Accept", "application/vnd.github+json")
                conn.setRequestProperty("User-Agent", "CarMirror")
                if (conn.responseCode == 404) {
                    Result(Kind.ERROR, message = "Yayın bulunamadı (depo herkese açık mı, yayın var mı?)")
                } else if (conn.responseCode != 200) {
                    Result(Kind.ERROR, message = "Sunucu hatası: ${conn.responseCode}")
                } else {
                    val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                    val tag = json.optString("tag_name")
                    var apk = ""
                    val assets = json.optJSONArray("assets")
                    if (assets != null) {
                        for (i in 0 until assets.length()) {
                            val a = assets.getJSONObject(i)
                            if (a.optString("name").endsWith(".apk")) {
                                apk = a.optString("browser_download_url")
                                break
                            }
                        }
                    }
                    val page = json.optString("html_url")
                    if (isNewer(tag, BuildConfig.VERSION_NAME)) {
                        Result(Kind.AVAILABLE, version = tag.trimStart('v', 'V'), url = apk.ifEmpty { page })
                    } else {
                        Result(Kind.UP_TO_DATE)
                    }
                }
            } catch (e: Exception) {
                Result(Kind.ERROR, message = "Bağlantı kurulamadı")
            }
            main.post { done(res) }
        }.start()
    }

    /** "v3.5" > "3.4" gibi sayısal sürüm karşılaştırması. */
    private fun isNewer(remote: String, local: String): Boolean {
        val r = Regex("\\d+").findAll(remote).map { it.value.toInt() }.toList()
        val l = Regex("\\d+").findAll(local).map { it.value.toInt() }.toList()
        if (r.isEmpty()) return false
        for (i in 0 until maxOf(r.size, l.size)) {
            val a = r.getOrElse(i) { 0 }
            val b = l.getOrElse(i) { 0 }
            if (a != b) return a > b
        }
        return false
    }
}
