@file:OptIn(UnstableApi::class)

package com.example.carmirror

import android.content.Context
import android.graphics.Color
import android.view.TextureView
import android.widget.FrameLayout
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory

/** Müzik, radyo, galeri videosu ve tekli IPTV'nin paylaştığı tek ExoPlayer. */
object PlayerHolder {

    private var player: ExoPlayer? = null

    fun get(ctx: Context): ExoPlayer = player ?: create(ctx, true).also {
        player = it
        PlaybackService.start(ctx) // bildirim + medya tuşları + arka planda çalma
    }

    /** Oynatıcı yoksa oluşturmadan null döner (şerit/widget yoklaması için). */
    fun peek(): ExoPlayer? = player

    /** Çoklu ekran gibi ek oynatıcılar için bağımsız oynatıcı üretir. */
    fun create(ctx: Context, handleAudioFocus: Boolean): ExoPlayer {
        val app = ctx.applicationContext
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Linux; Android 13) CarMirror/1.0")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(15_000)
        val dataSourceFactory = DefaultDataSource.Factory(app, http) // content://, file://, http(s)
        val attrs = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()
        return ExoPlayer.Builder(app)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dataSourceFactory))
            .setAudioAttributes(attrs, handleAudioFocus)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()
    }

    fun release() {
        PlaybackService.stop()
        try {
            player?.release()
        } catch (_: Exception) {
        }
        player = null
    }
}

/** TextureView tabanlı, en-boy oranını koruyan video yüzeyi (sanal ekranda SurfaceView'dan daha güvenli). */
class VideoSurface(ctx: Context) : FrameLayout(ctx) {

    private val tv = TextureView(ctx)
    private var aspect = 0f
    private var player: ExoPlayer? = null

    private val listener = object : Player.Listener {
        override fun onVideoSizeChanged(videoSize: VideoSize) {
            aspect = if (videoSize.width == 0 || videoSize.height == 0) 0f
            else videoSize.width * videoSize.pixelWidthHeightRatio / videoSize.height
            requestLayout()
        }
    }

    init {
        setBackgroundColor(Color.BLACK)
        addView(tv, LayoutParams(Ui.MATCH, Ui.MATCH))
    }

    fun attach(p: ExoPlayer) {
        detach()
        player = p
        p.setVideoTextureView(tv)
        p.addListener(listener)
        listener.onVideoSizeChanged(p.videoSize)
    }

    fun detach() {
        player?.let {
            it.removeListener(listener)
            it.clearVideoTextureView(tv)
        }
        player = null
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val w = r - l
        val h = b - t
        var cw = w
        var ch = h
        if (aspect > 0f && w > 0 && h > 0) {
            if (w / h.toFloat() > aspect) cw = (h * aspect).toInt() else ch = (w / aspect).toInt()
        }
        val cl = (w - cw) / 2
        val ct = (h - ch) / 2
        tv.layout(cl, ct, cl + cw, ct + ch)
    }
}
