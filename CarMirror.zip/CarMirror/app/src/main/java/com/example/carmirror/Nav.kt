package com.example.carmirror

import android.content.Context
import android.content.Intent

/** "Navigasyon" kartı: Google Haritalar veya Waze'i açar (Ayarlar > Genel'den seçilir). */
object Nav {

    fun launch(ctx: Context): Boolean {
        val app = ctx.applicationContext
        val maps = "com.google.android.apps.maps"
        val waze = "com.waze"
        val order = if (CarPrefs.navApp(app) == "waze") listOf(waze, maps) else listOf(maps, waze)
        for (pkg in order) {
            val i = app.packageManager.getLaunchIntentForPackage(pkg) ?: continue
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                app.startActivity(i)
                return true
            } catch (_: Exception) {
            }
        }
        return false
    }
}
