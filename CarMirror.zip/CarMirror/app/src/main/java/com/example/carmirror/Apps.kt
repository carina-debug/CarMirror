package com.example.carmirror

import android.content.Context

data class App(val id: String, val glyph: String, val label: String, val c1: Int, val c2: Int)

/** Ana menüdeki uygulama kutularının tanımı ve kullanıcının seçtiği sıra. */
object Apps {

    val all: List<App> = listOf(
        App("youtube", "▶", "YouTube", 0xFFFF5252.toInt(), 0xFFD50F1F.toInt()),
        App("kids", "☺", "YouTube Kids", 0xFFFFB84D.toInt(), 0xFFFF7A00.toInt()),
        App("ytmusic", "♫", "YouTube Music", 0xFFFF6B8A.toInt(), 0xFFC2185B.toInt()),
        App("iptv", "📺", "IPTV", 0xFF34D399.toInt(), 0xFF059669.toInt()),
        App("radio", "📻", "Radyo", 0xFFF472B6.toInt(), 0xFFDB2777.toInt()),
        App("browser", "🌐", "Tarayıcı", 0xFF60A5FA.toInt(), 0xFF2563EB.toInt()),
        App("nav", "🧭", "Navigasyon", 0xFF4ADE80.toInt(), 0xFF16A34A.toInt()),
        App("music", "🎵", "Müzik", 0xFFA78BFA.toInt(), 0xFF7C3AED.toInt()),
        App("gallery", "🖼", "Galeri", 0xFFFBBF24.toInt(), 0xFFD97706.toInt()),
        App("mirror", "📱", "Telefon ekranı", 0xFF22D3EE.toInt(), 0xFF0891B2.toInt()),
        App("settings", "⚙", "Ayarlar", 0xFF94A3B8.toInt(), 0xFF475569.toInt())
    )

    /** Kaydedilmiş sıraya göre uygulamalar; kayıtta olmayanlar varsayılan sırayla sona eklenir. */
    fun ordered(ctx: Context, forPhone: Boolean = false): List<App> {
        val byId = all.associateBy { it.id }
        val out = ArrayList<App>()
        for (id in CarPrefs.order(ctx)) {
            val app = byId[id] ?: continue
            if (out.none { it.id == id }) out.add(app)
        }
        for (a in all) {
            if (out.none { it.id == a.id }) out.add(a)
        }
        // "Telefon ekranı" kutusu telefonun kendi ekranında anlamsız
        if (forPhone) out.removeAll { it.id == "mirror" }
        return out
    }
}
