package com.example.carmirror

import android.content.pm.ActivityInfo
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.ViewGroup
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/**
 * Telefonun kendi ekranında çalışan arayüz: araç ekranındaki aynı kart menüsü (HomeModule) ve
 * tüm modüller (RootView). Araç tarafındaki CarUiHost'un telefondaki karşılığıdır.
 *
 * - Dikey (portre) kilitli; yalnızca tam ekran video / IPTV tam ekranında yatay moda geçer.
 * - Yazı girişinde telefonun gerçek klavyesi kullanılır.
 * - Ana menüdeyken geri tuşu uygulamadan çıkar.
 */
class PhoneActivity : ComponentActivity(), UiHost {

    private var root: RootView? = null
    private var immersiveOn = false

    private val permsLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Themes.apply(CarPrefs.theme(this))
        build("home")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val r = root
                if (r == null || r.canExit()) finish() else r.back()
            }
        })

        // İlk açılışta medya (müzik/galeri) + bildirim izinlerini iste
        if (!Perms.hasAudio(this) || !Perms.hasVisual(this)) {
            permsLauncher.launch(Perms.requestList())
        }
    }

    /** Arayüzü (yeni temayla) baştan kurar. */
    private fun build(startId: String) {
        root?.destroy()
        val r = RootView(this, this, startId, isPhone = true)
        root = r
        setContentView(r, ViewGroup.LayoutParams(Ui.MATCH, Ui.MATCH))

        window.setBackgroundDrawable(ColorDrawable(Ui.BG))
        window.statusBarColor = Ui.PANEL
        window.navigationBarColor = Ui.BG
        val ctl = WindowCompat.getInsetsController(window, window.decorView)
        ctl.isAppearanceLightStatusBars = false
        ctl.isAppearanceLightNavigationBars = false
        if (immersiveOn) setImmersive(false)
    }

    // ---------------------------------------------------------------- UiHost

    override fun enterMirror() {
        root?.toast("Telefon ekranı yansıtma yalnızca araç ekranında kullanılır")
    }

    override fun restartUi(startId: String) {
        window.decorView.post { build(startId) }
    }

    override fun setImmersive(on: Boolean) {
        immersiveOn = on
        val ctl = WindowCompat.getInsetsController(window, window.decorView)
        if (on) {
            ctl.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            ctl.hide(WindowInsetsCompat.Type.systemBars())
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        } else {
            ctl.show(WindowInsetsCompat.Type.systemBars())
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_USER_PORTRAIT
        }
    }

    override fun onDestroy() {
        root?.destroy()
        root = null
        // Araç bağlı değilse ve uygulama kapatılıyorsa çalan sesi de bırak
        if (isFinishing && !MirrorBridge.hasCarSurface) PlayerHolder.release()
        super.onDestroy()
    }
}
