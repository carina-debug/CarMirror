# Araç Ekranı (CarMirror) – kişisel Android Auto uygulaması

Android Auto'nun araç ekranında kendi arayüzünü çizer. Modüller:

| Modül | Ne yapar |
|---|---|
| 🌐 Tarayıcı | WebView; YouTube, YouTube Music, Spotify Web vb. Ekran klavyesi, yazı boyutu, tam ekran video |
| 🎵 Müzik | Telefondaki müzikler (albüm kapağı, karıştır/tekrar, ilerleme çubuğu) |
| 📻 Radyo | Favoriler (telefondan düzenlenir), Türkiye popüler istasyonları ve ada göre arama (radio-browser.info) |
| 🖼 Galeri | Fotoğraf/video ızgarası, tam ekran görüntüleyici, slayt gösterisi, video oynatma |
| 📺 IPTV | M3U veya Xtream bilgisiyle canlı kanallar, grup/arama/favori, tam ekran, 2x2 çoklu ekran |
| 📱 Telefon ekranı | Telefon ekranını araca yansıtır, dokunmayı telefona geri iletir (isteğe bağlı) |

## Nasıl çalışır
1. `CarMirrorService` Android Auto'ya **navigasyon uygulaması** olarak kayıt olur ve araç ekranının ham `Surface`'ini alır.
2. `CarUiHost` bu yüzeye bağlı kendi `VirtualDisplay`'ini açar ve üzerinde bir `Presentation` (ana menü + modüller) gösterir. Telefon ekranı kapalıyken de çalışır.
3. Araçtan gelen `onClick/onScroll` olayları `MotionEvent`'e çevrilip bu pencereye verilir. (Sistem klavyesi sanal ekranda çıkmadığı için `CarKeyboard` var.)
4. "Telefon ekranı" kutusu ise yüzeyi `MirrorBridge`'e (MediaProjection) devreder; dokunmalar `TouchForwardService` ile telefona uygulanır.

## Kurulum
1. Android Studio ile `CarMirror` klasörünü aç, Gradle sync bitsin (JDK 17).
2. Telefonu USB hata ayıklama ile bağla → Run (veya Build > Build APK).
3. Telefonda uygulamayı aç → **Medya izinlerini ver** (müzik/galeri için).
4. İstersen: **Radyo istasyonlarını düzenle** ve **IPTV ayarları** (M3U adresi veya Xtream sunucu/kullanıcı/şifre).
5. Android Auto ayarları → en alta in, "Sürüm" yazısına 10 kez dokun → ⋮ menüsü > **Geliştirici ayarları** → **Bilinmeyen kaynaklar**'ı aç.
6. Arabaya bağlan, Android Auto uygulama listesinden **Araç Ekranı**'nı aç.

Yalnızca "Telefon ekranı" kutusu için: erişilebilirlik ayarlarından "Araç Ekranı Dokunma İletimi"ni aç
(Android 13+ yan yüklemede gri ise: Ayarlar > Uygulamalar > Araç Ekranı > ⋮ > *Kısıtlı ayarlara izin ver*), sonra **Yansıtmayı başlat** → "Tüm ekran".

## Araç eylem çubuğu
◀ Geri · ⌂ Ana menü · ✕ Çıkış. Telefon ekranı modunda ◀ telefonun geri tuşudur, ⌂ ana menüye döner.

## Sorun giderme
- **Uygulama Android Auto'da görünmüyor:** Bilinmeyen kaynaklar açık mı? Android Auto > Ayarlar > "Başlatıcıyı özelleştir" içinde işaretli mi? Android Auto'yu zorla durdurup arabayı yeniden bağla.
- **Araç ekranı siyah / çöküyor:** Logcat'te `CarUiHost` ve `Presentation` hatalarına bak. Sanal ekran oluşturma bazı telefonlarda kısıtlı olabilir.
- **Kaydırma çalışmıyor:** Araç sürükleme olaylarını göndermeyebilir. Tüm listelerde ▲ ▼ düğmeleri var; tarayıcıda da ▲ ▼ sayfa kaydırır. Yön ters ise `CarUiHost.scroll` içinde `dx/dy` işaretini çevir (telefon ekranı modu için `MirrorBridge.SCROLL_SIGN`).
- **Siyah bantlar (telefon ekranı modu):** Telefonu yatay çevir.
- **Radyo/IPTV oynamıyor:** Adres http ise sorun yok (cleartext açık). Bazı IPTV sağlayıcıları belirli User-Agent ister; `PlayerHolder` içindeki User-Agent'ı değiştir.
- **Müzik/Galeri boş:** Medya izinleri verildi mi? (Android 14'te "seçili fotoğraflar" yerine "tümüne izin ver" seç.)

## Not
- Sürüş sırasında video izlemek tehlikelidir ve birçok ülkede yasaktır; video/IPTV/tarayıcıyı yalnızca park halindeyken kullan.
- Bu proje kişisel/debug kullanım içindir (`HostValidator.ALLOW_ALL_HOSTS_VALIDATOR`). Play Store'a konamaz.
- Telif/erişim hakkın olmayan IPTV listelerini kullanma.
