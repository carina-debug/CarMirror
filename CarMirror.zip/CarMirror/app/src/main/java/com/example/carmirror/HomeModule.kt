package com.example.carmirror

import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.media3.common.Player
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Ana menü: üstte widget'lar (saat, hava, çalan parça, sık kullanılan 3 kısayol),
 * altında cam görünümlü uygulama kartları. Sıra ve renkler Ayarlar'dan değişir.
 */
class HomeModule(private val root: RootView) : CarModule {

    override val title = "Ana menü"

    private lateinit var holder: FrameLayout
    private val main = Handler(Looper.getMainLooper())
    private var shown = false

    private var clockV: TextView? = null
    private var dateV: TextView? = null
    private var weatherV: TextView? = null
    private var nowTitleV: TextView? = null
    private var nowSubV: TextView? = null
    private var playBtn: TextView? = null
    private var nextBtn: TextView? = null

    private val ticker = object : Runnable {
        override fun run() {
            refreshWidgets()
            if (shown) main.postDelayed(this, 1000)
        }
    }

    override fun createView(root: RootView): View {
        holder = FrameLayout(root.context)
        rebuild()
        return holder
    }

    // Ayarlar'da sıra/tema değişmiş olabilir; her gösterimde yeniden kur.
    override fun onShow() {
        shown = true
        rebuild()
        main.removeCallbacks(ticker)
        main.post(ticker)
        WeatherHub.refresh(root.context) { refreshWidgets() }
    }

    override fun onHide() {
        shown = false
        main.removeCallbacks(ticker)
    }

    override fun onDestroy() {
        shown = false
        main.removeCallbacksAndMessages(null)
    }

    private fun rebuild() {
        holder.removeAllViews()
        holder.addView(buildGrid(), FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        refreshWidgets()
    }

    private fun launch(app: App) {
        val c = root.context
        CarPrefs.bump(c, app.id)
        when (app.id) {
            "mirror" -> root.host.enterMirror()
            "nav" -> if (!Nav.launch(c)) root.toast("Google Haritalar veya Waze kurulu değil")
            else -> root.open(app.id)
        }
    }

    // ------------------------------------------------------------------ ızgara

    private fun buildGrid(): View {
        val c = root.context
        val compact = root.compact
        val cols = if (compact) 3 else 5
        val pad = if (compact) c.dp(8) else c.dp(14)
        val grid = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Ui.HOME_TOP, Ui.HOME_BOTTOM)
            )
        }
        grid.addView(widgetBar(), widgetParams())
        Apps.ordered(c, root.isPhone).chunked(cols).forEach { rowApps ->
            val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
            rowApps.forEach { app -> row.addView(tileView(app), Ui.lin(0, Ui.MATCH, 1f, c.dp(7))) }
            // Eksik kalan son satırda kutular genişlemesin
            repeat(cols - rowApps.size) { row.addView(View(c), Ui.lin(0, Ui.MATCH, 1f, c.dp(7))) }
            // Telefon dikeyde sabit yükseklikli satırlar + kaydırma; diğerlerinde ekranı eşit böl
            grid.addView(row, if (compact) Ui.lin(Ui.MATCH, c.dp(128)) else Ui.lin(Ui.MATCH, 0, 1f))
        }
        if (!compact) return grid
        return ScrollView(c).apply {
            isFillViewport = true
            addView(grid, FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        }
    }

    private fun widgetParams(): LinearLayout.LayoutParams {
        val c = root.context
        val h = when {
            root.compact -> 250 // iki satır + kısayollar
            root.short -> 58
            else -> 100
        }
        return Ui.lin(Ui.MATCH, c.dp(h)).apply { bottomMargin = c.dp(6) }
    }

    // --------------------------------------------------------------- widget'lar

    private fun card(): LinearLayout {
        val c = root.context
        return LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(c.dp(14), c.dp(6), c.dp(14), c.dp(6))
            background = GradientDrawable().apply {
                setColor(Ui.cardColor())
                cornerRadius = c.dp(18).toFloat()
                setStroke(c.dp(1), Ui.cardStroke())
            }
        }
    }

    private fun widgetBar(): View {
        val c = root.context
        val m = c.dp(4)

        val clockCard = card().apply {
            val t = Ui.label(c, "", if (root.short) 22f else 32f, bold = true)
            val d = Ui.label(c, "", 13f, Ui.MUTED).apply { isSingleLine = true }
            clockV = t
            dateV = d
            addView(t)
            if (!root.short) addView(d)
        }
        val weatherCard = card().apply {
            gravity = Gravity.CENTER
            val w = Ui.label(c, "☁ —", if (root.short) 18f else 26f, bold = true)
            weatherV = w
            addView(w)
            isClickable = true
            setOnClickListener {
                if (!Perms.hasLocation(c)) {
                    root.toast("Hava durumu için telefonda uygulamayı açıp konum izni ver")
                } else {
                    WeatherHub.refresh(c, true) { refreshWidgets() }
                    root.toast("Hava durumu güncelleniyor…")
                }
            }
        }
        val nowCard = card().apply {
            orientation = LinearLayout.HORIZONTAL
            val tv = Ui.label(c, "Çalan yok", 16f, bold = true).apply {
                isSingleLine = true
                ellipsize = TextUtils.TruncateAt.END
            }
            val sub = Ui.label(c, "", 13f, Ui.MUTED).apply {
                isSingleLine = true
                ellipsize = TextUtils.TruncateAt.END
            }
            nowTitleV = tv
            nowSubV = sub
            val col = LinearLayout(c).apply {
                orientation = LinearLayout.VERTICAL
                addView(tv)
                addView(sub)
            }
            val pb = Ui.button(c, "▶", 20f) { toggleNow() }
            val nb = Ui.button(c, "⏭", 20f) { PlayerHolder.peek()?.seekToNextMediaItem() }
            for (b in listOf(pb, nb)) {
                b.minHeight = c.dp(44)
                b.minimumWidth = c.dp(48)
            }
            playBtn = pb
            nextBtn = nb
            addView(col, Ui.lin(0, Ui.WRAP, 1f))
            addView(pb, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, c.dp(2)))
            addView(nb, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, c.dp(2)))
        }

        return if (root.compact) {
            val row1 = LinearLayout(c).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(clockCard, Ui.lin(0, Ui.MATCH, 2f, m))
                addView(weatherCard, Ui.lin(0, Ui.MATCH, 1f, m))
            }
            LinearLayout(c).apply {
                orientation = LinearLayout.VERTICAL
                addView(row1, Ui.lin(Ui.MATCH, 0, 1f))
                addView(nowCard, Ui.lin(Ui.MATCH, 0, 1f, m))
                addView(shortcutRow(), Ui.lin(Ui.MATCH, 0, 1.1f))
            }
        } else {
            LinearLayout(c).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(clockCard, Ui.lin(0, Ui.MATCH, 2f, m))
                addView(weatherCard, Ui.lin(0, Ui.MATCH, 1.2f, m))
                addView(nowCard, Ui.lin(0, Ui.MATCH, 3.2f, m))
                if (!root.short) addView(shortcutRow(), Ui.lin(0, Ui.MATCH, 3.6f))
            }
        }
    }

    /** En sık açılan 3 kart (yeterli kullanım yoksa YouTube / Radyo / Müzik ile tamamlanır). */
    private fun shortcutRow(): View {
        val c = root.context
        val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        shortcuts().forEach { app ->
            val icon = Apps.iconView(c, app, 20f, 10)
            val chip = card().apply {
                gravity = Gravity.CENTER
                isClickable = true
                setPadding(c.dp(4), c.dp(4), c.dp(4), c.dp(4))
                addView(icon, LinearLayout.LayoutParams(c.dp(38), c.dp(38)))
                addView(
                    Ui.label(c, app.label, 11f, bold = true).apply {
                        gravity = Gravity.CENTER
                        isSingleLine = true
                        ellipsize = TextUtils.TruncateAt.END
                    },
                    Ui.lin(Ui.WRAP, Ui.WRAP).apply { topMargin = c.dp(3) }
                )
                setOnClickListener { launch(app) }
            }
            row.addView(chip, Ui.lin(0, Ui.MATCH, 1f, c.dp(4)))
        }
        return row
    }

    private fun shortcuts(): List<App> {
        val c = root.context
        val usage = CarPrefs.usage(c)
        val apps = Apps.ordered(c, root.isPhone).filter { it.id != "settings" && it.id != "mirror" }
        val top = apps.filter { (usage[it.id] ?: 0) > 0 }
            .sortedByDescending { usage[it.id] ?: 0 }
            .take(3)
        val fill = listOf("youtube", "radio", "music", "nav")
            .mapNotNull { id -> apps.firstOrNull { it.id == id } }
            .filter { a -> top.none { it.id == a.id } }
        return (top + fill).take(3)
    }

    private fun toggleNow() {
        val p = PlayerHolder.peek() ?: return
        if (p.isPlaying) p.pause() else p.play()
        refreshWidgets()
    }

    private fun refreshWidgets() {
        val now = Date()
        clockV?.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
        dateV?.text = SimpleDateFormat("d MMMM, EEEE", Locale.getDefault()).format(now)
        val w = WeatherHub.data
        weatherV?.text = if (w != null) "${WeatherHub.emoji(w.code)} ${w.temp}°" else "☁ —"

        val p = PlayerHolder.peek()
        val t = p?.mediaMetadata?.title?.toString()
        if (p != null && !t.isNullOrBlank() && p.currentMediaItem != null &&
            p.playbackState != Player.STATE_IDLE && p.playbackState != Player.STATE_ENDED
        ) {
            nowTitleV?.text = t
            nowSubV?.text = p.mediaMetadata.artist?.toString() ?: ""
            playBtn?.text = if (p.isPlaying) "⏸" else "▶"
            playBtn?.visibility = View.VISIBLE
            nextBtn?.visibility = if (p.hasNextMediaItem()) View.VISIBLE else View.GONE
        } else {
            nowTitleV?.text = "Çalan yok"
            nowSubV?.text = ""
            playBtn?.visibility = View.GONE
            nextBtn?.visibility = View.GONE
        }
    }

    // ------------------------------------------------------------------ kartlar

    private fun tileView(app: App): View {
        val c = root.context
        val card = GradientDrawable().apply {
            setColor(Ui.cardColor())
            cornerRadius = c.dp(20).toFloat()
            setStroke(c.dp(1), Ui.cardStroke())
        }
        val compact = root.compact
        val small = root.short
        val iconSize = if (compact) 60 else if (small) 50 else 76
        val icon = Apps.iconView(c, app, if (compact) 28f else if (small) 24f else 34f, 18)
        return LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            // Telefonda ikonlar aynı hizada dursun (2 satırlık etiketler ikonu kaydırmasın)
            gravity = if (compact) Gravity.TOP or Gravity.CENTER_HORIZONTAL else Gravity.CENTER
            if (compact) setPadding(c.dp(4), c.dp(14), c.dp(4), c.dp(4))
            background = card
            isClickable = true
            addView(icon, LinearLayout.LayoutParams(c.dp(iconSize), c.dp(iconSize)))
            addView(
                Ui.label(c, app.label, if (compact || small) 14f else 17f, bold = true).apply {
                    gravity = Gravity.CENTER
                    if (compact) {
                        maxLines = 2
                        ellipsize = TextUtils.TruncateAt.END
                    } else {
                        isSingleLine = true
                    }
                },
                Ui.lin(Ui.WRAP, Ui.WRAP).apply { topMargin = c.dp(if (compact || small) 8 else 12) }
            )
            setOnClickListener { launch(app) }
        }
    }
}
