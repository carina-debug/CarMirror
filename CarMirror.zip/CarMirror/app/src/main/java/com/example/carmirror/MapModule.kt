package com.example.carmirror

import android.annotation.SuppressLint
import android.content.Intent
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

/**
 * Harita: OpenStreetMap (Leaflet) + telefonun GPS konumu, Nominatim ile yer arama,
 * OSRM ile rota (süre/km) ve Overpass ile yakındaki şarj istasyonları.
 * "Yol tarifini başlat" Google Haritalar veya Waze'e hedefi gönderir.
 */
class MapModule(private val root: RootView) : CarModule {

    override val title = "Harita"

    private data class Place(val name: String, val lat: Double, val lon: Double)

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private lateinit var web: WebView
    private lateinit var resultsPanel: LinearLayout
    private lateinit var resultList: RecyclerView
    private lateinit var resultAdapter: RowAdapter<Place>
    private lateinit var resultInfo: TextView
    private lateinit var goBtn: TextView

    private var pageReady = false
    private val pending = ArrayList<String>()
    private var lastLoc: Location? = null
    private var dest: Place? = null
    private var listening = false

    private val locListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            lastLoc = location
            pushLocation(location)
        }

        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}

        @Deprecated("Eski sürümler için")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {
        }
    }

    // ------------------------------------------------------------------ görünüm

    @SuppressLint("SetJavaScriptEnabled")
    override fun createView(root: RootView): View {
        val c = root.context

        web = WebView(c).apply {
            setBackgroundColor(0xFF0B1220.toInt())
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    pageReady = true
                    pending.forEach { web.evaluateJavascript(it, null) }
                    pending.clear()
                }
            }
            loadDataWithBaseURL("https://carmirror.local/", HTML, "text/html", "UTF-8", null)
        }

        val bar = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(c.dp(6), c.dp(4), c.dp(6), c.dp(4))
        }
        fun add(label: String, sp: Float = 20f, onClick: () -> Unit) {
            val b = Ui.button(c, label, sp) { onClick() }
            if (root.isPhone) {
                b.minimumWidth = c.dp(40)
                b.minHeight = c.dp(44)
                b.setPadding(c.dp(6), c.dp(4), c.dp(6), c.dp(4))
            }
            bar.addView(b, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, c.dp(2)))
        }
        add("🔍 Ara", 16f) { askSearch() }
        add("📍") { myLocation() }
        add("＋") { js("cvZoom(1)") }
        add("－") { js("cvZoom(-1)") }
        add("⚡") { js("cvCharge()") }
        add("✕") {
            dest = null
            goBtn.visibility = View.GONE
            js("cvClear()")
        }
        if (!root.isPhone) { // araçta sürükleme yerine yön düğmeleri
            add("◀") { js("cvPan(-180,0)") }
            add("▲") { js("cvPan(0,-180)") }
            add("▼") { js("cvPan(0,180)") }
            add("▶") { js("cvPan(180,0)") }
        }

        // ---- arama sonuçları paneli
        resultAdapter = RowAdapter { row, p, _ ->
            row.title.text = p.name
            row.subtitle.text = ""
            row.setSelectedRow(false)
            row.setAction(null)
            row.setOnClickListener { choose(p) }
        }
        resultList = RecyclerView(c).apply {
            layoutManager = LinearLayoutManager(c)
            adapter = resultAdapter
        }
        resultInfo = Ui.label(c, "", 15f, Ui.MUTED).apply { setPadding(c.dp(10), c.dp(6), c.dp(10), c.dp(2)) }
        resultsPanel = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
            visibility = View.GONE
            addView(resultInfo, Ui.lin(Ui.MATCH, Ui.WRAP))
            addView(resultList, Ui.lin(Ui.MATCH, 0, 1f))
            addView(Ui.button(c, "Kapat", 16f) { resultsPanel.visibility = View.GONE }, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, c.dp(4)))
        }

        goBtn = Ui.button(c, "▶ Yol tarifini başlat", if (root.compact) 16f else 20f, Ui.ACCENT) { startNav() }
        goBtn.visibility = View.GONE

        val stack = FrameLayout(c).apply {
            addView(web, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
            addView(resultsPanel, FrameLayout.LayoutParams(Ui.MATCH, c.dp(if (root.compact) 300 else 260), Gravity.TOP))
            addView(
                goBtn,
                FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
                    bottomMargin = c.dp(14)
                }
            )
        }

        return LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            addView(bar, Ui.lin(Ui.MATCH, Ui.WRAP))
            addView(stack, Ui.lin(Ui.MATCH, 0, 1f))
        }
    }

    override fun onShow() {
        startLocation()
    }

    override fun onHide() {
        stopLocation()
    }

    override fun onBack(): Boolean {
        if (resultsPanel.visibility == View.VISIBLE) {
            resultsPanel.visibility = View.GONE
            return true
        }
        return false
    }

    override fun onDestroy() {
        stopLocation()
        io.shutdownNow()
        main.removeCallbacksAndMessages(null)
        web.destroy()
    }

    // ------------------------------------------------------------------ konum

    private fun js(code: String) {
        if (pageReady) web.evaluateJavascript(code, null) else pending.add(code)
    }

    private fun startLocation() {
        val c = root.context
        if (!Perms.hasFineLocation(c)) {
            root.toast(
                if (root.isPhone) "Konum izni yok. 📍'ye dokunup izin ver."
                else "Konumunu göstermek için telefonda uygulamayı açıp konum iznini ver."
            )
            return
        }
        if (listening) return
        val lm = c.getSystemService(LocationManager::class.java) ?: return
        try {
            for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
                if (lm.isProviderEnabled(p)) {
                    lm.requestLocationUpdates(p, 1500L, 3f, locListener, Looper.getMainLooper())
                }
            }
            var best: Location? = null
            for (p in lm.getProviders(true)) {
                val l = lm.getLastKnownLocation(p)
                if (l != null && (best == null || l.time > best.time)) best = l
            }
            if (best != null) {
                lastLoc = best
                pushLocation(best)
            }
            listening = true
        } catch (_: SecurityException) {
        }
    }

    private fun stopLocation() {
        if (!listening) return
        listening = false
        try {
            root.context.getSystemService(LocationManager::class.java)?.removeUpdates(locListener)
        } catch (_: Exception) {
        }
    }

    private fun pushLocation(l: Location) {
        val bearing = if (l.hasBearing() && l.speed > 1f) l.bearing.toString() else "null"
        js("cvPos(${l.latitude},${l.longitude},${l.accuracy},$bearing)")
    }

    private fun myLocation() {
        val c = root.context
        if (!Perms.hasFineLocation(c)) {
            if (root.isPhone) {
                try {
                    c.applicationContext.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + c.packageName))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (_: Exception) {
                }
            }
            root.toast("Konum izni ver (İzinler > Konum > Kesin)")
            return
        }
        startLocation()
        js("cvFollow()")
    }

    // ------------------------------------------------------------------ arama

    private fun askSearch() {
        root.showKeyboard("", "Yer veya adres ara") { q ->
            if (q.isNotBlank()) search(q.trim())
        }
    }

    private fun search(q: String) {
        resultsPanel.visibility = View.VISIBLE
        resultInfo.text = "Aranıyor: $q …"
        resultAdapter.items = emptyList()
        io.execute {
            try {
                val url = "https://nominatim.openstreetmap.org/search?format=json&limit=8&accept-language=tr&q=" +
                        URLEncoder.encode(q, "UTF-8")
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 10_000
                conn.readTimeout = 15_000
                conn.setRequestProperty("User-Agent", "CarMirror/" + BuildConfig.VERSION_NAME)
                val arr = JSONArray(conn.inputStream.bufferedReader().use { it.readText() })
                val out = ArrayList<Place>()
                for (i in 0 until arr.length()) {
                    val o: JSONObject = arr.getJSONObject(i)
                    out.add(Place(o.optString("display_name"), o.optString("lat").toDouble(), o.optString("lon").toDouble()))
                }
                main.post {
                    resultAdapter.items = out
                    resultInfo.text = if (out.isEmpty()) "Sonuç yok" else "${out.size} sonuç – birini seç"
                }
            } catch (e: Exception) {
                main.post { resultInfo.text = "Aranamadı: ${e.message ?: "bağlantı hatası"}" }
            }
        }
    }

    private fun choose(p: Place) {
        dest = p
        resultsPanel.visibility = View.GONE
        goBtn.visibility = View.VISIBLE
        val l = lastLoc
        val from = if (l != null) "${l.latitude},${l.longitude}" else "null,null"
        js("cvGo(${p.lat},${p.lon},${JSONObject.quote(p.name)},$from)")
    }

    // ------------------------------------------------------------ yol tarifi

    private fun startNav() {
        val d = dest ?: return
        val app = root.context.applicationContext
        val maps = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=${d.lat},${d.lon}"))
            .setPackage("com.google.android.apps.maps")
        val waze = Intent(Intent.ACTION_VIEW, Uri.parse("https://waze.com/ul?ll=${d.lat},${d.lon}&navigate=yes"))
            .setPackage("com.waze")
        val order = if (CarPrefs.navApp(app) == "waze") listOf(waze, maps) else listOf(maps, waze)
        for (i in order) {
            try {
                app.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                root.toast("Yol tarifi gönderildi")
                return
            } catch (_: Exception) {
            }
        }
        root.toast("Haritalar veya Waze kurulu değil")
    }

    companion object {
        // Leaflet unpkg'den, olmazsa cdnjs'den yüklenir. Haritanın kendisi (rota, şarj noktaları) tarayıcıda çalışır.
        private const val HTML = """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css">
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>window.L||document.write('<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js"><\/script>');</script>
<style>
html,body{margin:0;height:100%;background:#0b1220}
#m{position:absolute;inset:0}
#msg{position:absolute;top:10px;left:50%;transform:translateX(-50%);z-index:1000;display:none;max-width:88%;
 background:rgba(0,0,0,.82);color:#fff;font:600 17px sans-serif;padding:9px 16px;border-radius:12px;text-align:center}
.me{width:18px;height:18px;border-radius:50%;background:#38bdf8;border:3px solid #fff;box-shadow:0 0 6px #000}
.arr{width:0;height:0;border-left:12px solid transparent;border-right:12px solid transparent;border-bottom:28px solid #38bdf8;filter:drop-shadow(0 0 3px #000)}
</style></head><body>
<div id="m"></div><div id="msg"></div>
<script>
var map=L.map('m',{zoomControl:false}).setView([39.0,35.0],6);
L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'&copy; OpenStreetMap'}).addTo(map);
var me=null,acc=null,follow=true,first=true,dest=null,route=null,chLayer=null,chBusy=false,msgT=null;
function esc(s){return String(s).replace(/[&<>]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;'}[c];});}
function short(s){s=String(s);return s.length>40?s.substring(0,40)+'…':s;}
function msg(t){var m=document.getElementById('msg');m.textContent=t;m.style.display='block';clearTimeout(msgT);msgT=setTimeout(function(){m.style.display='none';},5000);}
function meIcon(b){
  if(b===null||b===undefined)return L.divIcon({className:'',html:'<div class="me"></div>',iconSize:[24,24]});
  return L.divIcon({className:'',html:'<div class="arr" style="transform:rotate('+b+'deg)"></div>',iconSize:[24,28]});
}
map.on('dragstart',function(){follow=false;});
function cvPos(lat,lng,a,b){
  var p=[lat,lng];
  if(!me){
    me=L.marker(p,{icon:meIcon(b),interactive:false,zIndexOffset:1000}).addTo(map);
    acc=L.circle(p,{radius:a,color:'#38bdf8',weight:1,fillOpacity:0.08,interactive:false}).addTo(map);
  }else{me.setLatLng(p);me.setIcon(meIcon(b));acc.setLatLng(p);acc.setRadius(a);}
  if(first){first=false;map.setView(p,16);}else if(follow){map.panTo(p,{animate:true});}
}
function cvFollow(){follow=true;if(me)map.setView(me.getLatLng(),Math.max(map.getZoom(),15));else msg('Konum bekleniyor…');}
function cvZoom(d){if(d>0)map.zoomIn();else map.zoomOut();}
function cvPan(x,y){follow=false;map.panBy([x,y],{animate:false});}
function cvClear(){if(dest){map.removeLayer(dest);dest=null;}if(route){map.removeLayer(route);route=null;}}
function cvGo(lat,lng,name,flat,flng){
  cvClear();follow=false;
  dest=L.marker([lat,lng]).addTo(map).bindPopup('<b>'+esc(name)+'</b>');
  if(flat===null){map.setView([lat,lng],15);dest.openPopup();msg('Konum yok, rota çizilemedi');return;}
  msg('Rota hesaplanıyor…');
  fetch('https://router.project-osrm.org/route/v1/driving/'+flng+','+flat+';'+lng+','+lat+'?overview=full&geometries=geojson')
  .then(function(r){return r.json();})
  .then(function(j){
    if(!j.routes||!j.routes.length)throw 0;
    var rt=j.routes[0];
    var pts=rt.geometry.coordinates.map(function(c){return [c[1],c[0]];});
    route=L.polyline(pts,{color:'#38bdf8',weight:6,opacity:0.9}).addTo(map);
    map.fitBounds(route.getBounds(),{padding:[40,40]});
    var km=rt.distance/1000,mn=Math.round(rt.duration/60);
    var t=mn>=60?(Math.floor(mn/60)+' sa '+(mn%60)+' dk'):(mn+' dk');
    msg(short(name)+' • '+km.toFixed(km<10?1:0)+' km • '+t);
  }).catch(function(){map.setView([lat,lng],15);dest.openPopup();msg('Rota alınamadı');});
}
var OVP=['https://overpass-api.de/api/interpreter','https://overpass.kumi.systems/api/interpreter'];
function showCh(els,c){
  chLayer=L.layerGroup().addTo(map);
  var n=0;
  els.forEach(function(e){
    var la=e.lat!==undefined?e.lat:(e.center?e.center.lat:null);
    var lo=e.lon!==undefined?e.lon:(e.center?e.center.lon:null);
    if(la===null||lo===null)return;
    var t=e.tags||{};
    var label='⚡ '+esc(t.name||t.operator||'Şarj istasyonu')+(t.capacity?'<br>'+esc(t.capacity)+' soket':'');
    L.circleMarker([la,lo],{radius:9,color:'#fff',weight:2,fillColor:'#22c55e',fillOpacity:1}).addTo(chLayer).bindPopup(label);
    n++;
  });
  msg(n?(n+' şarj istasyonu (15 km)'):'15 km içinde şarj istasyonu yok');
}
function cvCharge(){
  if(chLayer){map.removeLayer(chLayer);chLayer=null;msg('Şarj istasyonları gizlendi');return;}
  if(chBusy)return;
  var c=me?me.getLatLng():map.getCenter();
  chBusy=true;msg('Şarj istasyonları aranıyor…');
  var q='[out:json][timeout:20];(node["amenity"="charging_station"](around:15000,'+c.lat+','+c.lng+');way["amenity"="charging_station"](around:15000,'+c.lat+','+c.lng+'););out center 80;';
  var i=0;
  function next(){
    if(i>=OVP.length){chBusy=false;msg('Şarj istasyonları alınamadı');return;}
    fetch(OVP[i++],{method:'POST',body:'data='+encodeURIComponent(q),headers:{'Content-Type':'application/x-www-form-urlencoded'}})
    .then(function(r){if(!r.ok)throw 0;return r.json();})
    .then(function(j){chBusy=false;showCh(j.elements||[],c);})
    .catch(next);
  }
  next();
}
</script></body></html>"""
    }
}
