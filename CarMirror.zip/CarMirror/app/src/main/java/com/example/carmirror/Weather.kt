package com.example.carmirror

import android.content.Context
import android.location.Location
import android.location.LocationManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/** Ana menü widget'ı için hava durumu (Open-Meteo, anahtar gerektirmez; yaklaşık konum kullanılır). */
object WeatherHub {

    data class W(val temp: Int, val code: Int)

    @Volatile
    var data: W? = null

    private var last = 0L
    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    fun emoji(code: Int): String = when (code) {
        0 -> "☀️"
        1, 2 -> "⛅"
        3 -> "☁️"
        45, 48 -> "🌫️"
        in 51..67 -> "🌧️"
        in 71..77, 85, 86 -> "❄️"
        in 80..82 -> "🌦️"
        in 95..99 -> "⛈️"
        else -> "🌡️"
    }

    fun refresh(ctx: Context, force: Boolean = false, done: () -> Unit) {
        val app = ctx.applicationContext
        if (!Perms.hasLocation(app)) return
        val now = SystemClock.elapsedRealtime()
        if (!force && data != null && now - last < 20 * 60_000L) return
        if (now - last < 15_000L) return // art arda istekleri engelle
        last = now
        io.execute {
            try {
                val lm = app.getSystemService(LocationManager::class.java)
                var loc: Location? = null
                for (p in lm.getProviders(true)) {
                    val l = try {
                        lm.getLastKnownLocation(p)
                    } catch (_: SecurityException) {
                        null
                    }
                    if (l != null && (loc == null || l.time > loc.time)) loc = l
                }
                if (loc == null) return@execute
                val url = URL(
                    "https://api.open-meteo.com/v1/forecast?latitude=${loc.latitude}" +
                            "&longitude=${loc.longitude}&current=temperature_2m,weather_code"
                )
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                val cur = JSONObject(body).getJSONObject("current")
                data = W(Math.round(cur.getDouble("temperature_2m")).toInt(), cur.getInt("weather_code"))
                main.post { done() }
            } catch (_: Exception) {
            }
        }
    }
}
