package com.example.carmirror

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.text.InputType
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.media3.common.Player
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * RootView'i barındıran taraf: araçta [CarUiHost], telefonda [PhoneActivity].
 */
interface UiHost {
    fun enterMirror()
    fun restartUi(startId: String)

    /** Tam ekran video / IPTV tam ekran: telefonda sistem çubukları gizlenir ve yatay moda geçilir. */
    fun setImmersive(on: Boolean) {}
}

/** Araç ekranında gösterilen her modül (tarayıcı, müzik, ...) bu arayüzü uygular. */
interface CarModule {
    val title: String
    fun createView(root: RootView): View
    fun onShow() {}
    fun onHide() {}

    /** true dönerse geri tuşu modül içinde tüketildi demektir. */
    fun onBack(): Boolean = false
    fun onDestroy() {}
}

/**
 * Araç ekranındaki sanal pencerenin kök görünümü: üst çubuk + modül alanı +
 * tam ekran katmanı + ekran klavyesi + kısa mesaj (toast).
 */
class RootView(
    ctx: Context,
    val host: UiHost,
    startId: String = "home",
    val isPhone: Boolean = false
) : FrameLayout(ctx) {

    /** Telefon + dikey: tek sütunlu, dar ekran düzenleri kullanılır. */
    val compact: Boolean = isPhone && ctx.resources.configuration.screenWidthDp < 600

    /** Telefon yatay (alçak ekran): üst widget'lar ve boşluklar küçültülür. */
    val short: Boolean = isPhone && ctx.resources.configuration.screenHeightDp < 480

    /** Ekran sınıfı değişince (döndürme) PhoneActivity arayüzü yeniden kurar. */
    val layoutKey: Int = (if (compact) 1 else 0) + (if (short) 2 else 0)

    val currentModuleId: String get() = current ?: "home"

    companion object {
        fun keyFor(ctx: Context): Int {
            val c = ctx.resources.configuration
            return (if (c.screenWidthDp < 600) 1 else 0) + (if (c.screenHeightDp < 480) 2 else 0)
        }
    }

    private var chromeShown = true

    private val handler = Handler(Looper.getMainLooper())
    private val topBar = LinearLayout(ctx)
    private val titleView = Ui.label(ctx, "", 22f, bold = true)
    private val clock = Ui.label(ctx, "", 20f, Ui.MUTED)
    private val content = FrameLayout(ctx)
    private val overlay = FrameLayout(ctx)
    private val keyboard = CarKeyboard(ctx)
    private val toastView = Ui.label(ctx, "", 18f, Color.WHITE)

    // ---- üst şerit: gelen mesaj + "şu an çalıyor" (⏯ ⏭)
    private val strip = LinearLayout(ctx)
    private val msgRow = Ui.label(ctx, "", 16f, Color.WHITE)
    private val playRow = LinearLayout(ctx)
    private val stripTitle = Ui.label(ctx, "", 15f)
    private val stripPlay = Ui.button(ctx, "▶", 16f) { stripToggle() }
    private val stripNext = Ui.button(ctx, "⏭", 16f) { PlayerHolder.peek()?.seekToNextMediaItem() }
    private var dismissedMsg = 0L

    private val factories: Map<String, () -> CarModule> = mapOf(
        "home" to { HomeModule(this) },
        "youtube" to { BrowserModule(this, "YouTube", "https://www.youtube.com", true, false) },
        "kids" to { BrowserModule(this, "YouTube Kids", "https://www.youtubekids.com", true, false) },
        "ytmusic" to { BrowserModule(this, "YouTube Music", "https://music.youtube.com", true, false) },
        "browser" to { BrowserModule(this, "Tarayıcı", null, true, true) },
        "music" to { MusicModule(this) },
        "radio" to { RadioModule(this) },
        "map" to { MapModule(this) },
        "gallery" to { GalleryModule(this) },
        "iptv" to { IptvModule(this) },
        "settings" to { SettingsModule(this) }
    )
    private val modules = HashMap<String, CarModule>()
    private val views = HashMap<String, View>()
    private var current: String? = null
    private var overlayHidden: (() -> Unit)? = null

    private val hideToast = Runnable { toastView.visibility = View.GONE }
    private val tick = object : Runnable {
        override fun run() {
            clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            // Gündüz/gece otomatik tema: yalnızca ana menüdeyken (açık sayfa kaybolmasın)
            if (current == "home" && overlay.visibility != View.VISIBLE &&
                Themes.effectiveId(context) != Themes.currentId
            ) {
                Themes.applyAll(context)
                host.restartUi("home")
            }
            handler.postDelayed(this, 20_000)
        }
    }

    private val stripTick = object : Runnable {
        override fun run() {
            updateStrip()
            handler.postDelayed(this, 1000)
        }
    }

    init {
        setBackgroundColor(Ui.BG)
        val c = ctx

        topBar.orientation = LinearLayout.HORIZONTAL
        topBar.gravity = Gravity.CENTER_VERTICAL
        topBar.setPadding(c.dp(8), c.dp(4), c.dp(8), c.dp(4))
        topBar.setBackgroundColor(Ui.PANEL)
        topBar.addView(Ui.button(c, "⌂", 24f) { home() }, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, c.dp(3)))
        topBar.addView(Ui.button(c, "◀", 22f) { back() }, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, c.dp(3)))
        topBar.addView(titleView, Ui.lin(0, Ui.WRAP, 1f).apply { leftMargin = c.dp(14) })
        topBar.addView(clock)

        val column = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        column.addView(topBar, Ui.lin(Ui.MATCH, Ui.WRAP))

        strip.orientation = LinearLayout.VERTICAL
        strip.visibility = View.GONE
        msgRow.background = Ui.round(Ui.ACCENT, c.dp(10).toFloat())
        msgRow.setPadding(c.dp(14), c.dp(8), c.dp(14), c.dp(8))
        msgRow.isSingleLine = true
        msgRow.ellipsize = android.text.TextUtils.TruncateAt.END
        msgRow.visibility = View.GONE
        msgRow.setOnClickListener { dismissedMsg = NotifyHub.last?.time ?: 0L; updateStrip() }
        strip.addView(msgRow, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, c.dp(3)))
        playRow.orientation = LinearLayout.HORIZONTAL
        playRow.gravity = Gravity.CENTER_VERTICAL
        playRow.background = Ui.round(Ui.PANEL, c.dp(10).toFloat())
        playRow.setPadding(c.dp(12), c.dp(2), c.dp(4), c.dp(2))
        playRow.visibility = View.GONE
        stripTitle.isSingleLine = true
        stripTitle.ellipsize = android.text.TextUtils.TruncateAt.END
        for (b in listOf(stripPlay, stripNext)) {
            b.minHeight = c.dp(40)
            b.minimumWidth = c.dp(44)
        }
        playRow.addView(stripTitle, Ui.lin(0, Ui.WRAP, 1f))
        playRow.addView(stripPlay, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, c.dp(2)))
        playRow.addView(stripNext, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, c.dp(2)))
        strip.addView(playRow, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, c.dp(3)))
        column.addView(strip, Ui.lin(Ui.MATCH, Ui.WRAP))
        column.addView(content, Ui.lin(Ui.MATCH, 0, 1f))
        addView(column, LayoutParams(Ui.MATCH, Ui.MATCH))

        overlay.setBackgroundColor(Color.BLACK)
        overlay.visibility = View.GONE
        addView(overlay, LayoutParams(Ui.MATCH, Ui.MATCH))

        addView(keyboard, LayoutParams(Ui.MATCH, Ui.WRAP, Gravity.BOTTOM))

        toastView.background = Ui.round(0xE6000000.toInt(), c.dp(10).toFloat())
        toastView.setPadding(c.dp(18), c.dp(10), c.dp(18), c.dp(10))
        toastView.visibility = View.GONE
        addView(
            toastView,
            LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
                bottomMargin = c.dp(40)
            }
        )

        keyboard.onMic = {
            Voice.listen(context, { keyboard.submitText(it) }, { toast(it) })
        }

        tick.run()
        stripTick.run()
        open(startId)
    }

    fun home() = open("home")

    fun open(id: String) {
        if (id == current) return
        hideKeyboard()
        if (overlay.visibility == View.VISIBLE) hideFullscreen()
        current?.let { modules[it]?.onHide() }
        content.removeAllViews()

        val m = modules.getOrPut(id) { factories.getValue(id)() }
        val v = views.getOrPut(id) { m.createView(this) }
        (v.parent as? ViewGroup)?.removeView(v)
        content.addView(v, LayoutParams(Ui.MATCH, Ui.MATCH))
        titleView.text = m.title
        current = id
        setChromeVisible(true)
        m.onShow()
    }

    fun back() {
        if (keyboard.visibility == View.VISIBLE) {
            hideKeyboard()
            return
        }
        if (overlay.visibility == View.VISIBLE) {
            hideFullscreen()
            return
        }
        val c = current ?: return
        if (modules[c]?.onBack() == true) return
        if (c != "home") home()
    }

    private fun stripToggle() {
        val p = PlayerHolder.peek() ?: return
        if (p.isPlaying) p.pause() else p.play()
        updateStrip()
    }

    /** Mesaj bildirimi (8 sn) ve çalan parça şeridi. Müzik/Radyo/IPTV/Ana menüde çalan şerit gizli. */
    private fun updateStrip() {
        val m = NotifyHub.last
        val showMsg = chromeShown && m != null && m.time != dismissedMsg &&
                System.currentTimeMillis() - m.time < 8000
        if (showMsg && m != null) {
            msgRow.text = "💬 " + (if (m.app.isNotEmpty()) m.app + " · " else "") + m.title +
                    (if (m.text.isNotEmpty()) ": " + m.text else "")
            msgRow.visibility = View.VISIBLE
        } else {
            msgRow.visibility = View.GONE
        }

        val p = PlayerHolder.peek()
        val title = p?.mediaMetadata?.title?.toString()
        val showPlay = chromeShown && p != null && !title.isNullOrBlank() &&
                current != "home" && current != "music" && current != "radio" && current != "iptv" &&
                p.currentMediaItem != null &&
                p.playbackState != Player.STATE_IDLE && p.playbackState != Player.STATE_ENDED
        if (showPlay && p != null) {
            val artist = p.mediaMetadata.artist?.toString()
            stripTitle.text = "♫ " + title + (if (!artist.isNullOrBlank()) " · $artist" else "")
            stripPlay.text = if (p.isPlaying) "⏸" else "▶"
            stripNext.visibility = if (p.hasNextMediaItem()) View.VISIBLE else View.GONE
            playRow.visibility = View.VISIBLE
        } else {
            playRow.visibility = View.GONE
        }
        strip.visibility = if (msgRow.visibility == View.VISIBLE || playRow.visibility == View.VISIBLE)
            View.VISIBLE else View.GONE
    }

    /** Telefonda ana menüdeyken geri tuşu uygulamadan çıkar. */
    fun canExit(): Boolean =
        current == "home" && overlay.visibility != View.VISIBLE && keyboard.visibility != View.VISIBLE

    fun setChromeVisible(visible: Boolean) {
        topBar.visibility = if (visible) View.VISIBLE else View.GONE
        if (chromeShown != visible) {
            chromeShown = visible
            host.setImmersive(!visible)
        }
    }

    fun showKeyboard(initial: String, hint: String, done: (String) -> Unit) {
        if (isPhone) {
            systemInput(initial, hint, done) // telefonda gerçek (sistem) klavye
            return
        }
        keyboard.show(initial, hint) {
            keyboard.hide()
            done(it)
        }
    }

    private fun systemInput(initial: String, hint: String, done: (String) -> Unit) {
        val c = context
        val et = EditText(c).apply {
            setText(initial)
            setSelection(text.length)
            this.hint = hint
            setSingleLine()
            imeOptions = EditorInfo.IME_ACTION_GO
            inputType = InputType.TYPE_CLASS_TEXT or
                    (if (hint.startsWith("Adres")) InputType.TYPE_TEXT_VARIATION_URI else 0)
        }
        val box = FrameLayout(c).apply {
            setPadding(c.dp(20), c.dp(8), c.dp(20), 0)
            addView(et, LayoutParams(Ui.MATCH, Ui.WRAP))
        }
        val dialog = AlertDialog.Builder(c)
            .setTitle(hint)
            .setView(box)
            .setPositiveButton("Git") { _, _ -> done(et.text.toString()) }
            .setNegativeButton("İptal", null)
            .setNeutralButton("🎤", null)
            .create()
        et.setOnEditorActionListener { _, _, _ ->
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick()
            true
        }
        dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        dialog.show()
        // 🎤: pencereyi kapatmadan sesle yaz, sonra otomatik gönder
        dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            Voice.listen(c, { t ->
                if (dialog.isShowing) {
                    et.setText(t)
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick()
                }
            }, { toast(it) })
        }
        et.requestFocus()
    }

    fun hideKeyboard() = keyboard.hide()

    fun showFullscreen(v: View, onHidden: () -> Unit) {
        overlay.removeAllViews()
        (v.parent as? ViewGroup)?.removeView(v)
        overlay.addView(v, LayoutParams(Ui.MATCH, Ui.MATCH))
        overlay.visibility = View.VISIBLE
        overlayHidden = onHidden
        setChromeVisible(false)
    }

    fun hideFullscreen() {
        if (overlay.visibility != View.VISIBLE) return
        overlay.visibility = View.GONE
        overlay.removeAllViews()
        setChromeVisible(true)
        val cb = overlayHidden
        overlayHidden = null
        cb?.invoke()
    }

    fun toast(msg: String) {
        toastView.text = msg
        toastView.visibility = View.VISIBLE
        toastView.bringToFront()
        handler.removeCallbacks(hideToast)
        handler.postDelayed(hideToast, 2500)
    }

    fun destroy() {
        handler.removeCallbacksAndMessages(null)
        modules.values.forEach {
            try {
                it.onDestroy()
            } catch (_: Exception) {
            }
        }
        modules.clear()
        views.clear()
    }
}
