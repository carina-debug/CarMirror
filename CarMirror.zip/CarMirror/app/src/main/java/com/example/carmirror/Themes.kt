package com.example.carmirror

data class Theme(
    val id: String,
    val name: String,
    val bg: Int,
    val panel: Int,
    val panel2: Int,
    val accent: Int,
    val muted: Int,
    val homeTop: Int,
    val homeBottom: Int
)

object Themes {

    val all: List<Theme> = listOf(
        Theme(
            "midnight", "Gece Mavisi",
            0xFF070B1F.toInt(), 0xFF111A3A.toInt(), 0xFF1B2757.toInt(), 0xFF3B82F6.toInt(),
            0xFFA9B4D6.toInt(), 0xFF0E1A44.toInt(), 0xFF060A1C.toInt()
        ),
        Theme(
            "purple", "Mor Gece",
            0xFF0C0614.toInt(), 0xFF1A0D2E.toInt(), 0xFF2A1748.toInt(), 0xFF8A2BE2.toInt(),
            0xFFB8AFC6.toInt(), 0xFF1F1038.toInt(), 0xFF080310.toInt()
        ),
        Theme(
            "forest", "Orman",
            0xFF06130D.toInt(), 0xFF0F2A1C.toInt(), 0xFF1A4030.toInt(), 0xFF22C55E.toInt(),
            0xFFA8C9B6.toInt(), 0xFF0F3322.toInt(), 0xFF04100A.toInt()
        ),
        Theme(
            "sunset", "Gün Batımı",
            0xFF1A0A06.toInt(), 0xFF2E1710.toInt(), 0xFF4A2418.toInt(), 0xFFF97316.toInt(),
            0xFFD9B8A8.toInt(), 0xFF3A1A10.toInt(), 0xFF160804.toInt()
        ),
        Theme(
            "ocean", "Okyanus",
            0xFF04141C.toInt(), 0xFF0B2A38.toInt(), 0xFF124357.toInt(), 0xFF06B6D4.toInt(),
            0xFFA6C8D4.toInt(), 0xFF0A3144.toInt(), 0xFF03101A.toInt()
        ),
        Theme(
            "carbon", "Karbon",
            0xFF000000.toInt(), 0xFF121212.toInt(), 0xFF222222.toInt(), 0xFF6B7280.toInt(),
            0xFFB0B0B0.toInt(), 0xFF161616.toInt(), 0xFF000000.toInt()
        )
    )

    fun byId(id: String): Theme = all.firstOrNull { it.id == id } ?: all.first()

    /** Ui renklerini seçilen temaya ayarlar. Arayüz yeniden kurulunca yeni renkler görünür. */
    fun apply(id: String) {
        Ui.applyTheme(byId(id))
    }
}
