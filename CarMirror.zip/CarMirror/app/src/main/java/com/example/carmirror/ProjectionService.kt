package com.example.carmirror

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.IntentCompat

/**
 * MediaProjection'ı yaşatan ön plan servisi.
 * Android 10+ ekran yakalama için ön plan servisi (mediaProjection tipi) zorunlu kılar.
 */
class ProjectionService : Service() {

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val ACTION_STOP = "com.example.carmirror.STOP"
        private const val CHANNEL_ID = "mirror"
        private const val NOTIF_ID = 1
    }

    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            MirrorBridge.release()
            shutdown()
            return START_NOT_STICKY
        }

        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        val data = intent?.let { IntentCompat.getParcelableExtra(it, EXTRA_DATA, Intent::class.java) }
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        // Android 14+: getMediaProjection'dan ÖNCE ön plan servisi başlamış olmalı
        startAsForeground()

        val mpm = getSystemService(MediaProjectionManager::class.java)
        val projection: MediaProjection = mpm.getMediaProjection(code, data)
        // Android 14+: createVirtualDisplay'den önce callback kaydı zorunlu
        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                MirrorBridge.release()
                shutdown()
            }
        }, Handler(Looper.getMainLooper()))
        MirrorBridge.attachProjection(projection)

        acquireScreenLock()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        releaseScreenLock()
        super.onDestroy()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notif_channel),
                NotificationManager.IMPORTANCE_LOW
            )
        )

        val stopIntent = PendingIntent.getService(
            this,
            0,
            Intent(this, ProjectionService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openIntent = PendingIntent.getActivity(
            this,
            1,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setContentIntent(openIntent)
            .setOngoing(true)
            .addAction(0, getString(R.string.notif_stop), stopIntent)
            .build()

        ServiceCompat.startForeground(
            this,
            NOTIF_ID,
            notification,
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        )
    }

    @Suppress("DEPRECATION")
    private fun acquireScreenLock() {
        releaseScreenLock()
        val pm = getSystemService(PowerManager::class.java)
        wakeLock = pm.newWakeLock(
            PowerManager.SCREEN_DIM_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
            "carmirror:screen"
        ).also { it.acquire(4 * 60 * 60 * 1000L) }
    }

    private fun releaseScreenLock() {
        try {
            wakeLock?.let { if (it.isHeld) it.release() }
        } catch (_: Exception) {
        }
        wakeLock = null
    }

    private fun shutdown() {
        releaseScreenLock()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }
}
