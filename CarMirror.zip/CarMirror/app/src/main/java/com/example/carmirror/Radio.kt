package com.example.carmirror

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

data class Station(val name: String, val url: String)

/** Favori istasyonlar (telefondaki "Radyo istasyonlarını düzenle" ekranından da yönetilir). */
object RadioStore {

    private fun sp(ctx: Context) = ctx.getSharedPreferences("radio", Context.MODE_PRIVATE)

    fun load(ctx: Context): MutableList<Station> {
        val raw = sp(ctx).getString("favs", null) ?: return seeds().also { save(ctx, it) }
        val out = ArrayList<Station>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Station(o.getString("name"), o.getString("url")))
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun save(ctx: Context, list: List<Station>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("name", it.name).put("url", it.url)) }
        sp(ctx).edit().putString("favs", arr.toString()).apply()
    }

    fun add(ctx: Context, s: Station) {
        val l = load(ctx)
        if (l.none { it.url == s.url }) {
            l.add(s)
            save(ctx, l)
        }
    }

    fun remove(ctx: Context, url: String) {
        save(ctx, load(ctx).filter { it.url != url })
    }

    // Örnek istasyonlar; istediğini silebilir, kendi istasyonlarını ekleyebilirsin.
    private fun seeds(): MutableList<Station> = mutableListOf(
        Station("SomaFM Groove Salad", "https://ice1.somafm.com/groovesalad-128-mp3"),
        Station("SomaFM Def Con Radio", "https://ice1.somafm.com/defcon-128-mp3"),
        Station("BBC World Service", "https://stream.live.vc.bbcmedia.co.uk/bbc_world_service")
    )
}

/** radio-browser.info açık veritabanından istasyon arar (ülke ve/veya ada göre). */
object RadioApi {

    private val hosts = listOf("de1", "nl1", "at1")

    fun search(name: String?, country: String?): List<Station> {
        val q = StringBuilder("/json/stations/search?hidebroken=true&order=votes&reverse=true&limit=80")
        if (!country.isNullOrBlank()) q.append("&countrycode=").append(country)
        if (!name.isNullOrBlank()) q.append("&name=").append(URLEncoder.encode(name, "UTF-8"))

        var last: Exception? = null
        for (h in hosts) {
            try {
                val conn = URL("https://" + h + ".api.radio-browser.info" + q).openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 12000
                conn.setRequestProperty("User-Agent", "CarMirror/1.0")
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                val arr = JSONArray(body)
                val out = ArrayList<Station>()
                val seen = HashSet<String>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val n = o.optString("name").trim()
                    var u = o.optString("url_resolved")
                    if (u.isBlank()) u = o.optString("url")
                    if (n.isEmpty() || u.isBlank() || !seen.add(n.lowercase())) continue
                    out.add(Station(n, u.trim()))
                }
                return out
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: IOException("Bağlantı kurulamadı")
    }
}

class RadioModule(private val root: RootView) : CarModule {

    override val title = "Radyo"

    private enum class Tab { FAV, TR, SEARCH }

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private var tab = Tab.TR // açılışta yerel (ülke) radyoları göster
    private var trCache: List<Station>? = null
    private var trCountry = ""
    private var searchResults: List<Station> = emptyList()
    private var current: Station? = null
    private var shown = false

    private lateinit var list: RecyclerView
    private lateinit var rowAdapter: RowAdapter<Station>
    private lateinit var info: TextView
    private lateinit var nowName: TextView
    private lateinit var nowSub: TextView
    private lateinit var playBtn: TextView
    private val tabButtons = HashMap<Tab, TextView>()

    private val player get() = PlayerHolder.get(root.context)

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            playBtn.text = if (isPlaying) "⏸" else "▶"
            if (isPlaying) nowSub.text = "Çalıyor"
        }

        override fun onPlaybackStateChanged(state: Int) {
            if (state == Player.STATE_BUFFERING) nowSub.text = "Yükleniyor…"
        }

        override fun onPlayerError(error: PlaybackException) {
            nowSub.text = "Oynatılamadı"
        }
    }

    override fun createView(root: RootView): View {
        val c = root.context

        rowAdapter = RowAdapter { row, s, _ ->
            row.title.text = s.name
            row.subtitle.text = if (s.url == current?.url) "Çalıyor" else (Uri.parse(s.url).host ?: "")
            row.setSelectedRow(s.url == current?.url)
            row.setOnClickListener { play(s) }
            val fav = RadioStore.load(c).any { it.url == s.url }
            when {
                tab == Tab.FAV -> row.setAction("✕") {
                    RadioStore.remove(c, s.url)
                    refreshList()
                }

                fav -> row.setAction("★") {
                    RadioStore.remove(c, s.url)
                    rowAdapter.notifyDataSetChanged()
                }

                else -> row.setAction("☆") {
                    RadioStore.add(c, s)
                    rowAdapter.notifyDataSetChanged()
                    root.toast("Favorilere eklendi")
                }
            }
        }
        list = RecyclerView(c).apply {
            layoutManager = LinearLayoutManager(c)
            adapter = rowAdapter
        }
        info = Ui.label(c, "", 16f, Ui.MUTED).apply { setPadding(c.dp(8), c.dp(4), c.dp(8), c.dp(4)) }

        val tabs = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        fun tabBtn(t: Tab, label: String, onClick: () -> Unit) {
            val b = Ui.button(c, label, if (root.compact) 15f else 18f) { onClick() }
            if (root.compact) b.setPadding(c.dp(4), c.dp(6), c.dp(4), c.dp(6))
            tabButtons[t] = b
            tabs.addView(b, Ui.lin(0, Ui.WRAP, 1f, c.dp(3)))
        }
        tabBtn(Tab.TR, "📍 Yerel") { switchTab(Tab.TR) }
        tabBtn(Tab.FAV, "★ Favoriler") { switchTab(Tab.FAV) }
        tabBtn(Tab.SEARCH, "🔍 Ara") {
            root.showKeyboard("", "İstasyon adı ara") { q ->
                if (q.isNotBlank()) doSearch(q.trim())
            }
        }

        nowName = Ui.label(c, "Bir istasyon seç", 20f, bold = true).apply {
            isSingleLine = true
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        nowSub = Ui.label(c, "", 14f, Ui.MUTED)
        playBtn = Ui.button(c, "▶", 26f, Ui.ACCENT) { togglePlay() }
        val nowCol = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            addView(nowName)
            addView(nowSub)
        }
        val bottom = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = Ui.round(Ui.PANEL, c.dp(12).toFloat())
            setPadding(c.dp(12), c.dp(6), c.dp(8), c.dp(6))
            addView(nowCol, Ui.lin(0, Ui.WRAP, 1f))
            addView(playBtn, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, c.dp(3)))
            addView(Ui.button(c, "⏹", 24f) { stop() }, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, c.dp(3)))
        }

        val col = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(c.dp(8), c.dp(8), c.dp(8), c.dp(8))
        }
        col.addView(tabs, Ui.lin(Ui.MATCH, Ui.WRAP))
        col.addView(info, Ui.lin(Ui.MATCH, Ui.WRAP))

        val mid = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        mid.addView(list, Ui.lin(0, Ui.MATCH, 1f))
        val side = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            addView(Ui.button(c, "▲", 22f) { list.smoothScrollBy(0, -(list.height * 0.8f).toInt()) }, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, c.dp(3)))
            addView(Ui.button(c, "▼", 22f) { list.smoothScrollBy(0, (list.height * 0.8f).toInt()) }, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, c.dp(3)))
        }
        if (!root.isPhone) mid.addView(side, Ui.lin(Ui.WRAP, Ui.MATCH)) // telefonda parmakla kaydır
        col.addView(mid, Ui.lin(Ui.MATCH, 0, 1f))
        col.addView(bottom, Ui.lin(Ui.MATCH, Ui.WRAP).apply { topMargin = c.dp(6) })

        refreshList()
        return col
    }

    override fun onShow() {
        shown = true
        player.addListener(listener)
        playBtn.text = if (player.isPlaying) "⏸" else "▶"
    }

    override fun onHide() {
        shown = false
        player.removeListener(listener)
    }

    override fun onDestroy() {
        io.shutdownNow()
        main.removeCallbacksAndMessages(null)
    }

    // ------------------------------------------------------------------ liste

    private fun switchTab(t: Tab) {
        tab = t
        refreshList()
    }

    private fun refreshList() {
        tabButtons.forEach { (t, b) ->
            b.background = Ui.round(if (t == tab) Ui.ACCENT else Ui.PANEL2, root.context.dp(10).toFloat())
            b.setTextColor(if (t == tab) 0xFFFFFFFF.toInt() else Ui.TEXT)
        }
        when (tab) {
            Tab.FAV -> {
                val favs = RadioStore.load(root.context)
                rowAdapter.items = favs
                info.text = if (favs.isEmpty()) "Favori yok. Türkiye veya Ara sekmesinden ☆ ile ekle." else ""
            }

            Tab.TR -> {
                val cc = CarPrefs.radioCountry(root.context)
                val cached = trCache
                if (cached != null && trCountry == cc) {
                    rowAdapter.items = cached
                    info.text = "Yerel radyolar ($cc) – en popülerler"
                } else {
                    fetch("Yerel radyolar yükleniyor ($cc)…", null, cc) {
                        trCache = it
                        trCountry = cc
                        if (tab == Tab.TR) refreshList()
                    }
                }
            }

            Tab.SEARCH -> {
                rowAdapter.items = searchResults
                info.text = if (searchResults.isEmpty()) "Arama sonucu yok" else "${searchResults.size} sonuç"
            }
        }
    }

    private fun doSearch(q: String) {
        tab = Tab.SEARCH
        fetch("Aranıyor: $q …", q, null) {
            searchResults = it
            if (tab == Tab.SEARCH) refreshList()
        }
        refreshList()
    }

    private fun fetch(message: String, name: String?, country: String?, done: (List<Station>) -> Unit) {
        info.text = message
        rowAdapter.items = emptyList()
        io.execute {
            try {
                val res = RadioApi.search(name, country)
                main.post { done(res) }
            } catch (e: Exception) {
                main.post { info.text = "Yüklenemedi: ${e.message ?: "bağlantı hatası"}" }
            }
        }
    }

    // --------------------------------------------------------------- oynatma

    private fun play(s: Station) {
        val p = player
        p.setMediaItem(
            MediaItem.Builder()
                .setUri(s.url)
                .setMediaMetadata(MediaMetadata.Builder().setTitle(s.name).setArtist("Radyo").build())
                .build()
        )
        p.prepare()
        p.play()
        current = s
        nowName.text = s.name
        nowSub.text = "Yükleniyor…"
        rowAdapter.notifyDataSetChanged()
    }

    private fun togglePlay() {
        val p = player
        if (p.isPlaying) {
            p.pause()
        } else {
            val s = current ?: return
            if (p.mediaItemCount == 0 || p.playbackState == Player.STATE_IDLE) play(s) else p.play()
        }
    }

    private fun stop() {
        val p = player
        p.stop()
        p.clearMediaItems()
        nowSub.text = "Durduruldu"
    }
}
