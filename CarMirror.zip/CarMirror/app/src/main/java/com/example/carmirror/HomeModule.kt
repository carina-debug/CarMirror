package com.example.carmirror

import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/** Ana menü: cam görünümlü kartlar ve renkli uygulama ikonları. Sıra ve renkler Ayarlar'dan değişir. */
class HomeModule(private val root: RootView) : CarModule {

    override val title = "Ana menü"

    private lateinit var holder: FrameLayout

    override fun createView(root: RootView): View {
        holder = FrameLayout(root.context)
        rebuild()
        return holder
    }

    // Ayarlar'da sıra değişmiş olabilir; her gösterimde yeniden kur.
    override fun onShow() {
        rebuild()
    }

    private fun rebuild() {
        val c = root.context
        holder.removeAllViews()
        holder.addView(buildGrid(), FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
    }

    private fun buildGrid(): View {
        val c = root.context
        val grid = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(c.dp(14), c.dp(14), c.dp(14), c.dp(14))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Ui.HOME_TOP, Ui.HOME_BOTTOM)
            )
        }
        Apps.ordered(c).chunked(5).forEach { rowApps ->
            val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
            rowApps.forEach { app -> row.addView(tileView(app), Ui.lin(0, Ui.MATCH, 1f, c.dp(7))) }
            grid.addView(row, Ui.lin(Ui.MATCH, 0, 1f))
        }
        return grid
    }

    private fun tileView(app: App): View {
        val c = root.context
        val card = GradientDrawable().apply {
            setColor(0x16FFFFFF)
            cornerRadius = c.dp(20).toFloat()
            setStroke(c.dp(1), 0x2EFFFFFF)
        }
        val icon = TextView(c).apply {
            text = app.glyph
            textSize = 34f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            background = Ui.gradient(app.c1, app.c2, c.dp(18).toFloat())
        }
        return LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = card
            isClickable = true
            addView(icon, LinearLayout.LayoutParams(c.dp(76), c.dp(76)))
            addView(
                Ui.label(c, app.label, 17f, bold = true).apply {
                    gravity = Gravity.CENTER
                    isSingleLine = true
                },
                Ui.lin(Ui.WRAP, Ui.WRAP).apply { topMargin = c.dp(12) }
            )
            setOnClickListener {
                if (app.id == "mirror") root.host.enterMirror() else root.open(app.id)
            }
        }
    }
}
