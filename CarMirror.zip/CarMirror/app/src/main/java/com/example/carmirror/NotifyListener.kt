package com.example.carmirror

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Son mesaj bildirimi; RootView üstte kısa süre şerit olarak gösterir. */
object NotifyHub {
    data class Msg(val app: String, val title: String, val text: String, val time: Long)

    @Volatile
    var last: Msg? = null
}

/**
 * Mesaj/e-posta/arama bildirimlerini okuyup araç ekranı şeridine aktarır.
 * Bildirim erişimi telefonda ayrıca açılmalıdır; veriler cihazdan çıkmaz, saklanmaz.
 */
class NotifyListener : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
        val cat = n.category
        if (cat != Notification.CATEGORY_MESSAGE &&
            cat != Notification.CATEGORY_EMAIL &&
            cat != Notification.CATEGORY_CALL
        ) return
        val e = n.extras ?: return
        val title = e.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = e.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        val app = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (_: Exception) {
            ""
        }
        NotifyHub.last = NotifyHub.Msg(app, title, text, System.currentTimeMillis())
    }
}
