package com.example.carmirror

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private lateinit var statusText: TextView
    private val handler = Handler(Looper.getMainLooper())

    private val captureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            if (result.resultCode == Activity.RESULT_OK && data != null) {
                val svc = Intent(this, ProjectionService::class.java)
                    .putExtra(ProjectionService.EXTRA_CODE, result.resultCode)
                    .putExtra(ProjectionService.EXTRA_DATA, data)
                ContextCompat.startForegroundService(this, svc)
            } else {
                Toast.makeText(this, R.string.toast_denied, Toast.LENGTH_SHORT).show()
            }
            refreshLater()
        }

    private val permsLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)

        findViewById<Button>(R.id.btnPerms).setOnClickListener {
            permsLauncher.launch(Perms.requestList())
        }
        findViewById<Button>(R.id.btnRadio).setOnClickListener {
            startActivity(Intent(this, RadioEditActivity::class.java))
        }
        findViewById<Button>(R.id.btnIptv).setOnClickListener {
            startActivity(Intent(this, IptvSettingsActivity::class.java))
        }
        findViewById<Button>(R.id.btnA11y).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.btnStart).setOnClickListener { startCapture() }
        findViewById<Button>(R.id.btnStop).setOnClickListener {
            startService(
                Intent(this, ProjectionService::class.java).setAction(ProjectionService.ACTION_STOP)
            )
            refreshLater()
        }

        // İlk açılışta medya + bildirim izinlerini iste
        if (!Perms.hasAudio(this) || !Perms.hasVisual(this)) {
            permsLauncher.launch(Perms.requestList())
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun startCapture() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val intent = if (Build.VERSION.SDK_INT >= 34) {
            // Android 14+: "tek uygulama" yerine tüm ekranı paylaşmaya zorla
            mpm.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
        } else {
            mpm.createScreenCaptureIntent()
        }
        captureLauncher.launch(intent)
    }

    private fun refreshLater() {
        handler.postDelayed({ refresh() }, 600)
    }

    private fun refresh() {
        val capture = MirrorBridge.projection != null
        val touch = isAccessibilityEnabled()
        val car = MirrorBridge.hasCarSurface

        statusText.text = buildString {
            appendLine("Araç ekranı: " + if (car) "BAĞLI" else "bağlı değil")
            appendLine("Medya izinleri: " + if (Perms.hasAudio(this@MainActivity) && Perms.hasVisual(this@MainActivity)) "verildi" else "eksik")
            appendLine("Telefon ekranı yansıtma: " + if (capture) "AÇIK" else "kapalı")
            appendLine("Dokunma iletimi (yansıtma için): " + if (touch) "AÇIK" else "kapalı")
            appendLine()
            appendLine("Tarayıcı, Müzik, Radyo, Galeri ve IPTV modülleri için yansıtmaya gerek yok: sadece medya izinlerini ver, arabada \"Araç Ekranı\" uygulamasını aç.")
            append("Yalnızca \"Telefon ekranı\" kutusu için yansıtmayı başlat ve dokunma iletimini aç.")
        }
    }

    private fun isAccessibilityEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val me = ComponentName(this, TouchForwardService::class.java).flattenToString()
        return enabled.split(':').any { it.equals(me, ignoreCase = true) }
    }
}
