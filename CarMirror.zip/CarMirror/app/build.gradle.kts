plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

fun secret(name: String): String? =
    System.getenv(name)?.takeIf { it.isNotBlank() }
        ?: (project.findProperty(name) as String?)?.takeIf { it.isNotBlank() }

android {
    namespace = "com.example.carmirror"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.carmirror"
        minSdk = 29
        targetSdk = 34
        versionCode = 10
        versionName = "3.6"
        // Güncelleme denetimi için "kullanici/depo" (GitHub Actions bunu otomatik verir)
        buildConfigField("String", "UPDATE_REPO", "\"${secret("CM_UPDATE_REPO") ?: ""}\"")
    }

    // İmza anahtarı ve şifreleri repoda TUTULMAZ. Şu sırayla aranır:
    //   1) ortam değişkenleri (GitHub Actions Secrets bunları verir)
    //   2) ~/.gradle/gradle.properties veya proje gradle.properties (git'e koyma!)
    // Hiçbiri yoksa (anahtarın olmayan biri derlerse) standart debug anahtarıyla imzalanır.
    val ksPath = secret("CM_KEYSTORE_PATH")
    val ksPass = secret("CM_STORE_PASSWORD")
    val ksAlias = secret("CM_KEY_ALIAS")
    val keyPass = secret("CM_KEY_PASSWORD")
    val hasSharedKey = ksPath != null && file(ksPath).exists() &&
        ksPass != null && ksAlias != null && keyPass != null

    signingConfigs {
        if (hasSharedKey) {
            create("shared") {
                storeFile = file(ksPath!!)
                storePassword = ksPass
                keyAlias = ksAlias
                keyPassword = keyPass
            }
        }
    }

    // Aynı anahtarla imzalanınca yeni sürüm eskisinin üzerine güncelleme olarak kurulur.
    val signing = if (hasSharedKey) signingConfigs.getByName("shared") else signingConfigs.getByName("debug")

    buildTypes {
        debug {
            signingConfig = signing
        }
        release {
            isMinifyEnabled = false
            signingConfig = signing
        }
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.activity:activity-ktx:1.8.2")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.car.app:app:1.4.0")
    implementation("androidx.webkit:webkit:1.10.0")

    // Müzik, radyo, galeri videosu ve IPTV oynatma
    implementation("androidx.media3:media3-exoplayer:1.3.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.3.1")
    implementation("androidx.media3:media3-exoplayer-dash:1.3.1")
    implementation("androidx.media3:media3-session:1.3.1") // bildirim, medya tuşları, arka planda çalma
}
