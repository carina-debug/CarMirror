package com.example.carmirror

import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import java.io.File

private fun ComponentActivity.page(build: LinearLayout.() -> Unit) {
    val pad = dp(16)
    val col = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(pad, pad, pad, pad)
    }
    col.build()
    setContentView(
        ScrollView(this).apply {
            addView(col, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
    )
}

/** Telefonda radyo favorilerini ekleme/silme ekranı. */
class RadioEditActivity : ComponentActivity() {

    private lateinit var listBox: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Radyo istasyonları"

        val name = EditText(this).apply {
            hint = "İstasyon adı"
            setSingleLine()
        }
        val url = EditText(this).apply {
            hint = "Yayın adresi (http://... veya https://...)"
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val add = Button(this).apply {
            text = "Ekle"
            setOnClickListener {
                val n = name.text.toString().trim()
                val u = url.text.toString().trim()
                if (n.isEmpty() || !(u.startsWith("http://") || u.startsWith("https://"))) {
                    Toast.makeText(this@RadioEditActivity, "Ad ve geçerli bir adres gir", Toast.LENGTH_SHORT).show()
                } else {
                    RadioStore.add(this@RadioEditActivity, Station(n, u))
                    name.setText("")
                    url.setText("")
                    render()
                }
            }
        }

        page {
            addView(TextView(this@RadioEditActivity).apply {
                text = "Araçtaki Radyo > Favoriler sekmesinde görünür. Türkiye ve Ara sekmelerinden de araçta ☆ ile ekleyebilirsin."
            })
            addView(name)
            addView(url)
            addView(add)
            addView(listBox)
        }
        render()
    }

    private fun render() {
        listBox.removeAllViews()
        RadioStore.load(this).forEach { s ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(8), 0, dp(8))
            }
            row.addView(
                TextView(this).apply { text = "${s.name}\n${s.url}" },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )
            row.addView(Button(this).apply {
                text = "Sil"
                setOnClickListener {
                    RadioStore.remove(this@RadioEditActivity, s.url)
                    render()
                }
            })
            listBox.addView(row)
        }
    }
}

/** IPTV M3U adresi veya Xtream bilgileri. */
class IptvSettingsActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "IPTV ayarları"

        fun field(hintText: String, key: String, password: Boolean = false) = EditText(this).apply {
            hint = hintText
            setSingleLine()
            setText(IptvPrefs.raw(this@IptvSettingsActivity, key))
            inputType = if (password) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }

        val url = field("M3U adresi (http://.../liste.m3u)", "url")
        val host = field("Xtream sunucu (örn. http://sunucu:8080)", "xhost")
        val user = field("Xtream kullanıcı adı", "xuser")
        val pass = field("Xtream şifre", "xpass", password = true)

        val save = Button(this).apply {
            text = "Kaydet"
            setOnClickListener {
                IptvPrefs.save(
                    this@IptvSettingsActivity,
                    url.text.toString(),
                    host.text.toString(),
                    user.text.toString(),
                    pass.text.toString()
                )
                Toast.makeText(this@IptvSettingsActivity, "Kaydedildi", Toast.LENGTH_SHORT).show()
            }
        }
        val clear = Button(this).apply {
            text = "Önbelleği temizle (listeyi yeniden indir)"
            setOnClickListener {
                File(cacheDir, "iptv.m3u").delete()
                Toast.makeText(this@IptvSettingsActivity, "Temizlendi", Toast.LENGTH_SHORT).show()
            }
        }

        page {
            addView(TextView(this@IptvSettingsActivity).apply {
                text = "Ya doğrudan bir M3U adresi gir, ya da Xtream sunucu/kullanıcı/şifre doldur " +
                        "(Xtream doluysa o kullanılır). Kendi sahip olduğun / aboneliğin olan listeleri kullan."
            })
            addView(url)
            addView(host)
            addView(user)
            addView(pass)
            addView(save)
            addView(clear)
        }
    }
}
