package com.example.carmirror

import android.content.Context
import android.content.Intent
import android.os.Build

/** Android Auto'nun uygulamayı neden göstermediğini anlamak için telefon tarafı kontroller. */
object AutoDiag {

    private const val GEARHEAD = "com.google.android.projection.gearhead"

    fun report(ctx: Context): String {
        val app = ctx.applicationContext
        val pm = app.packageManager
        val sb = StringBuilder()

        val aa = try {
            pm.getPackageInfo(GEARHEAD, 0).versionName ?: "?"
        } catch (_: Exception) {
            null
        }
        sb.append(if (aa != null) "✓ Android Auto yüklü (sürüm $aa)\n" else "✗ Android Auto görünmüyor (yüklü değil veya devre dışı)\n")

        val svc = pm.queryIntentServices(
            Intent("androidx.car.app.CarAppService")
                .setPackage(app.packageName)
                .addCategory("androidx.car.app.category.NAVIGATION"),
            0
        ).size
        sb.append(if (svc > 0) "✓ Araç servisi kayıtlı (navigasyon)\n" else "✗ Araç servisi kayıtlı değil\n")

        sb.append("Android: ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})\n")
        sb.append(SelfInstaller.installSource(app)).append("\n\n")

        sb.append(
            "Sırayla dene:\n" +
                    "1) Android Auto > Sürüm satırına 10 kez dokun > Geliştirici ayarlarını aç.\n" +
                    "2) ⋮ > Geliştirici ayarları > \"Bilinmeyen kaynaklar\"ı aç.\n" +
                    "3) Aynı ekranda \"Uygulama modu\"nu Geliştirici yap (varsa).\n" +
                    "4) Android Auto > Ayarlar > Menüyü özelleştir: Araç Ekranı işaretli olsun.\n" +
                    "5) Android Auto'yu Zorla durdur, önbelleği temizle; arabadan bağlantıyı kesip yeniden bağlan.\n" +
                    "6) Olmazsa \"Alternatif yöntemle etkinleştir\"i dene, sonra telefonu yeniden başlat."
        )
        return sb.toString()
    }
}
