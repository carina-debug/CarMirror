package com.example.carmirror

import android.content.ContentResolver
import android.content.ContentUris
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.media3.common.MediaItem
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

/** Telefondaki fotoğraf ve videoları ızgara halinde gösterir; tam ekran görüntüleyici + slayt gösterisi. */
class GalleryModule(private val root: RootView) : CarModule {

    override val title = "Galeri"

    private data class Item(val id: Long, val video: Boolean, val name: String, val uri: Uri)

    private companion object {
        const val SLIDE_MS = 5000L
    }

    /** Izgara sütun sayısı: araçta 5, telefonda (dikey) 3. */
    private val span: Int get() = if (root.compact) 3 else 5

    private val main = Handler(Looper.getMainLooper())
    private val thumbPool = Executors.newFixedThreadPool(3)
    private val loader = Executors.newSingleThreadExecutor()
    private val cache = LruCache<Long, Bitmap>(250)

    private var items: List<Item> = emptyList()
    private var loaded = false
    private var index = -1
    private var slideshow = false
    private var videoActive = false
    private var viewToken = 0

    private lateinit var grid: RecyclerView
    private lateinit var info: TextView
    private lateinit var viewer: FrameLayout
    private lateinit var imageView: ImageView
    private lateinit var videoSurface: VideoSurface
    private lateinit var viewerTitle: TextView
    private lateinit var videoControls: LinearLayout
    private lateinit var slideBtn: TextView

    private val slideRunnable = Runnable {
        if (slideshow && viewer.visibility == View.VISIBLE) step(1)
    }

    private inner class Cell(val box: FrameLayout, val img: ImageView, val mark: TextView) :
        RecyclerView.ViewHolder(box) {
        var token = 0L
    }

    private inner class GridAdapter : RecyclerView.Adapter<Cell>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Cell {
            val c = parent.context
            val size = if (parent.width > 0) parent.width / span else c.dp(150)
            val box = FrameLayout(c).apply {
                layoutParams = RecyclerView.LayoutParams(size, size)
                setPadding(c.dp(2), c.dp(2), c.dp(2), c.dp(2))
                isClickable = true
            }
            val img = ImageView(c).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(Ui.PANEL)
            }
            val mark = Ui.label(c, "▶", 22f, bold = true).apply {
                gravity = Gravity.CENTER
                setBackgroundColor(0x88000000.toInt())
                setPadding(c.dp(8), c.dp(2), c.dp(8), c.dp(2))
            }
            box.addView(img, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
            box.addView(mark, FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.BOTTOM or Gravity.START))
            return Cell(box, img, mark)
        }

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: Cell, pos: Int) {
            val item = items[pos]
            h.mark.visibility = if (item.video) View.VISIBLE else View.GONE
            h.token = item.id
            val cached = cache.get(item.id)
            if (cached != null) {
                h.img.setImageBitmap(cached)
            } else {
                h.img.setImageDrawable(null)
                val resolver = root.context.contentResolver
                thumbPool.execute {
                    val b = try {
                        resolver.loadThumbnail(item.uri, Size(256, 256), null)
                    } catch (_: Exception) {
                        null
                    }
                    if (b != null) {
                        cache.put(item.id, b)
                        main.post { if (h.token == item.id) h.img.setImageBitmap(b) }
                    }
                }
            }
            h.box.setOnClickListener {
                val p = h.bindingAdapterPosition
                if (p != RecyclerView.NO_POSITION) openViewer(p)
            }
        }
    }

    override fun createView(root: RootView): View {
        val c = root.context

        grid = RecyclerView(c).apply {
            layoutManager = GridLayoutManager(c, span)
            adapter = GridAdapter()
        }
        info = Ui.label(c, "", 16f, Ui.MUTED).apply { setPadding(c.dp(8), c.dp(4), c.dp(8), c.dp(4)) }

        val browse = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        browse.addView(info, Ui.lin(Ui.MATCH, Ui.WRAP))
        browse.addView(grid, Ui.lin(Ui.MATCH, 0, 1f))
        if (!root.isPhone) browse.addView(Ui.pager(c, grid), Ui.lin(Ui.MATCH, Ui.WRAP))

        // ---- görüntüleyici
        imageView = ImageView(c).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        videoSurface = VideoSurface(c)
        viewerTitle = Ui.label(c, "", 16f, 0xFFD1D5DB.toInt()).apply {
            gravity = Gravity.CENTER
            isSingleLine = true
        }
        slideBtn = Ui.button(c, "▶ Slayt", 16f) { toggleSlideshow() }

        videoControls = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            addView(Ui.button(c, "⏪ 10", 16f) { seekVideo(-10_000) }, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, c.dp(3)))
            addView(Ui.button(c, "⏯", 22f, Ui.ACCENT) { toggleVideo() }, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, c.dp(3)))
            addView(Ui.button(c, "10 ⏩", 16f) { seekVideo(10_000) }, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, c.dp(3)))
        }
        val nav = LinearLayout(c).apply {
            setBackgroundColor(0xCC000000.toInt())
            setPadding(c.dp(6), c.dp(6), c.dp(6), c.dp(6))
            if (root.compact) {
                // Telefon (dikey): iki satır — gezinme + video/slayt kontrolleri
                orientation = LinearLayout.VERTICAL
                val r1 = LinearLayout(c).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    addView(Ui.button(c, "✕", 18f) { closeViewer() }, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, c.dp(3)))
                    addView(Ui.button(c, "⏮", 22f) { step(-1) }, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, c.dp(3)))
                    addView(viewerTitle, Ui.lin(0, Ui.WRAP, 1f, c.dp(6)))
                    addView(Ui.button(c, "⏭", 22f) { step(1) }, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, c.dp(3)))
                }
                val r2 = LinearLayout(c).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER
                    addView(videoControls, Ui.lin(Ui.WRAP, Ui.WRAP))
                    addView(slideBtn, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, c.dp(3)))
                }
                addView(r1, Ui.lin(Ui.MATCH, Ui.WRAP))
                addView(r2, Ui.lin(Ui.MATCH, Ui.WRAP))
            } else {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                addView(Ui.button(c, "✕ Kapat", 16f) { closeViewer() }, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, c.dp(3)))
                addView(Ui.button(c, "⏮", 22f) { step(-1) }, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, c.dp(3)))
                addView(viewerTitle, Ui.lin(0, Ui.WRAP, 1f, c.dp(6)))
                addView(videoControls, Ui.lin(Ui.WRAP, Ui.WRAP))
                addView(slideBtn, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, c.dp(3)))
                addView(Ui.button(c, "⏭", 22f) { step(1) }, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, c.dp(3)))
            }
        }

        viewer = FrameLayout(c).apply {
            setBackgroundColor(0xFF000000.toInt())
            visibility = View.GONE
            isClickable = true
            addView(imageView, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
            addView(videoSurface, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
            addView(nav, FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP, Gravity.BOTTOM))
        }

        return FrameLayout(c).apply {
            addView(browse, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
            addView(viewer, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        }
    }

    override fun onShow() {
        load()
    }

    override fun onHide() {
        closeViewer()
    }

    override fun onBack(): Boolean {
        if (viewer.visibility == View.VISIBLE) {
            closeViewer()
            return true
        }
        return false
    }

    override fun onDestroy() {
        closeViewer()
        main.removeCallbacksAndMessages(null)
        thumbPool.shutdownNow()
        loader.shutdownNow()
    }

    // ------------------------------------------------------------------ veri

    private fun load() {
        if (loaded) return
        if (!Perms.hasVisual(root.context)) {
            info.text = if (root.isPhone) "Fotoğraf/video izni yok. Ayarlar > Genel > Kurulum bölümünden 'Medya izinlerini ver'e bas."
            else "Fotoğraf/video izni yok. Telefonda uygulamayı açıp 'Medya izinlerini ver'e bas."
            return
        }
        info.text = "Yükleniyor…"
        val resolver = root.context.contentResolver
        loader.execute {
            val out = ArrayList<Item>()
            try {
                val files = MediaStore.Files.getContentUri("external")
                val mt = MediaStore.Files.FileColumns.MEDIA_TYPE
                val args = Bundle().apply {
                    putString(ContentResolver.QUERY_ARG_SQL_SELECTION, "$mt=? OR $mt=?")
                    putStringArray(
                        ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS,
                        arrayOf(
                            MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE.toString(),
                            MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO.toString()
                        )
                    )
                    putStringArray(
                        ContentResolver.QUERY_ARG_SORT_COLUMNS,
                        arrayOf(MediaStore.Files.FileColumns.DATE_ADDED)
                    )
                    putInt(
                        ContentResolver.QUERY_ARG_SORT_DIRECTION,
                        ContentResolver.QUERY_SORT_DIRECTION_DESCENDING
                    )
                    putInt(ContentResolver.QUERY_ARG_LIMIT, 800)
                }
                resolver.query(
                    files,
                    arrayOf(
                        MediaStore.Files.FileColumns._ID,
                        mt,
                        MediaStore.Files.FileColumns.DISPLAY_NAME
                    ),
                    args,
                    null
                )?.use { cur ->
                    while (cur.moveToNext()) {
                        val id = cur.getLong(0)
                        val video = cur.getInt(1) == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO
                        val base = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                        else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                        out.add(Item(id, video, cur.getString(2) ?: "", ContentUris.withAppendedId(base, id)))
                    }
                }
            } catch (_: Exception) {
            }
            main.post {
                items = out
                loaded = true
                grid.adapter?.notifyDataSetChanged()
                info.text = if (out.isEmpty()) "Fotoğraf/video bulunamadı" else "${out.size} öğe"
            }
        }
    }

    // ----------------------------------------------------------- görüntüleyici

    private fun openViewer(i: Int) {
        index = i
        viewer.visibility = View.VISIBLE
        showCurrent()
    }

    private fun closeViewer() {
        main.removeCallbacks(slideRunnable)
        slideshow = false
        if (::slideBtn.isInitialized) slideBtn.text = "▶ Slayt"
        stopVideo()
        if (::viewer.isInitialized) viewer.visibility = View.GONE
    }

    private fun step(delta: Int) {
        if (items.isEmpty()) return
        index = (index + delta + items.size) % items.size
        showCurrent()
    }

    private fun showCurrent() {
        main.removeCallbacks(slideRunnable)
        stopVideo()
        val item = items.getOrNull(index) ?: return
        viewerTitle.text = "${index + 1}/${items.size}  ${item.name}"

        if (item.video) {
            imageView.visibility = View.GONE
            videoSurface.visibility = View.VISIBLE
            videoControls.visibility = View.VISIBLE
            val p = PlayerHolder.get(root.context)
            videoSurface.attach(p)
            p.setMediaItem(MediaItem.fromUri(item.uri))
            p.prepare()
            p.play()
            videoActive = true
        } else {
            videoSurface.visibility = View.GONE
            videoControls.visibility = View.GONE
            imageView.visibility = View.VISIBLE
            imageView.setImageDrawable(null)
            val token = ++viewToken
            val resolver = root.context.contentResolver
            loader.execute {
                val b = try {
                    resolver.loadThumbnail(item.uri, Size(1920, 1080), null)
                } catch (_: Exception) {
                    null
                }
                main.post { if (token == viewToken && b != null) imageView.setImageBitmap(b) }
            }
            if (slideshow) main.postDelayed(slideRunnable, SLIDE_MS)
        }
    }

    private fun toggleSlideshow() {
        slideshow = !slideshow
        slideBtn.text = if (slideshow) "⏸ Slayt" else "▶ Slayt"
        main.removeCallbacks(slideRunnable)
        if (slideshow) {
            val item = items.getOrNull(index)
            if (item != null && !item.video) main.postDelayed(slideRunnable, SLIDE_MS)
            else root.toast("Slayt gösterisi fotoğraflarda çalışır")
        }
    }

    private fun stopVideo() {
        if (!videoActive) return
        videoActive = false
        val p = PlayerHolder.get(root.context)
        p.stop()
        p.clearMediaItems()
        videoSurface.detach()
    }

    private fun toggleVideo() {
        if (!videoActive) return
        val p = PlayerHolder.get(root.context)
        if (p.isPlaying) p.pause() else p.play()
    }

    private fun seekVideo(deltaMs: Long) {
        if (!videoActive) return
        val p = PlayerHolder.get(root.context)
        p.seekTo((p.currentPosition + deltaMs).coerceAtLeast(0L))
    }
}
