package com.example.carmirror

import android.graphics.Bitmap
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Size
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

/** Telefondaki müzik dosyalarını çalar. (YouTube Music için Tarayıcı modülündeki kısayolu kullan.) */
class MusicModule(private val root: RootView) : CarModule {

    override val title = "Müzik"

    private data class Track(val id: Long, val title: String, val artist: String, val uri: Uri)

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private var tracks: List<Track> = emptyList()
    private var loaded = false
    private var shown = false
    private var userSeeking = false
    private var artToken = 0

    private lateinit var list: RecyclerView
    private lateinit var rowAdapter: RowAdapter<Track>
    private lateinit var info: TextView
    private lateinit var nowTitle: TextView
    private lateinit var nowArtist: TextView
    private lateinit var art: ImageView
    private lateinit var seek: SeekBar
    private lateinit var timeView: TextView
    private lateinit var playBtn: TextView
    private lateinit var shuffleBtn: TextView
    private lateinit var repeatBtn: TextView

    private val player: ExoPlayer get() = PlayerHolder.get(root.context)

    private val listener = object : Player.Listener {
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            refreshNow()
            rowAdapter.notifyDataSetChanged()
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            playBtn.text = if (isPlaying) "⏸" else "▶"
        }

        override fun onPlayerError(error: PlaybackException) {
            root.toast("Oynatma hatası")
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            updateProgress()
            if (shown) main.postDelayed(this, 500)
        }
    }

    override fun createView(root: RootView): View {
        val c = root.context

        rowAdapter = RowAdapter { row, t, pos ->
            row.title.text = t.title
            row.subtitle.text = t.artist
            row.setAction(null)
            row.setSelectedRow(player.currentMediaItem?.mediaId == t.id.toString())
            row.setOnClickListener { play(pos) }
        }
        list = RecyclerView(c).apply {
            layoutManager = LinearLayoutManager(c)
            adapter = rowAdapter
        }
        info = Ui.label(c, "", 16f, Ui.MUTED).apply { setPadding(c.dp(8), c.dp(4), c.dp(8), c.dp(4)) }

        val left = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        left.addView(info, Ui.lin(Ui.MATCH, Ui.WRAP))
        left.addView(list, Ui.lin(Ui.MATCH, 0, 1f))
        left.addView(Ui.pager(c, list), Ui.lin(Ui.MATCH, Ui.WRAP))

        art = ImageView(c).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = Ui.round(Ui.PANEL, c.dp(14).toFloat())
            clipToOutline = true
        }
        nowTitle = Ui.label(c, "Şarkı seç", 24f, bold = true).apply {
            gravity = Gravity.CENTER
            isSingleLine = true
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        nowArtist = Ui.label(c, "", 17f, Ui.MUTED).apply { gravity = Gravity.CENTER }
        seek = SeekBar(c).apply {
            max = 1
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {}
                override fun onStartTrackingTouch(sb: SeekBar?) {
                    userSeeking = true
                }

                override fun onStopTrackingTouch(sb: SeekBar?) {
                    userSeeking = false
                    player.seekTo((sb?.progress ?: 0) * 1000L)
                }
            })
        }
        timeView = Ui.label(c, "0:00 / 0:00", 15f, Ui.MUTED).apply { gravity = Gravity.CENTER }

        playBtn = Ui.button(c, "▶", 28f, Ui.ACCENT) { togglePlay() }
        shuffleBtn = Ui.button(c, "🔀 Kapalı", 15f) { toggleShuffle() }
        repeatBtn = Ui.button(c, "🔁 Kapalı", 15f) { toggleRepeat() }

        val controls = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            addView(Ui.button(c, "⏮", 26f) { player.seekToPreviousMediaItem() }, Ui.lin(0, Ui.WRAP, 1f, c.dp(4)))
            addView(playBtn, Ui.lin(0, Ui.WRAP, 1.3f, c.dp(4)))
            addView(Ui.button(c, "⏭", 26f) { player.seekToNextMediaItem() }, Ui.lin(0, Ui.WRAP, 1f, c.dp(4)))
        }
        val toggles = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(shuffleBtn, Ui.lin(0, Ui.WRAP, 1f, c.dp(4)))
            addView(repeatBtn, Ui.lin(0, Ui.WRAP, 1f, c.dp(4)))
        }

        val right = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(c.dp(10), c.dp(6), c.dp(10), c.dp(6))
            addView(art, Ui.lin(c.dp(200), c.dp(200)))
            addView(nowTitle, Ui.lin(Ui.MATCH, Ui.WRAP).apply { topMargin = c.dp(10) })
            addView(nowArtist, Ui.lin(Ui.MATCH, Ui.WRAP))
            addView(seek, Ui.lin(Ui.MATCH, Ui.WRAP).apply { topMargin = c.dp(8) })
            addView(timeView, Ui.lin(Ui.MATCH, Ui.WRAP))
            addView(controls, Ui.lin(Ui.MATCH, Ui.WRAP).apply { topMargin = c.dp(8) })
            addView(toggles, Ui.lin(Ui.MATCH, Ui.WRAP).apply { topMargin = c.dp(4) })
        }

        return LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(c.dp(8), c.dp(8), c.dp(8), c.dp(8))
            addView(left, Ui.lin(0, Ui.MATCH, 1f, c.dp(4)))
            addView(right, Ui.lin(0, Ui.MATCH, 1f, c.dp(4)))
        }
    }

    override fun onShow() {
        shown = true
        load()
        player.addListener(listener)
        playBtn.text = if (player.isPlaying) "⏸" else "▶"
        refreshNow()
        updateToggleLabels()
        main.post(ticker)
    }

    override fun onHide() {
        shown = false
        main.removeCallbacks(ticker)
        player.removeListener(listener)
    }

    override fun onDestroy() {
        shown = false
        main.removeCallbacksAndMessages(null)
        io.shutdownNow()
    }

    // ------------------------------------------------------------------ veri

    private fun load() {
        if (loaded) return
        if (!Perms.hasAudio(root.context)) {
            info.text = "Müzik izni yok. Telefonda uygulamayı açıp 'Medya izinlerini ver'e bas."
            return
        }
        info.text = "Yükleniyor…"
        val resolver = root.context.contentResolver
        io.execute {
            val out = ArrayList<Track>()
            try {
                resolver.query(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    arrayOf(
                        MediaStore.Audio.Media._ID,
                        MediaStore.Audio.Media.TITLE,
                        MediaStore.Audio.Media.ARTIST
                    ),
                    "${MediaStore.Audio.Media.IS_MUSIC}!=0",
                    null,
                    "${MediaStore.Audio.Media.TITLE} ASC"
                )?.use { cur ->
                    while (cur.moveToNext()) {
                        val id = cur.getLong(0)
                        val artist = cur.getString(2)
                        out.add(
                            Track(
                                id,
                                cur.getString(1) ?: "Adsız",
                                if (artist == null || artist == "<unknown>") "Bilinmeyen sanatçı" else artist,
                                Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id.toString())
                            )
                        )
                    }
                }
            } catch (_: Exception) {
            }
            main.post {
                tracks = out
                loaded = true
                rowAdapter.items = out
                info.text = if (out.isEmpty()) "Müzik bulunamadı" else "${out.size} şarkı"
            }
        }
    }

    // --------------------------------------------------------------- oynatma

    private fun play(index: Int) {
        if (tracks.isEmpty()) return
        val p = player
        val sameQueue = p.mediaItemCount == tracks.size &&
                p.getMediaItemAt(0).mediaId == tracks.first().id.toString()
        if (sameQueue) {
            p.seekTo(index, 0L)
        } else {
            val items = tracks.map {
                MediaItem.Builder().setUri(it.uri).setMediaId(it.id.toString()).build()
            }
            p.setMediaItems(items, index, 0L)
        }
        p.prepare()
        p.play()
    }

    private fun togglePlay() {
        val p = player
        if (p.isPlaying) {
            p.pause()
        } else {
            if (p.mediaItemCount == 0) {
                play(0)
                return
            }
            if (p.playbackState == Player.STATE_IDLE) p.prepare()
            p.play()
        }
    }

    private fun toggleShuffle() {
        player.shuffleModeEnabled = !player.shuffleModeEnabled
        updateToggleLabels()
    }

    private fun toggleRepeat() {
        val p = player
        p.repeatMode = when (p.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
        updateToggleLabels()
    }

    private fun updateToggleLabels() {
        val p = player
        shuffleBtn.text = if (p.shuffleModeEnabled) "🔀 Açık" else "🔀 Kapalı"
        repeatBtn.text = when (p.repeatMode) {
            Player.REPEAT_MODE_ALL -> "🔁 Tümü"
            Player.REPEAT_MODE_ONE -> "🔂 Tek"
            else -> "🔁 Kapalı"
        }
    }

    private fun updateProgress() {
        val p = player
        val d = p.duration
        val pos = p.currentPosition
        if (d > 0 && !userSeeking) {
            seek.max = (d / 1000).toInt().coerceAtLeast(1)
            seek.progress = (pos / 1000).toInt()
        }
        timeView.text = "${Ui.formatTime(pos)} / ${Ui.formatTime(if (d > 0) d else -1)}"
    }

    private fun refreshNow() {
        val id = player.currentMediaItem?.mediaId
        val t = tracks.firstOrNull { it.id.toString() == id }
        if (t == null) {
            nowTitle.text = "Şarkı seç"
            nowArtist.text = ""
            art.setImageDrawable(null)
            return
        }
        nowTitle.text = t.title
        nowArtist.text = t.artist
        val token = ++artToken
        val resolver = root.context.contentResolver
        io.execute {
            val bmp: Bitmap? = try {
                resolver.loadThumbnail(t.uri, Size(512, 512), null)
            } catch (_: Exception) {
                null
            }
            main.post {
                if (token == artToken) {
                    if (bmp != null) art.setImageBitmap(bmp) else art.setImageDrawable(null)
                }
            }
        }
    }
}
