package com.example.carmirror

import android.graphics.Bitmap
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Basit tarayıcı. YouTube / YouTube Music gibi siteler de burada açılır; ses telefondan
 * araca normal medya sesi olarak gider. Adres için kendi ekran klavyemiz kullanılır.
 */
class BrowserModule(private val root: RootView) : CarModule {

    override val title = "Tarayıcı"

    private lateinit var web: WebView
    private lateinit var urlView: TextView
    private var textZoom = 130

    private val desktopUa =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) " +
                "Chrome/124.0.0.0 Safari/537.36"

    private val startHtml = """
        <!DOCTYPE html><html lang="tr"><head><meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
          body{margin:0;background:#0c0614;color:#fff;font-family:sans-serif}
          h1{text-align:center;font-weight:600;margin:28px 0 18px}
          .g{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;padding:0 24px 24px}
          a{display:block;text-align:center;padding:34px 8px;border-radius:18px;
            color:#fff;text-decoration:none;font-size:26px;font-weight:600}
        </style></head><body>
        <h1>Hızlı erişim</h1>
        <div class="g">
          <a style="background:#e53935" href="https://www.youtube.com">YouTube</a>
          <a style="background:#d81b60" href="https://music.youtube.com">YouTube Music</a>
          <a style="background:#1e6fe0" href="https://www.google.com">Google</a>
          <a style="background:#2e9e4f" href="https://open.spotify.com">Spotify</a>
          <a style="background:#e08a00" href="https://news.google.com/?hl=tr">Haberler</a>
          <a style="background:#3949ab" href="https://www.google.com/maps">Harita</a>
        </div></body></html>
    """.trimIndent()

    override fun createView(root: RootView): View {
        val c = root.context

        web = WebView(c)
        urlView = Ui.label(c, "", 17f).apply {
            isSingleLine = true
            gravity = Gravity.CENTER_VERTICAL
            setPadding(c.dp(12), 0, c.dp(12), 0)
            background = Ui.round(Ui.PANEL, c.dp(10).toFloat())
            isClickable = true
            setOnClickListener {
                root.showKeyboard(currentTypedUrl(), "Adres yaz veya ara") { navigate(it) }
            }
        }

        configure()

        val bar = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(c.dp(6), c.dp(4), c.dp(6), c.dp(4))
        }
        fun add(label: String, sp: Float = 20f, onClick: () -> Unit) =
            bar.addView(Ui.button(c, label, sp) { onClick() }, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, c.dp(2)))

        add("◀") { if (web.canGoBack()) web.goBack() }
        add("▶") { if (web.canGoForward()) web.goForward() }
        add("⟳") { web.reload() }
        add("⌂") { loadStart() }
        bar.addView(urlView, Ui.lin(0, c.dp(52), 1f, c.dp(2)))
        add("A−", 16f) { setZoom(textZoom - 20) }
        add("A+", 16f) { setZoom(textZoom + 20) }
        add("▲") { web.pageUp(false) }
        add("▼") { web.pageDown(false) }

        val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        col.addView(bar, Ui.lin(Ui.MATCH, Ui.WRAP))
        col.addView(web, Ui.lin(Ui.MATCH, 0, 1f))

        loadStart()
        return col
    }

    private fun configure() {
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            useWideViewPort = true
            loadWithOverviewMode = true
            userAgentString = desktopUa
            textZoom = this@BrowserModule.textZoom
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)

        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                showUrl(url)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                showUrl(url)
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val scheme = request?.url?.scheme ?: return false
                return scheme !in listOf("http", "https", "about", "data", "blob", "file")
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (view == null) return
                root.showFullscreen(view) { callback?.onCustomViewHidden() }
            }

            override fun onHideCustomView() {
                root.hideFullscreen()
            }
        }
    }

    private fun loadStart() {
        web.loadDataWithBaseURL("https://start.page/", startHtml, "text/html", "utf-8", null)
    }

    private fun showUrl(url: String?) {
        urlView.text = when {
            url.isNullOrEmpty() -> "Adres yaz veya ara"
            url.startsWith("https://start.page") -> "Başlangıç sayfası"
            else -> url
        }
    }

    private fun currentTypedUrl(): String {
        val u = web.url ?: ""
        return if (u.startsWith("https://start.page")) "" else u
    }

    private fun navigate(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        val url = when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            !t.contains(' ') && t.contains('.') -> "https://$t"
            else -> "https://www.google.com/search?q=" + Uri.encode(t)
        }
        web.loadUrl(url)
    }

    private fun setZoom(z: Int) {
        textZoom = z.coerceIn(80, 260)
        web.settings.textZoom = textZoom
        root.toast("Yazı boyutu %$textZoom")
    }

    override fun onBack(): Boolean {
        if (web.canGoBack()) {
            web.goBack()
            return true
        }
        return false
    }

    override fun onDestroy() {
        try {
            web.destroy()
        } catch (_: Exception) {
        }
    }
}
