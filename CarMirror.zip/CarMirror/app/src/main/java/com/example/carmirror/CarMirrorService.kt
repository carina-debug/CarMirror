package com.example.carmirror

import android.content.Intent
import android.graphics.Color
import androidx.car.app.AppManager
import androidx.car.app.CarAppService
import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.Session
import androidx.car.app.SurfaceCallback
import androidx.car.app.SurfaceContainer
import androidx.car.app.model.Action
import androidx.car.app.model.ActionStrip
import androidx.car.app.model.CarColor
import androidx.car.app.model.CarIcon
import androidx.car.app.model.Template
import androidx.car.app.navigation.model.NavigationTemplate
import androidx.car.app.validation.HostValidator
import androidx.core.graphics.drawable.IconCompat
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner

/**
 * Android Auto'nun bağlandığı giriş noktası.
 * "Navigasyon" kategorisi sayesinde araç ekranının ham yüzeyine (Surface) erişim alırız.
 */
class CarMirrorService : CarAppService() {

    // Kişisel kullanım için tüm hostlara izin ver. Yayın yapacaksan gerçek bir doğrulayıcı kullan.
    override fun createHostValidator(): HostValidator = HostValidator.ALLOW_ALL_HOSTS_VALIDATOR

    override fun onCreateSession(): Session = MirrorSession()
}

class MirrorSession : Session() {
    override fun onCreateScreen(intent: Intent): Screen {
        val host = CarUiHost(carContext.applicationContext)
        lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onDestroy(owner: LifecycleOwner) {
                host.destroy()
            }
        })
        return MirrorScreen(carContext, host)
    }
}

class MirrorScreen(carContext: CarContext, private val host: CarUiHost) : Screen(carContext) {

    private val surfaceCallback = object : SurfaceCallback {

        override fun onSurfaceAvailable(surfaceContainer: SurfaceContainer) {
            val s = surfaceContainer.surface ?: return
            host.onSurfaceAvailable(
                s,
                surfaceContainer.width,
                surfaceContainer.height,
                surfaceContainer.dpi
            )
        }

        override fun onSurfaceDestroyed(surfaceContainer: SurfaceContainer) {
            host.onSurfaceDestroyed()
        }

        override fun onClick(x: Float, y: Float) {
            host.click(x, y)
        }

        override fun onScroll(distanceX: Float, distanceY: Float) {
            host.scroll(distanceX, distanceY)
        }

        override fun onFling(velocityX: Float, velocityY: Float) {
            host.fling(velocityX, velocityY)
        }
    }

    init {
        carContext.getCarService(AppManager::class.java).setSurfaceCallback(surfaceCallback)
        lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onDestroy(owner: LifecycleOwner) {
                carContext.getCarService(AppManager::class.java).setSurfaceCallback(null)
                host.onSurfaceDestroyed()
            }
        })
    }

    override fun onGetTemplate(): Template {
        val actions = ActionStrip.Builder()
            .addAction(iconAction(R.drawable.ic_back) { host.back() })
            .addAction(iconAction(R.drawable.ic_home) { host.menu() })
            .addAction(iconAction(R.drawable.ic_close) {
                host.destroy()
                carContext.finishCarApp()
            })
            .build()

        return NavigationTemplate.Builder()
            .setActionStrip(actions)
            .setBackgroundColor(CarColor.createCustom(Color.BLACK, Color.BLACK))
            .build()
    }

    private fun iconAction(resId: Int, onClick: () -> Unit): Action =
        Action.Builder()
            .setIcon(
                CarIcon.Builder(IconCompat.createWithResource(carContext, resId)).build()
            )
            .setOnClickListener { onClick() }
            .build()
}
