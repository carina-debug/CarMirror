plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.carmirror"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.carmirror"
        minSdk = 29
        targetSdk = 34
        versionCode = 6
        versionName = "3.2"
    }

    // Her bilgisayarda / GitHub Actions'ta AYNI anahtarla imzala: böylece yeni sürüm
    // eskisinin üzerine güncelleme olarak kurulur (kaldırmaya gerek kalmaz).
    signingConfigs {
        create("shared") {
            storeFile = file("keystore/carmirror.jks")
            storePassword = "carmirror123"
            keyAlias = "carmirror"
            keyPassword = "carmirror123"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("shared")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("shared")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.activity:activity-ktx:1.8.2")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.car.app:app:1.4.0")
    implementation("androidx.webkit:webkit:1.10.0")

    // Müzik, radyo, galeri videosu ve IPTV oynatma
    implementation("androidx.media3:media3-exoplayer:1.3.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.3.1")
    implementation("androidx.media3:media3-exoplayer-dash:1.3.1")
}
