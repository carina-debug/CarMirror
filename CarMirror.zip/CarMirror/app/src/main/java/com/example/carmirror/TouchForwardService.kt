package com.example.carmirror

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

/**
 * Araç ekranından gelen dokunuşları telefon ekranında gerçek dokunuş olarak uygular.
 * Ekran içeriğini okumaz; yalnızca hareket (gesture) gönderir.
 */
class TouchForwardService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: TouchForwardService? = null
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Kullanılmıyor
    }

    override fun onInterrupt() {
        // Kullanılmıyor
    }

    fun tap(x: Float, y: Float) = stroke(x, y, x, y, 50L)

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long) =
        stroke(x1, y1, x2, y2, durationMs)

    fun back() {
        performGlobalAction(GLOBAL_ACTION_BACK)
    }

    fun home() {
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    private fun stroke(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long) {
        val path = Path().apply {
            moveTo(x1, y1)
            if (x1 != x2 || y1 != y2) lineTo(x2, y2)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, durationMs.coerceAtLeast(1L)))
            .build()
        dispatchGesture(gesture, null, null)
    }
}
