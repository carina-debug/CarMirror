package com.example.carmirror

import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Ana menü: cam görünümlü kartlar ve renkli uygulama ikonları. Sıra ve renkler Ayarlar'dan değişir. */
class HomeModule(private val root: RootView) : CarModule {

    override val title = "Ana menü"

    private lateinit var holder: FrameLayout

    override fun createView(root: RootView): View {
        holder = FrameLayout(root.context)
        rebuild()
        return holder
    }

    // Ayarlar'da sıra değişmiş olabilir; her gösterimde yeniden kur.
    override fun onShow() {
        rebuild()
    }

    private fun rebuild() {
        val c = root.context
        holder.removeAllViews()
        holder.addView(buildGrid(), FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
    }

    private fun buildGrid(): View {
        val c = root.context
        val compact = root.compact
        val cols = if (compact) 3 else 5
        val pad = if (compact) c.dp(8) else c.dp(14)
        val grid = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Ui.HOME_TOP, Ui.HOME_BOTTOM)
            )
        }
        Apps.ordered(c, root.isPhone).chunked(cols).forEach { rowApps ->
            val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
            rowApps.forEach { app -> row.addView(tileView(app), Ui.lin(0, Ui.MATCH, 1f, c.dp(7))) }
            // Eksik kalan son satırda kutular genişlemesin
            repeat(cols - rowApps.size) { row.addView(View(c), Ui.lin(0, Ui.MATCH, 1f, c.dp(7))) }
            // Telefonda sabit yükseklikli satırlar + kaydırma; araçta ekranı eşit böl
            grid.addView(row, if (compact) Ui.lin(Ui.MATCH, c.dp(128)) else Ui.lin(Ui.MATCH, 0, 1f))
        }
        if (!compact) return grid
        return ScrollView(c).apply {
            isFillViewport = true
            addView(grid, FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        }
    }

    private fun tileView(app: App): View {
        val c = root.context
        val card = GradientDrawable().apply {
            setColor(0x16FFFFFF)
            cornerRadius = c.dp(20).toFloat()
            setStroke(c.dp(1), 0x2EFFFFFF)
        }
        val compact = root.compact
        val iconSize = if (compact) 60 else 76
        val icon = TextView(c).apply {
            text = app.glyph
            textSize = if (compact) 28f else 34f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            background = Ui.gradient(app.c1, app.c2, c.dp(18).toFloat())
        }
        return LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            // Telefonda ikonlar aynı hizada dursun (2 satırlık etiketler ikonu kaydırmasın)
            gravity = if (compact) Gravity.TOP or Gravity.CENTER_HORIZONTAL else Gravity.CENTER
            if (compact) setPadding(c.dp(4), c.dp(14), c.dp(4), c.dp(4))
            background = card
            isClickable = true
            addView(icon, LinearLayout.LayoutParams(c.dp(iconSize), c.dp(iconSize)))
            addView(
                Ui.label(c, app.label, if (compact) 14f else 17f, bold = true).apply {
                    gravity = Gravity.CENTER
                    if (compact) {
                        maxLines = 2
                        ellipsize = TextUtils.TruncateAt.END
                    } else {
                        isSingleLine = true
                    }
                },
                Ui.lin(Ui.WRAP, Ui.WRAP).apply { topMargin = c.dp(if (compact) 8 else 12) }
            )
            setOnClickListener {
                if (app.id == "mirror") root.host.enterMirror() else root.open(app.id)
            }
        }
    }
}
