package com.example.carmirror

import android.content.Context
import android.graphics.PointF
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Display
import android.view.Surface
import kotlin.math.min

/**
 * "Telefon ekranı" modu: MediaProjection ile telefon ekranını araç yüzeyine çizer ve
 * araçtan gelen dokunuşları erişilebilirlik servisiyle telefona geri iletir.
 * Yüzeyi CarUiHost verir (setTarget / clearTarget).
 */
object MirrorBridge {

    /** Kaydırma yönü ters çıkarsa -1f yap. */
    private const val SCROLL_SIGN = 1f

    private val main = Handler(Looper.getMainLooper())

    @Volatile
    var projection: MediaProjection? = null
        private set

    /** Araç ekranı yüzeyi şu an var mı (durum satırı için). */
    @Volatile
    var hasCarSurface: Boolean = false

    private var virtualDisplay: VirtualDisplay? = null
    private var surface: Surface? = null
    private var carWidth = 0
    private var carHeight = 0
    private var carDpi = 0

    // Kaydırma birikimi
    private var pendDx = 0f
    private var pendDy = 0f
    private val flushScroll = Runnable { flushPendingScroll() }

    // ---------------------------------------------------------------- yansıtma

    fun attachProjection(p: MediaProjection) {
        release()
        projection = p
        ensureDisplay()
    }

    fun setTarget(s: Surface, width: Int, height: Int, dpi: Int) {
        surface = s
        carWidth = width
        carHeight = height
        carDpi = dpi
        ensureDisplay()
    }

    fun clearTarget() {
        surface = null
        try {
            virtualDisplay?.surface = null
        } catch (_: Exception) {
        }
    }

    fun release() {
        val vd = virtualDisplay
        val p = projection
        virtualDisplay = null
        projection = null
        try {
            vd?.release()
        } catch (_: Exception) {
        }
        try {
            p?.stop()
        } catch (_: Exception) {
        }
    }

    private fun ensureDisplay() {
        val p = projection ?: return
        val s = surface ?: return
        if (!s.isValid || carWidth <= 0 || carHeight <= 0) return
        try {
            val vd = virtualDisplay
            if (vd == null) {
                // Android 14+: bir MediaProjection ile yalnızca BİR VirtualDisplay açılabilir.
                // Sonraki yüzey değişimlerinde aynı ekranın surface'i değiştirilir.
                virtualDisplay = p.createVirtualDisplay(
                    "CarMirror",
                    carWidth,
                    carHeight,
                    carDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    s,
                    null,
                    null
                )
            } else {
                vd.resize(carWidth, carHeight, carDpi)
                vd.surface = s
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // ---------------------------------------------------------------- dokunma

    /** Araç yüzeyi koordinatını telefon ekranı koordinatına çevirir; bant (letterbox) alanındaysa null. */
    private fun toPhone(svc: Context, x: Float, y: Float): PointF? {
        if (carWidth <= 0 || carHeight <= 0) return null
        val (pw, ph) = phoneSize(svc)
        val scale = min(carWidth / pw, carHeight / ph)
        val offX = (carWidth - pw * scale) / 2f
        val offY = (carHeight - ph * scale) / 2f
        val px = (x - offX) / scale
        val py = (y - offY) / scale
        if (px < 0f || py < 0f || px > pw || py > ph) return null
        return PointF(px, py)
    }

    private fun phoneScale(svc: Context): Float {
        val (pw, ph) = phoneSize(svc)
        return min(carWidth / pw, carHeight / ph)
    }

    @Suppress("DEPRECATION")
    private fun phoneSize(ctx: Context): Pair<Float, Float> {
        val dm = ctx.getSystemService(DisplayManager::class.java)
        val display = dm.getDisplay(Display.DEFAULT_DISPLAY)
        val m = DisplayMetrics()
        display.getRealMetrics(m)
        return Pair(m.widthPixels.toFloat(), m.heightPixels.toFloat())
    }

    /** @return erişilebilirlik servisi kapalıysa false */
    fun tap(x: Float, y: Float): Boolean {
        val svc = TouchForwardService.instance ?: return false
        val p = toPhone(svc, x, y) ?: return true
        svc.tap(p.x, p.y)
        return true
    }

    fun scroll(dx: Float, dy: Float) {
        pendDx += dx
        pendDy += dy
        main.removeCallbacks(flushScroll)
        main.postDelayed(flushScroll, 120)
    }

    private fun flushPendingScroll() {
        val svc = TouchForwardService.instance
        val dx = pendDx
        val dy = pendDy
        pendDx = 0f
        pendDy = 0f
        if (svc == null || (dx == 0f && dy == 0f) || carWidth <= 0) return
        val (pw, ph) = phoneSize(svc)
        val scale = phoneScale(svc)
        val cx = pw / 2f
        val cy = ph / 2f
        // Parmak, kaydırma mesafesinin tersi yönde hareket eder (GestureDetector kuralı)
        val ex = (cx - SCROLL_SIGN * dx / scale).coerceIn(1f, pw - 1f)
        val ey = (cy - SCROLL_SIGN * dy / scale).coerceIn(1f, ph - 1f)
        svc.swipe(cx, cy, ex, ey, 150L)
    }

    fun fling(vx: Float, vy: Float) {
        main.removeCallbacks(flushScroll)
        pendDx = 0f
        pendDy = 0f
        val svc = TouchForwardService.instance ?: return
        if (carWidth <= 0) return
        val (pw, ph) = phoneSize(svc)
        val scale = phoneScale(svc)
        val cx = pw / 2f
        val cy = ph / 2f
        val ex = (cx + SCROLL_SIGN * vx * 0.2f / scale).coerceIn(1f, pw - 1f)
        val ey = (cy + SCROLL_SIGN * vy * 0.2f / scale).coerceIn(1f, ph - 1f)
        svc.swipe(cx, cy, ex, ey, 150L)
    }

    fun back() {
        TouchForwardService.instance?.back()
    }

    fun home() {
        TouchForwardService.instance?.home()
    }
}
