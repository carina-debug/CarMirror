package com.example.carmirror

import android.view.Gravity
import android.view.View
import android.widget.LinearLayout

class HomeModule(private val root: RootView) : CarModule {

    override val title = "Ana menü"

    private data class Tile(val id: String, val icon: String, val label: String, val color: Int)

    private val tiles = listOf(
        Tile("browser", "🌐", "Tarayıcı", 0xFF1E6FE0.toInt()),
        Tile("music", "🎵", "Müzik", 0xFFD81B60.toInt()),
        Tile("radio", "📻", "Radyo", 0xFF2E9E4F.toInt()),
        Tile("gallery", "🖼", "Galeri", 0xFFE08A00.toInt()),
        Tile("iptv", "📺", "IPTV", 0xFF3949AB.toInt()),
        Tile("mirror", "📱", "Telefon ekranı", 0xFF8A2BE2.toInt())
    )

    override fun createView(root: RootView): View {
        val c = root.context
        val grid = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(c.dp(12), c.dp(12), c.dp(12), c.dp(12))
        }
        tiles.chunked(3).forEach { rowTiles ->
            val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
            rowTiles.forEach { t -> row.addView(tileView(t), Ui.lin(0, Ui.MATCH, 1f, c.dp(8))) }
            grid.addView(row, Ui.lin(Ui.MATCH, 0, 1f))
        }
        return grid
    }

    private fun tileView(t: Tile): View {
        val c = root.context
        return LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = Ui.round(t.color, c.dp(20).toFloat())
            isClickable = true
            addView(Ui.label(c, t.icon, 52f).apply { gravity = Gravity.CENTER })
            addView(Ui.label(c, t.label, 24f, bold = true).apply { gravity = Gravity.CENTER })
            setOnClickListener {
                if (t.id == "mirror") root.host.enterMirror() else root.open(t.id)
            }
        }
    }
}
